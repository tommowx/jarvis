const fs=require('node:fs/promises'),path=require('node:path');const {randomUUID}=require('node:crypto');const {redact}=require('./vault-memory.cjs');
class RoutineStore{
 constructor({file,encrypt=s=>Buffer.from(s),decrypt=b=>b.toString(),emit=()=>{},now=()=>Date.now()}){Object.assign(this,{file,encrypt,decrypt,emit,now});this.data={routines:[],reminders:[],runs:[]};this.queue=Promise.resolve();this.ticking=false;this.running=new Set();}
 async load(){try{this.data=JSON.parse(this.decrypt(await fs.readFile(this.file)));}catch(e){if(e.code!=='ENOENT')throw new Error('Routine salvate non leggibili, file conservato.');}this.data.runs||=[];if(!Array.isArray(this.data.routines)||!Array.isArray(this.data.reminders)||!Array.isArray(this.data.runs))throw new Error('Formato routine non valido: file conservato.');for(const job of this.data.runs)if(job.status==='running'){job.status=job.current===null?'paused':'uncertain';job.interruptedAt=new Date(this.now()).toISOString();}await this.save();if(!Array.isArray(this.data.routines)||!Array.isArray(this.data.reminders))throw new Error('Formato routine non valido.');}
 save(){const work=this.queue.then(async()=>{await fs.mkdir(path.dirname(this.file),{recursive:true});await fs.writeFile(this.file+'.tmp',this.encrypt(JSON.stringify(this.data)));await fs.rename(this.file+'.tmp',this.file);});this.queue=work.catch(()=>{});return work;}
 async reminder(text,delayMinutes){if(typeof text!=='string'||!text.trim()||text.length>1000||!Number.isFinite(delayMinutes)||delayMinutes<.1||delayMinutes>525600)throw new Error('Promemoria non valido: durata tra 6 secondi e un anno.');const reminder={id:randomUUID(),text:redact(text),dueAt:new Date(this.now()+delayMinutes*60000).toISOString(),deliveredAt:null};this.data.reminders.push(reminder);await this.save();return reminder;}
 async tick(){if(this.ticking)return;this.ticking=true;try{const due=this.data.reminders.filter(r=>!r.deliveredAt&&Date.parse(r.dueAt)<=this.now());for(const item of due){item.deliveredAt=new Date(this.now()).toISOString();await this.save();this.emit({type:'reminder',text:item.text,dueAt:item.dueAt});}}finally{this.ticking=false;}}
 async define(name,steps,request){if(typeof name!=='string'||!name.trim()||name.length>60||!Array.isArray(steps)||!steps.length||steps.length>10)throw new Error('Routine non valida.');const allowed=['open_app','project_status','set_theme','search_memory'];if(steps.some(s=>!s||!allowed.includes(s.name)||!s.args||typeof s.args!=='object'))throw new Error('La routine contiene azioni non supportate.');const record={id:randomUUID(),name:name.trim(),steps:JSON.parse(JSON.stringify(steps)),request:redact(request),updatedAt:new Date(this.now()).toISOString()};const old=this.data.routines.findIndex(r=>r.name.toLowerCase()===record.name.toLowerCase());if(old>=0)this.data.routines[old]=record;else this.data.routines.push(record);await this.save();return record;}

 async pause(){const active=this.data.runs.filter(r=>r.status==='running');for(const job of active)job.pauseRequested=true;await this.save();return{requested:active.length,note:'Pausa al termine del passo corrente; nessuna azione completata viene annullata.'};}
 async run(name,execute,signal,resume=false){
  const routine=this.data.routines.find(r=>r.name.toLowerCase()===String(name).toLowerCase());if(!routine)throw new Error('Routine non trovata.');if(this.running.has(routine.id))throw new Error('Questa routine è già in esecuzione.');
  let job;if(resume){job=[...this.data.runs].reverse().find(r=>r.routineId===routine.id&&['paused','uncertain'].includes(r.status));if(!job)throw new Error('Nessuna routine in pausa.');if(job.status==='uncertain')throw new Error('Il riavvio ha interrotto un passo: il suo risultato è incerto. Controllalo prima di avviare una nuova routine.');if(job.version!==routine.updatedAt)throw new Error('La routine è stata modificata: la vecchia esecuzione non viene ripresa.');}
  else{job={id:randomUUID(),routineId:routine.id,name:routine.name,version:routine.updatedAt,next:0,current:null,status:'running',results:[],startedAt:new Date(this.now()).toISOString()};this.data.runs.push(job);this.data.runs=this.data.runs.slice(-100);}
  job.pauseRequested=false;job.status='running';this.running.add(routine.id);await this.save();
  try{for(let i=job.next;i<routine.steps.length;i++){
   if(signal?.aborted||job.pauseRequested){job.status='paused';break;}
   const step=routine.steps[i];job.current=i;await this.save();
   try{const result=await execute(step.name,step.args,routine.request);const ok=result?.applied!==false&&result?.completed!==false&&result?.opened!==false;job.results.push({name:step.name,ok,result:JSON.parse(redact(JSON.stringify(result??null)))});job.current=null;job.next=i+1;if(!ok){job.status='failed';await this.save();break;}}
   catch(error){job.results.push({name:step.name,ok:false,error:redact(String(error.message))});job.status='uncertain';await this.save();break;}
   await this.save();
  }
  if(job.next===routine.steps.length&&job.status==='running')job.status='completed';await this.save();return{name:routine.name,runId:job.id,results:job.results,completed:job.status==='completed',paused:job.status==='paused',status:job.status,nextStep:job.next+1};
  }finally{this.running.delete(routine.id);}
 }

 list(){return {runs:(this.data.runs||[]).slice(-10).map(({id,name,status,next})=>({id,name,status,nextStep:next+1})),routines:this.data.routines.map(({id,name,steps,updatedAt})=>({id,name,actions:steps.length,updatedAt})),reminders:this.data.reminders.filter(r=>!r.deliveredAt).map(r=>({...r}))};}
}
module.exports={RoutineStore};
