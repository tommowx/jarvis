const normalize=value=>String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’']/g,' ').replace(/\s+/g,' ').trim();
function volumeIntent(text,previous=[],current=30){
 const s=normalize(text), recent=previous.slice(-3).some(m=>/volume|voce|audio|parli|forte|piano/.test(normalize(m.content||'')));
 if(/\bnon\s+(?:mi\s+)?(?:abbass|alz|aument|riduc|modific|cambia|silenz|mut|speg)/.test(s))return null;
 const voice=/volume|voce|audio|parli|parla/.test(s), adjustment=/abbass|riduc|alza|aument|troppo alt|troppo fort|piu piano|meno forte|piu forte|silenzia|muta|spegni|riattiva|imposta|metti|porta|regola/.test(s);
 const words={zero:0,uno:1,una:1,due:2,tre:3,quattro:4,cinque:5,sei:6,sette:7,otto:8,nove:9,dieci:10,undici:11,dodici:12,tredici:13,quattordici:14,quindici:15,sedici:16,diciassette:17,diciotto:18,diciannove:19,venti:20,trenta:30,quaranta:40,cinquanta:50,sessanta:60,settanta:70,ottanta:80,novanta:90,cento:100};
 for (const [tens,base] of Object.entries(words).filter(([,v])=>v>=20&&v<100&&v%10===0)) for(const [unit,n] of Object.entries(words).filter(([,v])=>v>=1&&v<=9)) words[(n===1||n===8?tens.slice(0,-1):tens)+unit]=base+n;
 let number=null;const digit=s.match(/\b(100|\d{1,2})\s*(?:%|per\s*cento|percento)(?=\s|$|[.,!?])/)||s.match(/(?:\b(?:al|a|all|volume)\s+)(100|\d{1,2})(?:\s|$|%)/);
 if(digit)number=Number(digit[1]);
 if(number===null){const entries=Object.entries(words).sort((a,b)=>b[0].length-a[0].length);for(const [word,value] of entries){if(new RegExp('\\b'+word+'\\s*(?:per\\s*cento|percento)\\b').test(s)||new RegExp('\\b(?:al|a|all|volume)\\s+(?:il\\s+)?'+word+'(?:\\s|$)').test(s)){number=value;break;}}}
 if(number===null&&recent){if(Object.prototype.hasOwnProperty.call(words,s))number=words[s];else if(/^\d{1,3}$/.test(s))number=Number(s);}
 const shorthand=recent&&(/^(?:al\b|a\b|all\b|abbass|riduc|alza|aument|ancora\b|piu\b|meno\b|solo\b)/.test(s)||(number!==null&&s.split(' ').length<=7));
 if(!voice&&!shorthand&&! (recent&&/piu piano|meno forte|troppo alt|troppo forte|ancora piu basso/.test(s)))return null;
 if(number===null&&!adjustment&&!/piu piano|meno forte|troppo alt|troppo forte|ancora piu basso/.test(s))return null;
 let volume=number;
 if(volume===null){if(/silenzia|muta|spegni/.test(s))volume=0;else if(/riattiva/.test(s))volume=30;else volume=current+(/abbass|riduc|troppo alt|troppo fort|piu piano|meno forte|piu basso/.test(s)?-10:10);}
 return Math.max(number===null&&!/silenzia|muta|spegni/.test(s)?1:0,Math.min(100,volume));
}
module.exports={volumeIntent};
