const fs = require('node:fs/promises');
const path = require('node:path');
const AdmZip = require('adm-zip');
const { createHash } = require('node:crypto');
const { locateUsbVault, redact } = require('./vault-memory.cjs');
function messagesOf(chat) {
  const mapping = chat.mapping || {}; let nodes;
  if (chat.current_node && mapping[chat.current_node]) { nodes = []; let node = mapping[chat.current_node], guard = new Set(); while (node && !guard.has(node.id)) { guard.add(node.id); nodes.push(node); node = mapping[node.parent]; } nodes.reverse(); }
  else nodes = Object.values(mapping).sort((a, b) => (a.message?.create_time || 0) - (b.message?.create_time || 0));
  return nodes.map(n => n.message).filter(m => m && ['user', 'assistant'].includes(m.author?.role) && !m.metadata?.is_visually_hidden_from_conversation && (!m.channel || ['final', 'commentary'].includes(m.channel)))
    .map(m => ({ id: String(m.id || createHash('sha256').update(JSON.stringify(m)).digest('hex')), role: m.author.role, at: m.create_time ? new Date(m.create_time * 1000).toISOString() : null,
      text: (m.content?.parts || []).map(p => typeof p === 'string' ? p : p?.content_type === 'image_asset_pointer' ? '[Allegato immagine presente nell’esportazione, non trascritto]' : '').filter(Boolean).join('\n') })).filter(m => m.text.trim());
}
async function importChatGPT(file, documents, { locateVault = locateUsbVault } = {}) {
  if ((await fs.stat(file)).size > 512 * 1024 * 1024) throw new Error('Esportazione troppo grande per questo importatore (limite 512 MB).');
  let data;
  if (/\.zip$/i.test(file)) { const zip = new AdmZip(file); const entry = zip.getEntries().find(e => /(?:^|\/)conversations\.json$/.test(e.entryName)); if (!entry || entry.header.size > 200 * 1024 * 1024) throw new Error('conversations.json non trovato o troppo grande.'); data = JSON.parse(entry.getData().toString('utf8')); }
  else data = JSON.parse(await fs.readFile(file, 'utf8'));
  if (!Array.isArray(data)) throw new Error('Esportazione ChatGPT non riconosciuta.');
  const root = await locateVault(); const folder = root ? path.join(root, '04 Conversazioni', 'ChatGPT importate da Jarvis') : path.join(documents, 'Obsidian-pending', 'ChatGPT importate da Jarvis'); await fs.mkdir(folder, { recursive: true });
  let chats = 0, messages = 0;
  for (const chat of data) {
    const id = String(chat.id || chat.conversation_id || createHash('sha256').update(JSON.stringify(chat)).digest('hex')).replace(/[^a-z0-9-]/gi, '').slice(0, 80);
    const title = String(chat.title || 'Conversazione senza titolo').replace(/[<>:"/\\|?*\x00-\x1f]/g, ' ').slice(0, 100).trim();
    const existing = (await fs.readdir(folder)).find(name => name.endsWith(' — ' + id + '.md'));
    const target = path.join(folder, existing || title + ' — ' + id + '.md'); const original = await fs.readFile(target, 'utf8').catch(() => '');
    const fresh = messagesOf(chat).filter(m => !original.includes('<!-- chatgpt-message:' + m.id + ' -->'));
    if (!fresh.length) continue;
    const header = original ? '' : `---\nsource: ChatGPT export ufficiale\nthread_id: "${id}"\ntags: [conversazione, memoria-ai]\n---\n\n# ${title}\n\n[[00 Grafo memoria]] · [[05 Temi/Memoria e AI]]\n\n`;
    await fs.appendFile(target, header + fresh.map(m => `<!-- chatgpt-message:${m.id} -->\n## ${m.role === 'user' ? 'Utente' : 'Assistente'} · ${m.at || 'data non disponibile'}\n\n${redact(m.text)}\n\n`).join('')); chats++; messages += fresh.length;
  }
  return { chats, messages, usb: Boolean(root), destination: folder, limit: 'Importati i messaggi testuali del ramo corrente. Gli allegati binari non vengono importati da questo passaggio.' };
}
async function flushPendingImports(documents, { locateVault = locateUsbVault } = {}) {
  const root = await locateVault(); if (!root) return;
  const pending = path.join(documents, 'Obsidian-pending', 'ChatGPT importate da Jarvis');
  const destination = path.join(root, '04 Conversazioni', 'ChatGPT importate da Jarvis');
  const names = await fs.readdir(pending).catch(() => []); if (!names.length) return;
  await fs.mkdir(destination, { recursive: true });
  for (const name of names.filter(name => name.endsWith('.md'))) {
    const source = await fs.readFile(path.join(pending, name), 'utf8');
    const suffix = name.match(/ — ([a-z0-9-]+)\.md$/i)?.[0];
    const existing = suffix && (await fs.readdir(destination)).find(n => n.endsWith(suffix));
    const target = path.join(destination, existing || name);
    const old = await fs.readFile(target, 'utf8').catch(() => '');
    if (!old) { await fs.writeFile(target, source); continue; }
    const blocks = source.split(/(?=<!-- chatgpt-message:)/).slice(1);
    const fresh = blocks.filter(block => !old.includes(block.slice(0, block.indexOf('-->') + 3)));
    if (fresh.length) await fs.appendFile(target, fresh.join(''));
  }
  // Keep pending files as recovery copies. Message markers prevent duplication on the next scan.
}
module.exports = { importChatGPT, messagesOf, flushPendingImports };
