"""Local multilingual transcription. Input PCM stays in memory; model never downloads here."""
import io, json, math, os, re, time, wave
import numpy as np

NAMES = 'Jarvis, TurboStick, CryptoDesk, Simio, Obsidian, ChatGPT, Discord.'

def canonical_names(text):
    for pattern, name in [(r'\bturbo[ -]*stick\b', 'TurboStick'), (r'\bcrypto[ -]*desk\b', 'CryptoDesk'), (r'\bsimio\b', 'Simio'), (r'\bchat[ -]*gpt\b', 'ChatGPT')]:
        text = re.sub(pattern, name, text, flags=re.I)
    return text.strip()

class SpeechRecognizer:
    def __init__(self, model_dir):
        self.dll_directories = []
        gpu_root = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'JarvisBeta', 'voice', 'gpu-packages')
        dll_paths = []
        if os.name == 'nt' and os.path.isdir(gpu_root):
            for folder, _, files in os.walk(gpu_root):
                if any(name.lower().endswith('.dll') for name in files):
                    dll_paths.append(folder)
                    self.dll_directories.append(os.add_dll_directory(folder))
            if dll_paths:
                os.environ['PATH'] = os.pathsep.join(dll_paths) + os.pathsep + os.environ.get('PATH', '')
        os.environ.setdefault('CT2_CUDA_ALLOCATOR', 'cub_caching')
        from faster_whisper import WhisperModel
        import ctranslate2
        self.beam_size = 5
        self.engine = 'whisper-' + ('base' if os.path.basename(model_dir).endswith('base') else 'small') + '-int8'
        self.model_dir = model_dir; self.device = 'cpu'; self.fallback_reason = None
        verified_gpu = os.path.isfile(os.path.join(gpu_root, 'verified.json'))
        requested_device = os.environ.get('JARVIS_STT_DEVICE', 'auto')
        if dll_paths and (requested_device == 'cuda' or (requested_device == 'auto' and verified_gpu)):
            try:
                supported = ctranslate2.get_supported_compute_types('cuda', 0)
                if 'int8_float32' in supported:
                    self.model = WhisperModel(model_dir, device='cuda', compute_type='int8_float32',
                                              num_workers=1, local_files_only=True)
                    self.device = 'cuda'
            except Exception:
                self.fallback_reason = 'GPU non disponibile: uso CPU.'
        if self.device == 'cpu':
            self.model = WhisperModel(model_dir, device='cpu', compute_type='int8', cpu_threads=4,
                                      num_workers=1, local_files_only=True)

    def transcribe(self, pcm, rate=16000, language='auto'):
        try:
            return self._transcribe(pcm, rate, language)
        except Exception:
            if self.device != 'cuda':
                raise
            from faster_whisper import WhisperModel
            self.model = None
            self.model = WhisperModel(self.model_dir, device='cpu', compute_type='int8', cpu_threads=4,
                                      num_workers=1, local_files_only=True)
            self.device = 'cpu'; self.fallback_reason = 'GPU non disponibile: riconoscimento su CPU, più lento.'
            return self._transcribe(pcm, rate, language)

    def _transcribe(self, pcm, rate=16000, language='auto'):
        started = time.monotonic()
        if len(pcm) < rate * 2 * .3:
            return {'text': '', 'reason': 'too-short'}
        if rate != 16000:
            from faster_whisper.audio import decode_audio
            stream = io.BytesIO()
            with wave.open(stream, 'wb') as output:
                output.setnchannels(1); output.setsampwidth(2); output.setframerate(rate); output.writeframes(pcm)
            stream.seek(0); samples = decode_audio(stream, sampling_rate=16000)
        else:
            samples = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(samples * samples)))
        if rms < .0006:
            return {'text': '', 'reason': 'silence'}
        peak = float(np.max(np.abs(samples)))
        if 0 < peak < .4:
            samples *= min(6.0, .6 / peak)
        segments, info = self.model.transcribe(
            samples, language=None if language == 'auto' else language, task='transcribe',
            beam_size=self.beam_size, best_of=1, without_timestamps=True, temperature=0, condition_on_previous_text=False,
            initial_prompt=NAMES,
            hotwords=NAMES, vad_filter=True,
            vad_parameters={'min_silence_duration_ms': 300, 'speech_pad_ms': 180},
            no_speech_threshold=.6, log_prob_threshold=-1.0,
            compression_ratio_threshold=2.4, hallucination_silence_threshold=1.0)
        accepted = [segment for segment in segments if segment.avg_logprob >= -1.05 and
                    not (segment.no_speech_prob > .6 and segment.avg_logprob < -.5)]
        text = canonical_names(' '.join(segment.text.strip() for segment in accepted))
        return {'text': text, 'language': info.language, 'engine': self.engine, 'device': self.device,
                'transcriptionMs': round((time.monotonic() - started) * 1000),
                'audioSeconds': round(len(samples) / 16000, 2)}

if __name__ == '__main__':
    import argparse, sys
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(); parser.add_argument('file'); parser.add_argument('--model', required=True)
    parser.add_argument('--language', default='auto', choices=['auto', 'it', 'en']); args = parser.parse_args()
    from faster_whisper.audio import decode_audio
    samples = decode_audio(args.file)
    pcm = (np.clip(samples, -1, 1) * 32767).astype(np.int16).tobytes()
    print(json.dumps(SpeechRecognizer(args.model).transcribe(pcm, language=args.language), ensure_ascii=False))
