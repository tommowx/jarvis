const fs = require('node:fs/promises');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { locateUsbVault, redact } = require('./vault-memory.cjs');

class ConversationStore {
  constructor({ userData, documents, encrypt, decrypt, onChange = () => {}, archiveEnabled = true, locateVault = locateUsbVault }) {
    Object.assign(this, { userData, documents, encrypt, decrypt, onChange, archiveEnabled, locateVault });
    this.file = path.join(userData, 'conversation-memory.dat'); this.messages = []; this.queue = Promise.resolve();
    this.archiveState = { usb: false, pending: 0, error: null };
  }
  async init() {
    await fs.mkdir(this.userData, { recursive: true });
    try { const data = JSON.parse(this.decrypt(await fs.readFile(this.file))); if (Array.isArray(data)) this.messages = data.filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({ ...m, id: m.id || randomUUID(), at: m.at || null })); }
    catch (e) { if (e.code !== 'ENOENT') throw new Error('La conversazione salvata non è leggibile. Il file è stato conservato.'); }
    return this.messages;
  }
  async append(role, content, extra = {}) {
    const message = { ...extra, id: randomUUID(), at: new Date().toISOString(), role, content: String(content) };
    const operation = this.queue.then(async () => {
      const next = [...this.messages, message];
      const temporary = this.file + '.tmp';
      await fs.writeFile(temporary, this.encrypt(JSON.stringify(next))); await fs.rename(temporary, this.file);
      this.messages = next; this.onChange(this.messages);
      await this.archive().catch(() => { this.archiveState.error = 'Archivio USB non aggiornato; conversazione conservata sul PC.'; });
      return message;
    });
    this.queue = operation.catch(() => {}); return operation;
  }
  context(query) {
    const recent = this.messages.slice(-24); const older = this.messages.slice(0, -24);
    const terms = new Set(query.toLowerCase().match(/[\p{L}\p{N}]{4,}/gu) || []);
    const related = older.map((m, i) => ({ i, n: [...terms].filter(t => m.content.toLowerCase().includes(t)).length })).filter(x => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 8).map(x => x.i);
    const indices = new Set(related.flatMap(i => [Math.max(0, i - 1), i, Math.min(older.length - 1, i + 1)]));
    const selected = [...indices].sort((a, b) => a - b).map(i => older[i]).concat(recent).slice(-40).map(({ role, content }) => ({ role, content }));
    while (selected.length > 2 && selected.reduce((s, m) => s + m.content.length, 0) > 55000) selected.shift();
    return selected;
  }
  async archive() {
    if (!this.archiveEnabled) return { usb: false, pending: 0, testing: true };
    const root = await this.locateVault();
    const folder = root ? path.join(root, '04 Conversazioni', 'Jarvis locale') : path.join(this.documents, 'Obsidian-pending', 'Jarvis');
    await fs.mkdir(folder, { recursive: true });
    const file = path.join(folder, 'Jarvis — conversazione continua.md');
    const old = await fs.readFile(file, 'utf8').catch(() => '');
    const ids = new Set([...old.matchAll(/<!-- jarvis-message:([a-f0-9-]+) -->/g)].map(m => m[1]));
    const fresh = this.messages.filter(m => !ids.has(m.id));
    if (fresh.length) {
      const header = old ? '' : '---\nsource: Jarvis locale\ntags: [conversazione, jarvis, memoria-ai]\n---\n\n# Jarvis — conversazione continua\n\n[[00 Grafo memoria]] · [[05 Temi/Memoria e AI]]\n\n';
      await fs.appendFile(file, header + fresh.map(m => `<!-- jarvis-message:${m.id} -->\n## ${m.role === 'user' ? 'Utente' : 'Jarvis'} · ${m.at || 'data originale non disponibile'}\n\n${redact(m.content)}\n\n`).join(''));
    }
    this.archiveState = { usb: Boolean(root), pending: root ? 0 : fresh.length, error: null };
    if (root) {
      const index = path.join(root, '04 Conversazioni', 'Indice conversazioni.md');
      const content = await fs.readFile(index, 'utf8').catch(() => '');
      if (!content.includes('[[04 Conversazioni/Jarvis locale/Jarvis — conversazione continua')) await fs.appendFile(index, '\n- [[04 Conversazioni/Jarvis locale/Jarvis — conversazione continua|Jarvis — conversazione continua]] — archivio locale aggiornato dall’app.\n');
      // The complete local history is also the queue: after USB transfer the pending file is retained as a fallback copy.
    }
    return this.archiveState;
  }
}
module.exports = { ConversationStore };
