import Foundation
import Speech
import AVFoundation

func emit(_ object: [String: Any]) {
    if let data = try? JSONSerialization.data(withJSONObject: object), let line = String(data: data, encoding: .utf8) {
        print(line); fflush(stdout)
    }
}
final class SpeechWorker {
    let engine = AVAudioEngine()
    var recognizer: SFSpeechRecognizer?
    var request: SFSpeechAudioBufferRecognitionRequest?
    var task: SFSpeechRecognitionTask?
    var timer: DispatchWorkItem?
    var paused = false
    var stopped = false
    var tapped = false
    var lastText = ""
    init(locale: String) { recognizer = SFSpeechRecognizer(locale: Locale(identifier: locale)) }
    func end() {
        timer?.cancel(); timer = nil
        engine.stop()
        if tapped { engine.inputNode.removeTap(onBus: 0); tapped = false }
        request?.endAudio(); task?.cancel(); task = nil; request = nil
    }
    func start() {
        if stopped || paused { return }
        end(); lastText = ""
        guard let recognizer = recognizer, recognizer.isAvailable else { emit(["type":"error","message":"Riconoscimento Speech non disponibile per questa lingua sul Mac."]); return }
        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        if recognizer.supportsOnDeviceRecognition { req.requiresOnDeviceRecognition = true }
        request = req
        let node = engine.inputNode
        let format = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in req.append(buffer) }
        tapped = true
        do { engine.prepare(); try engine.start() } catch { emit(["type":"error","message":"Microfono macOS non disponibile. Controlla il permesso Microfono."]); end(); return }
        emit(["type":"ready"])
        task = recognizer.recognitionTask(with: req) { [weak self] result, error in
            DispatchQueue.main.async {
                guard let self = self, !self.stopped, !self.paused, self.request === req else { return }
                if let result = result {
                    let text = result.bestTranscription.formattedString
                    if !text.isEmpty && text != self.lastText {
                        self.lastText = text
                        self.timer?.cancel()
                        let item = DispatchWorkItem { [weak self] in
                            guard let self = self, !self.paused, !self.stopped else { return }
                            let final = self.lastText
                            self.end()
                            if !final.isEmpty { emit(["type":"text","text":final]) }
                            DispatchQueue.main.asyncAfter(deadline:.now()+0.4) { self.start() }
                        }
                        self.timer = item
                        DispatchQueue.main.asyncAfter(deadline:.now()+0.9, execute:item)
                    }
                } else if error != nil {
                    self.end()
                    DispatchQueue.main.asyncAfter(deadline:.now()+1) { self.start() }
                }
            }
        }
    }
    func command(_ command: [String: Any]) {
        if command["command"] as? String == "quit" { stopped = true; end(); exit(0) }
        if command["command"] as? String == "pause" {
            paused = command["value"] as? Bool ?? false
            if paused { end() } else { start() }
        }
    }
}
let worker = SpeechWorker(locale: CommandLine.arguments.dropFirst().first ?? "it-IT")
DispatchQueue.global(qos:.utility).async {
    while let line = readLine() {
        if let data = line.data(using:.utf8), let obj = try? JSONSerialization.jsonObject(with:data) as? [String:Any] {
            DispatchQueue.main.async { worker.command(obj) }
        }
    }
    DispatchQueue.main.async { worker.command(["command":"quit"]) }
}
SFSpeechRecognizer.requestAuthorization { status in
    DispatchQueue.main.async {
        if status == .authorized { worker.start() }
        else { emit(["type":"error","message":"Autorizza Riconoscimento vocale e Microfono nelle impostazioni Privacy del Mac."]); exit(1) }
    }
}
RunLoop.main.run()
