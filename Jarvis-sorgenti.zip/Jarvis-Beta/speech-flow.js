(function(root){
 class SpeechFlow{
  constructor(){this.queue=[];this.active=null;this.saved=[];this.serial=0;}
  push(text){if(typeof text==='string'&&text.trim())this.queue.push({id:++this.serial,text});}
  take(){this.active=this.queue.shift()||null;return this.active;}
  finish(id){if(this.active?.id===id)this.active=null;}
  interrupt(){const remaining=[...(this.active?[this.active.text]:[]),...this.queue.map(x=>x.text)];if(remaining.length)this.saved=remaining;this.active=null;this.queue=[];return remaining.length;}
  resume(){const saved=this.saved.slice();this.saved=[];for(const text of saved)this.push(text);return saved.length;}
  get length(){return this.queue.length;}
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={SpeechFlow};else root.SpeechFlow=SpeechFlow;
})(typeof window==='undefined'?globalThis:window);
