const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const QRCode = require('qrcode');
class PhoneGateway {
  constructor({ invoke, root }) { this.invoke = invoke; this.root = root; this.server = null; this.listeners = new Set(); this.devices = new Set(); this.secret = null; this.port = 0; }
  addresses() { return Object.values(os.networkInterfaces()).flat().filter(a => a && a.family === 'IPv4' && !a.internal).map(a => a.address); }
  event(type, data) { for (const response of this.listeners) { try { response.write('data: ' + JSON.stringify({ type, data }) + '\n\n'); } catch { this.listeners.delete(response); } } }
  async pairing() { if (!this.server) return { enabled: false }; const urls = this.addresses().map(ip => `http://${ip}:${this.port}/#${this.secret}`); return { enabled: true, urls, qr: urls[0] ? await QRCode.toDataURL(urls[0], { width: 220, margin: 2 }) : null, limitation: 'Funziona sulla stessa rete mentre il PC è acceso. Sul telefono usa testo o dettatura della tastiera; il microfono web diretto richiede HTTPS.' }; }
  async start() {
    if (this.server) return this.pairing();
    this.secret = crypto.randomBytes(32).toString('base64url');
    this.server = http.createServer((req, res) => { this.handle(req, res).catch(() => { if (!res.headersSent) this.json(res, 500, { error: 'Richiesta non completata.' }); else res.end(); }); });
    await new Promise((resolve, reject) => { this.server.once('error', reject); this.server.listen(0, '0.0.0.0', resolve); });
    this.port = this.server.address().port; return this.pairing();
  }
  json(res, status, value) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); }
  async body(req) { let size = 0; const parts = []; for await (const part of req) { size += part.length; if (size > 100000) throw new Error('Richiesta troppo grande'); parts.push(part); } return JSON.parse(Buffer.concat(parts).toString('utf8') || '{}'); }
  async handle(req, res) {
    const host = String(req.headers.host || '');
    const allowed = new Set([...this.addresses(), '127.0.0.1', 'localhost']);
    let url; try { url = new URL('http://' + host + req.url); } catch { return this.json(res, 400, { error: 'Indirizzo non valido' }); }
    if (!allowed.has(url.hostname) || (req.headers.origin && req.headers.origin !== 'http://' + host)) return this.json(res, 403, { error: 'Origine non consentita' });
    if (url.pathname === '/pair' && req.method === 'POST') {
      const { token } = await this.body(req); if (typeof token !== 'string' || token !== this.secret) return this.json(res, 403, { error: 'Associazione non valida. Scansiona il codice mostrato sul PC.' });
      const device = crypto.randomBytes(32).toString('base64url'); this.devices.add(device); res.setHeader('Set-Cookie', `JarvisDevice=${device}; HttpOnly; SameSite=Strict; Path=/`); return this.json(res, 200, { paired: true });
    }
    const cookie = req.headers.cookie?.match(/(?:^|;\s*)JarvisDevice=([^;]+)/)?.[1];
    const paired = cookie && this.devices.has(cookie);
    if (url.pathname === '/events') {
      if (!paired) return this.json(res, 401, { error: 'Associazione richiesta' });
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' }); res.write(': connected\n\n'); this.listeners.add(res); req.on('close', () => this.listeners.delete(res)); return;
    }
    if (url.pathname === '/rpc' && req.method === 'POST') {
      if (!paired) return this.json(res, 401, { error: 'Associazione richiesta' });
      const { method, args } = await this.body(req);
      const allowedMethods = new Set(['conversation-control','pause-routine','activities', 'get-state', 'load-memory', 'knowledge-status', 'send-message', 'cancel', 'get-settings', 'save-settings', 'refresh-knowledge', 'source-text']);
      if (!allowedMethods.has(method) || !Array.isArray(args) || args.length > 2) return this.json(res, 400, { error: 'Operazione non disponibile da telefono.' });
      try { return this.json(res, 200, { result: await this.invoke(method, ...args) }); } catch (e) { return this.json(res, 400, { error: String(e.message || 'Operazione non completata.').slice(0, 400) }); }
    }
    const files = { '/': 'index.html', '/styles.css': 'styles.css', '/orb.css': 'orb.css', '/reactor.css': 'reactor.css', '/app.js': 'app.js', '/phone-bridge.js': 'phone-bridge.js', '/audio-capture.js':'audio-capture.js','/audio-worklet.js':'audio-worklet.js','/speech-flow.js':'speech-flow.js', '/orb-scene.js': 'orb-scene.js' };
    const file = files[url.pathname]; if (!file || !['GET', 'HEAD'].includes(req.method)) return this.json(res, 404, { error: 'Non trovato' });
    const body = await fs.readFile(path.join(this.root, file));
    res.writeHead(200, { 'Content-Type': file.endsWith('.js') ? 'text/javascript; charset=utf-8' : file.endsWith('.css') ? 'text/css; charset=utf-8' : 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'" }); res.end(req.method === 'HEAD' ? undefined : body);
  }
  async stop() { for (const response of this.listeners) response.end(); this.listeners.clear(); this.devices.clear(); this.secret = null; if (this.server) { const server = this.server; this.server = null; server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); } }
}
module.exports = { PhoneGateway };
