(function(root){
 const norm=text=>String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.!?]+$/,'').trim();
 function isHideMedia(text,visible=true){const s=norm(text).replace(/^(?:jarvis[, ]*)/,'');if(/^(?:non|don't|don’t|do not|never)\b/.test(s))return false;return /^(?:nascondi|chiudi|togli|leva|rimuovi|hide|close|remove|dismiss)\b.*\b(?:immagine|immagini|foto|image|picture|photo)\b/.test(s)||visible&&/^(?:nascondila|chiudila|toglila|levala|levamela|toglimela|hide it|close it|dismiss it)$/.test(s);}
 const api={isHideMedia};if(typeof module==='object'&&module.exports)module.exports=api;else root.jarvisMediaCommands=api;
})(typeof window==='object'?window:globalThis);
