"""Explicit audio upload from an authenticated paired phone. Never save audio."""
import io,sys,json,os,importlib.util
import numpy as np
from faster_whisper.audio import decode_audio
spec=importlib.util.spec_from_file_location('speech_recognizer',os.path.join(os.path.dirname(__file__),'speech-recognizer.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
SpeechRecognizer=module.SpeechRecognizer
data=sys.stdin.buffer.read(15*1024*1024+1)
if len(data)>15*1024*1024:raise ValueError('Audio oltre 15 MB')
samples=decode_audio(io.BytesIO(data),sampling_rate=16000)
if len(samples)>16000*90:raise ValueError('Registra meno di 90 secondi')
pcm=(np.clip(samples,-1,1)*32767).astype(np.int16).tobytes()
result=SpeechRecognizer(sys.argv[1]).transcribe(pcm,language='auto')
print(json.dumps({'text':result.get('text','')},ensure_ascii=False))
