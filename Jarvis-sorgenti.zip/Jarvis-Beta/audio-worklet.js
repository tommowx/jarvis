class JarvisCapture extends AudioWorkletProcessor {
 constructor(){super();this.buffer=new Int16Array(1600);this.used=0;this.phase=0;this.sum=0;this.count=0;}
 process(inputs){const channel=inputs[0]?.[0];if(channel){for(let i=0;i<channel.length;i++){this.sum+=channel[i];this.count++;this.phase+=16000;if(this.phase>=sampleRate){this.phase-=sampleRate;const value=Math.max(-1,Math.min(1,this.sum/this.count));this.sum=0;this.count=0;this.buffer[this.used++]=Math.round(value*32767);if(this.used===this.buffer.length){this.port.postMessage(this.buffer.buffer,[this.buffer.buffer]);this.buffer=new Int16Array(1600);this.used=0;}}}}return true;}
}
registerProcessor('jarvis-capture',JarvisCapture);
