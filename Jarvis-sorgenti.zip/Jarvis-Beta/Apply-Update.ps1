param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$Stage,[int]$OldPid,[string]$Version,[switch]$ShowWindow)
$ErrorActionPreference='Stop'
$expected=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'JarvisBeta'))
$Root=[IO.Path]::GetFullPath($Root);$Stage=[IO.Path]::GetFullPath($Stage)
if($Root -ne $expected -or (Split-Path $Stage) -ne $Root -or (Split-Path $Stage -Leaf) -notmatch '^update-[A-Za-z0-9]+$' -or $Version -notmatch '^\d+\.\d+\.\d+$'){exit 2}
$appPath=Join-Path $Root 'App';$health=Join-Path $Root ('updates\health-'+$Version+'.json');$replaced=@();$saved=@();$process=$null
try {
 if(Test-Path -LiteralPath $health){Remove-Item -LiteralPath $health}
 if($OldPid -gt 0){Wait-Process -Id $OldPid -Timeout 120 -ErrorAction SilentlyContinue;if(Get-Process -Id $OldPid -ErrorAction SilentlyContinue){throw 'Jarvis ancora in esecuzione.'}}
 if(!(Test-Path -LiteralPath (Join-Path $Stage 'App\Jarvis.exe'))){throw 'Programma candidato assente.'}
 foreach($name in @('App','voice','documents')){
  $candidate=Join-Path $Stage $name;if(!(Test-Path -LiteralPath $candidate)){continue}
  $target=Join-Path $Root $name;$backup=Join-Path $Stage ('Previous-'+$name)
  if(Test-Path -LiteralPath $target){Move-Item -LiteralPath $target -Destination $backup;$saved+=@($name)}
  Move-Item -LiteralPath $candidate -Destination $target;$replaced+=@($name)
 }
 $startOptions=@{FilePath=(Join-Path $appPath 'Jarvis.exe');PassThru=$true};if(!$ShowWindow){$startOptions.ArgumentList='--background';$startOptions.WindowStyle='Hidden'};$process=Start-Process @startOptions
 $ok=$false
 for($i=0;$i -lt 90;$i++){Start-Sleep -Seconds 1;if(Test-Path -LiteralPath $health){$h=Get-Content -LiteralPath $health -Raw|ConvertFrom-Json;if($h.version -eq $Version -and $h.pid -eq $process.Id){$ok=$true;break}};if($process.HasExited){break}}
 if(!$ok){throw 'Avvio non verificato.'}
 if(Test-Path -LiteralPath (Join-Path $Stage 'components.json')){Copy-Item -LiteralPath (Join-Path $Stage 'components.json') -Destination (Join-Path $Root 'updates\components.json') -Force}
 @{version=$Version;installedAt=(Get-Date).ToString('o');backup=(Join-Path $Stage 'Previous-App')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Root 'updates\last-install.json') -Encoding UTF8
} catch {
 $failure=$_.Exception.Message
 if($process -and !$process.HasExited){Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue;Start-Sleep -Milliseconds 500}
 foreach($name in @('documents','voice','App')){
  $target=Join-Path $Root $name
  if($replaced -contains $name){Move-Item -LiteralPath $target -Destination (Join-Path $Stage ('Failed-'+$name))}
  if($saved -contains $name){Move-Item -LiteralPath (Join-Path $Stage ('Previous-'+$name)) -Destination $target}
 }
 if($saved -contains 'App'){Start-Process -FilePath (Join-Path $appPath 'Jarvis.exe') -ArgumentList '--background' -WindowStyle Hidden}
 $failure|Set-Content -LiteralPath (Join-Path $Stage 'update-error.txt') -Encoding UTF8;exit 1
}
