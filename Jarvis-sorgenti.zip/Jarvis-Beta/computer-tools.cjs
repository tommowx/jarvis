const fs = require('node:fs/promises');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {randomUUID} = require('node:crypto');
const {redact} = require('./vault-memory.cjs');
const {guardText,negativeAction}=require('./request-language.cjs');
const {DocumentReader} = require('./document-reader.cjs');
class ComputerTools {
 constructor({shell,emit,getSettings}){Object.assign(this,{shell,emit,getSettings});this.backups=path.join(process.env.APPDATA,'Jarvis Beta','computer-backups');}
 catalog(){const entries=[
 {name:'system_volume',description:'Legge o modifica il volume generale di Windows e il muto con verifica reale. Per il solo volume della voce Jarvis usa set_voice.',args:{volume:'numero 0–100 facoltativo',muted:'booleano facoltativo'}},
 {name:'system_diagnostics',description:'Legge RAM, spazio dischi e processi con maggior memoria. CPU dei processi cumulativa dall’avvio, non percentuale istantanea. Non chiude processi.',args:{}},
 {name:'foreground_context',description:'Legge PID e titolo della finestra attualmente in primo piano, per capire questa finestra. Nessuno screenshot.',args:{}},
 {name:'explorer_selection',description:'Legge i file attualmente selezionati nelle finestre Esplora file aperte. Non inventare quale file è questo se ci sono più candidati.',args:{}},
 {name:'find_files',description:'Cerca file personali per nome, estensione e giorno di modifica (today,yesterday,week,any). Limita la scansione; restituisce soltanto file reali.',args:{root:'desktop|downloads|documents oppure cartella assoluta',query:'parole nel nome',extension:'pdf o altro, facoltativo',modified:'today|yesterday|week|any'}},
 {name:'installed_apps',description:'Cerca le app realmente installate in Windows.',args:{query:'nome, oppure stringa vuota per elenco'}},
 {name:'launch_installed',description:'Apre un’app installata cercandone il nome; se ambiguo restituisce le alternative senza inventare.',args:{query:'nome app'}},
 {name:'list_windows',description:'Elenca finestre visibili con titolo, processo e PID.',args:{}},
 {name:'window_control',description:'Attiva, minimizza, ingrandisce, chiude o dispone una finestra su monitor scelto. Usa prima list_windows per ottenere PID reale.',args:{pid:'numero reale',title:'titolo esatto da list_windows',action:'focus|minimize|maximize|close|place',monitor:'1 o 2',layout:'full|left|right'}},
 {name:'inspect_window',description:'Legge i nomi dei controlli visibili e non riservati di una finestra tramite accessibilità Windows. Non analizza immagini e non legge campi password.',args:{pid:'PID da list_windows',title:'titolo esatto da list_windows'}},
 {name:'click_control',description:'Attiva un controllo della finestra usando il suo indice reale restituito da inspect_window. Preferisce l’accessibilità Windows a coordinate inventate.',args:{pid:'PID reale',title:'titolo esatto da list_windows, necessario se ci sono più finestre',index:'indice reale del controllo'}},
 {name:'type_text',description:'Scrive testo in una finestra attivandola, attraverso incolla. Non inviare messaggi ad altre persone senza richiesta esplicita.',args:{pid:'PID reale',title:'titolo esatto da list_windows, necessario se ci sono più finestre',text:'testo da scrivere'}},
 {name:'press_keys',description:'Invia una scorciatoia a una finestra attivata. Sintassi SendKeys: ^l Ctrl+L, ^s Ctrl+S, {ENTER}, {TAB}, %{F4}.',args:{pid:'PID reale',title:'titolo esatto da list_windows, necessario se ci sono più finestre',keys:'sequenza entro 80 caratteri'}},
 {name:'pc_files',description:'Legge/scrive/copia file con verifica, crea cartelle o Cestino esplicito. backups elenca scritture annullabili; restore ripristina un backupId reale solo se il file non è stato modificato dopo. Non modifica sorgenti Jarvis.',args:{action:'list|read|mkdir|write|copy|trash|backups|restore',path:'percorso assoluto',destination:'percorso per copy',text:'contenuto per write',backupId:'id reale da backups'}},
 {name:'windows_command',description:'Esegue un comando PowerShell per il compito Windows richiesto, con i permessi dell’utente e timeout 45 secondi. Niente elevazione automatica, disattivazione protezioni, cancellazioni permanenti/ricorsive, invio a terzi o estrazione di credenziali. Usa strumenti tipizzati quando disponibili.',args:{script:'script PowerShell',cwd:'cartella assoluta facoltativa'}}
 ];return process.platform==='darwin'?entries.filter(e=>!['windows_command','press_keys','click_control','explorer_selection'].includes(e.name)).map(e=>e.name==='inspect_window'?{...e,description:'Legge il titolo della finestra macOS; non espone ancora l’albero dei controlli.'}:e):entries;}
 ps(data,signal){return new Promise((resolve,reject)=>{
  const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-STA','-File',path.join(__dirname,'computer-worker.ps1')],{windowsHide:true,stdio:['pipe','pipe','pipe'],signal});let out='',err='',done=false;
  const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);error?reject(error):resolve(value);};
  const timer=setTimeout(()=>{child.kill();finish(new Error('Comando interrotto dopo 45 secondi; eventuali azioni già eseguite restano applicate.'));},45000);
  child.stdin.on('error',()=>{});child.stdin.end(JSON.stringify(data),'utf8');child.stdout.on('data',v=>{out+=v.toString('utf8');if(out.length>160000){child.kill();finish(new Error('Output eccessivo: restringi il comando.'));}});child.stderr.on('data',v=>{err=(err+v).slice(-3000);});
  child.on('error',e=>finish(e));child.on('exit',code=>{if(code!==0)return finish(new Error(redact(err||'Comando Windows non completato.').slice(0,500)));try{finish(null,JSON.parse(out.replace(/^\uFEFF/,'').trim()));}catch{finish(null,{output:redact(out).slice(0,14000)});}});
 });}
 async filePath(value,create=false){
  if(typeof value!=='string'||!path.isAbsolute(value)||value.length>500)throw new Error('Serve un percorso assoluto reale.');
  const target=path.resolve(value);let real;
  if(create){const parent=await fs.realpath(path.dirname(target));real=path.join(parent,path.basename(target));try{const info=await fs.lstat(target);if(info.isSymbolicLink())throw new Error('Destinazione collegata non ammessa.');real=await fs.realpath(target);}catch(e){if(e.code!=='ENOENT')throw e;}}
  else real=await fs.realpath(target);
  const lower=real.toLowerCase();const protectedRoots=[...(process.platform==='darwin'?['/System','/Library','/Applications','/usr','/bin','/sbin',process.resourcesPath]:[]),process.env.WINDIR,process.env.ProgramFiles,process.env['ProgramFiles(x86)'],path.join(process.env.LOCALAPPDATA,'JarvisBeta','App'),path.join(require('node:os').homedir(),'Documents','Codex','Jarvis-Beta')].filter(Boolean);
  if(real===path.parse(real).root||protectedRoots.some(root=>lower===root.toLowerCase()||lower.startsWith(root.toLowerCase()+path.sep)))throw new Error('Percorso di sistema o del programma: usa gli strumenti dedicati.');
  if(/(?:^|[\\/])(?:\.ssh|\.aws|\.env(?:\.[^\\/]*)?|credentials?|cookies|login data|local state|chatgpt-auth\.json|.*\.(?:key|pem|pfx))(?=[\\/]|$)/i.test(real))throw new Error('File riservato non disponibile per questi strumenti.');
  return real;
 }
 async files(args,user){
  user=guardText(user);
  if(args.action==='backups'){const items=[];for(const name of await fs.readdir(this.backups).catch(()=>[])){if(!/^[a-f0-9-]{36}$/.test(name))continue;try{const data=JSON.parse(await fs.readFile(path.join(this.backups,name,'restore.json'),'utf8'));if(data.afterHash&&!data.restoredAt)items.push({id:name,path:data.path,at:data.at});}catch{}}return{backups:items.sort((a,b)=>b.at.localeCompare(a.at)).slice(0,30)};}
  if(args.action==='restore'){
   if(/\bnon\s+(?:annull|ripristin)/i.test(user)||!/annulla|ripristina|torna indietro/i.test(user))throw new Error('Ripristino non richiesto.');
   if(!/^[a-f0-9-]{36}$/.test(args.backupId||''))throw new Error('Identificativo backup non valido.');
   const folder=path.join(this.backups,args.backupId),manifest=path.join(folder,'restore.json');const data=JSON.parse(await fs.readFile(manifest,'utf8'));
   if(data.restoredAt||!data.afterHash||!data.beforeHash)throw new Error('Backup già usato o senza verifica: file conservati.');
   const target=await this.filePath(data.path),hash=b=>require('node:crypto').createHash('sha256').update(b).digest('hex');
   const current=await fs.readFile(target);if(hash(current)!==data.afterHash)throw new Error('Il file è cambiato dopo la scrittura: ripristino bloccato per conservare le modifiche nuove.');
   const original=await fs.readFile(path.join(folder,'original'));if(hash(original)!==data.beforeHash)throw new Error('Backup alterato: nessun ripristino.');
   await fs.writeFile(target,original);if(hash(await fs.readFile(target))!==data.beforeHash)throw new Error('Ripristino non verificato; backup conservato.');data.restoredAt=new Date().toISOString();await fs.writeFile(manifest,JSON.stringify(data));return{restored:target,verified:true,backupId:args.backupId};
  }
  const action=args.action, target=await this.filePath(args.path,['write','mkdir','copy'].includes(action));
  if(action==='list'){const items=await fs.readdir(target,{withFileTypes:true});return{path:target,items:items.filter(e=>!e.name.startsWith('.')).slice(0,150).map(e=>({name:e.name,directory:e.isDirectory()})),truncated:items.length>150};}
  if(action==='read'){if(/\.(pdf|docx|xlsx)$/i.test(target))return {path:target,...await new DocumentReader().read(target)};const stat=await fs.stat(target);if(!stat.isFile()||stat.size>512*1024||! /\.(txt|md|json|csv|js|ts|cjs|mjs|py|css|html|xml|yaml|yml|toml|log|ini)$/i.test(target))throw new Error('File testuale non supportato o oltre 512 KB.');return{path:target,text:redact((await fs.readFile(target,'utf8')).slice(0,22000))};}
  if(!/crea|scrivi|salva|copia|sposta|rinomina|elimina|cancella|cestino|modifica|organizza|sistema|metti|aggiungi|aggiorna/i.test(user))throw new Error('Operazione sui file non richiesta.');
  if(action==='mkdir'){await fs.mkdir(target);return{created:target};}
  if(action==='write'){
   if(typeof args.text!=='string'||args.text.length>150000)throw new Error('Testo non valido o troppo lungo.');
   let backup=null;const stat=await fs.stat(target).catch(()=>null);
   if(stat){if(!stat.isFile()||stat.size>10*1024*1024)throw new Error('Il file esistente non è sostituibile da questo strumento.');backup=path.join(this.backups,randomUUID());await fs.mkdir(backup,{recursive:true});await fs.copyFile(target,path.join(backup,'original'));await fs.writeFile(path.join(backup,'restore.json'),JSON.stringify({path:target,at:new Date().toISOString()}));}
   await fs.writeFile(target,args.text,'utf8');const actual=await fs.readFile(target,'utf8');if(actual!==args.text)throw new Error('Scrittura eseguita ma verifica del contenuto fallita; backup conservato.');if(backup){const manifest=path.join(backup,'restore.json'),data=JSON.parse(await fs.readFile(manifest,'utf8'));const hash=b=>require('node:crypto').createHash('sha256').update(b).digest('hex');data.beforeHash=hash(await fs.readFile(path.join(backup,'original')));data.afterHash=hash(Buffer.from(actual));await fs.writeFile(manifest,JSON.stringify(data));}return{written:target,backup,backupId:backup?path.basename(backup):null,verified:true,bytes:Buffer.byteLength(actual)};
  }
  if(action==='copy'){const destination=await this.filePath(args.destination,true);const before=await fs.stat(target);if(!before.isFile()||before.size>100*1024*1024)throw new Error('Copia disponibile per singoli file fino a 100 MB.');await fs.copyFile(target,destination,require('node:fs').constants.COPYFILE_EXCL);const hash=async file=>require('node:crypto').createHash('sha256').update(await fs.readFile(file)).digest('hex');if(await hash(target)!==await hash(destination))throw new Error('Copia creata ma verifica del contenuto fallita.');return{copied:target,destination,verified:true,bytes:before.size};}
  if(action==='trash'){if(!/elimina|cancella|cestino|rimuovi/i.test(user)||!user.toLowerCase().includes(path.basename(target).toLowerCase()))throw new Error('Per il Cestino indica esplicitamente l’elemento da rimuovere.');await this.shell.trashItem(target);return{trashed:target,recoverable:'Cestino Windows, se supportato dall’unità'};}
  throw new Error('Azione file non disponibile.');
 }
 async findFiles(args){
  const home=require('node:os').homedir(),aliases={desktop:path.join(home,'Desktop'),downloads:path.join(home,'Downloads'),documents:path.join(home,'Documents')};const root=await this.filePath(aliases[args.root]||args.root);const query=String(args.query||'').toLowerCase().split(/\s+/).filter(Boolean),extension=String(args.extension||'').replace(/^\./,'').toLowerCase();const results=[],stack=[[root,0]];let visited=0,truncated=false;const started=Date.now();
  const key=date=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);const today=key(new Date()),yesterday=key(new Date(Date.now()-86400000));
  while(stack.length){if(visited>=5000||Date.now()-started>3500){truncated=true;break;}const [folder,depth]=stack.pop();const entries=await fs.readdir(folder,{withFileTypes:true}).catch(()=>[]);for(const entry of entries){if(entry.name.startsWith('.')||entry.isSymbolicLink())continue;const file=path.join(folder,entry.name);if(entry.isDirectory()){if(depth<5&&!['node_modules','AppData'].includes(entry.name))stack.push([file,depth+1]);continue;}visited++;if(!entry.isFile()||!query.every(word=>entry.name.toLowerCase().includes(word))||(extension&&path.extname(entry.name).toLowerCase()!=='.'+extension))continue;const info=await fs.stat(file).catch(()=>null);if(!info)continue;const day=key(info.mtime);if(args.modified==='today'&&day!==today||args.modified==='yesterday'&&day!==yesterday||args.modified==='week'&&Date.now()-info.mtimeMs>7*86400000)continue;results.push({path:file,name:entry.name,modifiedAt:info.mtime.toISOString(),bytes:info.size});if(results.length>=50){truncated=true;break;}}if(results.length>=50)break;}
  return{root,results,visited,truncated};
 }
 async execute(name,args,user,signal){ const entry={at:new Date().toISOString(),tool:name};try{const result=await this.perform(name,args,user,signal);entry.ok=true;return result;}catch(error){entry.ok=false;throw error;}finally{const log=path.join(process.env.APPDATA,'Jarvis Beta','computer-actions.jsonl');await fs.appendFile(log,JSON.stringify(entry)+'\n').catch(()=>{});} }
 async perform(name,args,user,signal){
  if(negativeAction(user))throw new Error('Richiesta negativa: nessuna azione eseguita.');
  const authorizedRequest=guardText(user);
  if(this.getSettings().privacy)throw new Error('Modalità riservata attiva: controllo del PC sospeso.');
  if(!this.getSettings().computerControl)throw new Error('Controllo del PC disattivato nelle impostazioni.');
  if(!args||typeof args!=='object'||Array.isArray(args))throw new Error('Parametri non validi.');
  if(name==='pc_files')return this.files(args,user);
  if(name==='find_files')return this.findFiles(args);
  if(process.platform==='darwin'){const readOnly=['installed_apps','list_windows','inspect_window','foreground_context','system_diagnostics'];if(!readOnly.includes(name)&&!(name==='system_volume'&&args.volume===undefined&&args.muted===undefined)&&!/apri|avvia|lancia|mostra|scrivi|digita|premi|clicca|sposta|metti|chiudi|riduci|ingrandisci|organizza|sistema|esegui|installa|aggiorna|controlla|verifica|cerca|leggi|salva|crea|modifica|imposta|alza|abbassa|silenzi|attiva|disattiva/i.test(authorizedRequest))throw Error('Manca una richiesta operativa.');return new(require('./mac-tools.cjs').MacTools)({shell:this.shell}).execute(name,args,user,signal);}
  if(name==='system_volume'){const change=args.volume!==undefined||args.muted!==undefined;if(change&&(!/volume|audio|suono|sound|mute|muto|silenzia/i.test(authorizedRequest)||!/imposta|alza|abbassa|silenzia|attiva|disattiva|metti|porta|set|lower|raise|mute|unmute/i.test(authorizedRequest)))throw new Error('Modifica volume di sistema non richiesta.');if(args.volume!==undefined&&(!Number.isFinite(args.volume)||args.volume<0||args.volume>100))throw new Error('Volume tra 0 e 100.');if(args.muted!==undefined&&typeof args.muted!=='boolean')throw new Error('Muto non valido.');return await new Promise((resolve,reject)=>{const c=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'system-audio.ps1')],{windowsHide:true});let out='',err='';const timer=setTimeout(()=>{c.kill();reject(Error('Audio Windows non disponibile.'));},15000);c.on('error',e=>{clearTimeout(timer);reject(e)});c.stdin.end(JSON.stringify(args));c.stdout.on('data',b=>out+=b);c.stderr.on('data',b=>err+=b);c.on('exit',code=>{clearTimeout(timer);try{if(code)throw Error(err.slice(0,200));resolve(JSON.parse(out));}catch(e){reject(e)}});});}
  const readOnly=['installed_apps','list_windows','inspect_window','foreground_context','explorer_selection','system_diagnostics'];
  if(!readOnly.includes(name)&&!/apri|avvia|lancia|mostra|scrivi|digita|premi|clicca|sposta|metti|chiudi|riduci|ingrandisci|organizza|sistema|esegui|installa|aggiorna|controlla|verifica|cerca|leggi|salva|crea|modifica/i.test(authorizedRequest))throw new Error('Manca una richiesta operativa dell’utente.');
  if(['window_control','inspect_window','type_text','press_keys','click_control'].includes(name)){if(!Number.isSafeInteger(args.pid)||args.pid<=0||args.pid===process.pid)throw new Error('Scegli un PID reale da list_windows, diverso da Jarvis.');}
  if(name==='window_control'&&!['focus','minimize','maximize','close','place'].includes(args.action))throw new Error('Azione finestra non valida.');
  if(name==='click_control'&&(!Number.isInteger(args.index)||args.index<0||args.index>499))throw new Error('Indice controllo non valido.');
  if(name==='press_keys'&&(typeof args.keys!=='string'||args.keys.length>80))throw new Error('Sequenza tasti non valida.');
  if(name==='type_text'&&(typeof args.text!=='string'||args.text.length>12000))throw new Error('Testo non valido.');
  if(name==='windows_command'){
   const script=String(args.script||'');if(!script||script.length>14000)throw new Error('Comando non valido.');
   if(/remove-item|\b(?:del|erase|rmdir|rd|move-item)\b|format-volume|clear-disk|diskpart|bcdedit|set-mppreference|disable.*(?:defender|firewall)|start-process[^\n]*-verb\s+runas|(?:credential|password|token|cookies|login data|local state)|invoke-expression|\biex\b|encodedcommand/i.test(script))throw new Error('Questo comando richiede un’operazione specifica diversa: usa file/Cestino, evita elevazione, credenziali e protezioni di Windows.');
   if(args.cwd)args.cwd=await this.filePath(args.cwd);
  }
  const result=await this.ps({...args,operation:name},signal);
  const clean=redact(JSON.stringify(result));return clean.length>100000?{output:clean.slice(0,18000),truncated:true}:JSON.parse(clean);
 }
}
module.exports={ComputerTools};
