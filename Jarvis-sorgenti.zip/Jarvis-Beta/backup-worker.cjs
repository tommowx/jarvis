const {parentPort,workerData}=require('node:worker_threads');
require('./rescue-backup.cjs').createBackup({...workerData,onStage:file=>parentPort.postMessage({stage:file}),onProgress:progress=>parentPort.postMessage({progress})}).then(result=>parentPort.postMessage({result})).catch(error=>parentPort.postMessage({error:error.message}));
