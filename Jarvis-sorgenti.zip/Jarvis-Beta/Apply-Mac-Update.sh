#!/bin/bash
set -euo pipefail
bundle="$1"; stage="$2"; oldpid="$3"; data="$4"; version="$5"; visibility="$6"
[[ "$bundle" == /*.app && "$stage" == /* && "$data" == /* && "$oldpid" =~ ^[0-9]+$ && "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 2
[[ -d "$stage/Jarvis.app" && -f "$stage/apply.sh" && ! -e "$stage/Previous.app" ]] || exit 3
for ((i=0;i<30;i++)); do if ! kill -0 "$oldpid" 2>/dev/null; then break; fi; sleep 1; done
if kill -0 "$oldpid" 2>/dev/null; then exit 4; fi
/usr/bin/codesign --verify --deep --strict "$stage/Jarvis.app"
mkdir -p "$data/updates"
health="$data/updates/health-$version.json"
if [[ -e "$health" ]]; then mv "$health" "$stage/previous-health.json"; fi
mv "$bundle" "$stage/Previous.app"
if ! mv "$stage/Jarvis.app" "$bundle"; then mv "$stage/Previous.app" "$bundle"; exit 5; fi
executable=$(/usr/libexec/PlistBuddy -c "Print :CFBundleExecutable" "$bundle/Contents/Info.plist")
if [[ "$visibility" == visible ]]; then "$bundle/Contents/MacOS/$executable" >/dev/null 2>&1 & else "$bundle/Contents/MacOS/$executable" --background >/dev/null 2>&1 & fi
newpid=$!
for ((i=0;i<90;i++)); do if [[ -f "$health" ]]; then printf '%s\n' "$version" > "$data/updates/mac-installed.txt"; exit 0; fi; sleep 1; done
# No success acknowledgement: stop only the new executable from this exact bundle.
kill "$newpid" 2>/dev/null || true
mv "$bundle" "$stage/Failed.app"
mv "$stage/Previous.app" "$bundle"
/usr/bin/open "$bundle"
exit 6
