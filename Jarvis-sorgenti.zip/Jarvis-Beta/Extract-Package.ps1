param([string]$Zip,[string]$Stage,[ValidateSet('App','voice','documents')][string]$Top)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stageRoot=[IO.Path]::GetFullPath($Stage).TrimEnd('\')+'\'
$archive=[IO.Compression.ZipFile]::OpenRead($Zip)
try{
 $size=0L;if($archive.Entries.Count -gt 25000){throw 'Troppi file nel pacchetto.'}
 foreach($entry in $archive.Entries){$target=[IO.Path]::GetFullPath((Join-Path $Stage $entry.FullName));$size+=$entry.Length;if($size -gt 12000000000 -or !$entry.FullName.StartsWith($Top+'/') -or !$target.StartsWith($stageRoot,[StringComparison]::OrdinalIgnoreCase) -or $entry.FullName.Contains(':') -or $entry.FullName.Contains('\') -or $entry.FullName.Split('/') -contains '..'){throw 'Percorso nel pacchetto non valido.'}}
}finally{$archive.Dispose()}
[IO.Compression.ZipFile]::ExtractToDirectory($Zip,$Stage)
