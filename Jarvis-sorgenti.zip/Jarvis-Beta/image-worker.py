import os,sys,json,time
from pathlib import Path
def send(data):print(json.dumps(data,ensure_ascii=False),flush=True)
try:
 request=json.loads(sys.stdin.readline());prompt=request['prompt']
 if not isinstance(prompt,str) or not 1<=len(prompt)<=1200:raise ValueError('Descrizione immagine non valida.')
 root=Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'images'
 output=Path(request['output']).resolve()
 if output.parent!= (root/'generated').resolve() or output.suffix.lower()!='.png':raise ValueError('Destinazione immagine non valida.')
 send({'status':'Preparo il modello immagini...'})
 import torch
 from diffusers import StableDiffusionPipeline
 started=time.monotonic();cuda=torch.cuda.is_available();dtype=torch.float16 if cuda else torch.float32
 pipe=StableDiffusionPipeline.from_pretrained(str(root/'model'),torch_dtype=dtype,variant='fp16',use_safetensors=True,local_files_only=True)
 pipe.set_progress_bar_config(disable=True);pipe.enable_attention_slicing('max');pipe.enable_vae_slicing()
 if cuda:pipe.enable_sequential_cpu_offload()
 else:pipe.to('cpu');torch.set_num_threads(4)
 send({'status':'Genero la tua immagine...','device':'cuda' if cuda else 'cpu'})
 def step(pipe,index,timestep,kwargs):send({'status':'Genero la tua immagine...','step':index+1,'total':2});return kwargs
 image=pipe(prompt=prompt,num_inference_steps=2,guidance_scale=0.0,width=512,height=512,callback_on_step_end=step).images[0]
 output.parent.mkdir(parents=True,exist_ok=True);image.save(output)
 send({'done':True,'file':str(output),'device':'cuda-offload' if cuda else 'cpu','seconds':round(time.monotonic()-started,1),'width':512,'height':512,'model':'SD-Turbo'})
except Exception as error:
 send({'error':str(error)[:700]});sys.exit(1)
