const fs=require('node:fs/promises'),path=require('node:path');
const TYPES=new Set(['chatgpt','openai','anthropic','ollama','compatible']);
function validate(config){
 const c={type:config?.type,model:String(config?.model||'').trim(),endpoint:String(config?.endpoint||'').trim(),key:String(config?.key||'').trim(),shareMemory:config?.shareMemory===true};
 if(!TYPES.has(c.type))throw Error('Tipo di collegamento non valido.');
 if(c.type==='chatgpt')return{type:'chatgpt'};
 if(!c.shareMemory)throw Error('Autorizza l’uso della memoria con il modello scelto.');
 if(!c.model||c.model.length>160||/[\x00-\x1f]/.test(c.model))throw Error('Indica il nome esatto del modello.');
 if(c.key.length>1000||/[\r\n]/.test(c.key))throw Error('Chiave non valida.');
 if(c.type==='openai')c.endpoint='https://api.openai.com/v1';
 if(c.type==='anthropic')c.endpoint='https://api.anthropic.com/v1';
 if(c.type==='ollama'&&!c.endpoint)c.endpoint='http://127.0.0.1:11434';
 let u;try{u=new URL(c.endpoint);}catch{throw Error('Indirizzo del servizio non valido.');}
 const local=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
 if(u.username||u.password||u.search||u.hash||!(u.protocol==='https:'||(local&&u.protocol==='http:')))throw Error('Usa HTTPS, oppure HTTP soltanto per un modello sul PC.');
 if(['openai','anthropic'].includes(c.type)&&!c.key)throw Error('Serve la chiave API del servizio scelto.');
 c.endpoint=u.href.replace(/\/$/,'');return c;
}
class ProviderHub{
 constructor({chatgpt,file,encrypt,decrypt,fetcher=fetch}){Object.assign(this,{chatgpt,file,encrypt,decrypt,fetcher});this.config={type:'chatgpt'};this.profiles={};this.queue=Promise.resolve();}
 async init(){try{const saved=JSON.parse(this.decrypt(await fs.readFile(this.file)));this.profiles=saved.profiles||{};this.config=saved.active==='chatgpt'?{type:'chatgpt'}:validate(this.profiles[saved.active]);}catch(e){if(e.code!=='ENOENT')this.loadError='Configurazione AI non leggibile: conservata senza modifiche.';}return this;}
 publicConfig(){const {key,...c}=this.config;return{...c,hasKey:Boolean(key),loadError:this.loadError||null,profiles:Object.values(this.profiles).map(({type,model,endpoint})=>({type,model,endpoint}))};}
 async persist(){await fs.mkdir(path.dirname(this.file),{recursive:true});await fs.writeFile(this.file+'.next',this.encrypt(JSON.stringify({active:this.config.type,profiles:this.profiles})));await fs.rename(this.file+'.next',this.file);}
 async configure(raw,{probe=true}={}){const operation=this.queue.then(async()=>{const previous=this.config;const saved=this.profiles[raw?.type];const reuse=saved&&(['openai','anthropic'].includes(raw?.type)||String(raw?.endpoint||'').replace(/\/$/,'')===saved.endpoint);const candidate=validate({...raw,key:raw?.key||(reuse?saved.key:'')||''});if(candidate.type!=='chatgpt'&&probe)await this.request(candidate,{instructions:'Reply with OK.',input:[{role:'user',content:'Connection test. Reply only OK.'}],signal:AbortSignal.timeout(30000)});this.config=candidate;if(candidate.type!=='chatgpt')this.profiles[candidate.type]=candidate;try{await this.persist();}catch(e){this.config=previous;throw e;}return this.publicConfig();});this.queue=operation.catch(()=>{});return operation;}
 subscribe(cb){return this.chatgpt.subscribe(cb);}
 async signIn(args){await this.configure({type:'chatgpt'},{probe:false});return this.chatgpt.signIn(args);}
 async disconnect(){if(this.config.type==='chatgpt')return this.chatgpt.disconnect();delete this.profiles[this.config.type];this.config={type:'chatgpt'};await this.persist();}
 async getSession(){if(this.config.type==='chatgpt')return{...await this.chatgpt.getSession(),provider:'ChatGPT'};return{status:'connected',sharing:true,provider:this.config.type,model:this.config.model};}
 async listModels(){return this.config.type==='chatgpt'?this.chatgpt.listModels():[{slug:this.config.model,name:this.config.model}];}
 streamResponse(args){const c=this.config;return c.type==='chatgpt'?this.chatgpt.streamResponse(args):this.request(c,args);}
 async request(c,{instructions,input,signal,onDelta}){
  const headers={'Content-Type':'application/json'},messages=(input||[]).filter(m=>['user','assistant'].includes(m.role)).map(m=>({role:m.role,content:String(m.content)}));let url,body;
  if(c.type==='anthropic'){url=c.endpoint+'/messages';headers['x-api-key']=c.key;headers['anthropic-version']='2023-06-01';body={model:c.model,system:instructions||'',messages,max_tokens:8192,stream:true};}
  else if(c.type==='openai'){url=c.endpoint+'/responses';headers.Authorization='Bearer '+c.key;body={model:c.model,instructions:instructions||'',input:messages,store:false,stream:true};}
  else {url=c.endpoint+(c.type==='ollama'?'/api/chat':'/chat/completions');if(c.key)headers.Authorization='Bearer '+c.key;body={model:c.model,messages:[{role:'system',content:instructions||''},...messages],stream:true};}
  let response;try{response=await this.fetcher(url,{method:'POST',redirect:'error',headers,body:JSON.stringify(body),signal:signal||AbortSignal.timeout(180000)});}catch(e){if(signal?.aborted)throw e;throw Error('Servizio AI non raggiungibile. Controlla indirizzo e connessione.');}
  if(!response.ok)throw Error('Il servizio AI ha rifiutato la richiesta (HTTP '+response.status+'). Controlla chiave, modello, credito e limiti.');
  let text='',buffer='',total=0;const decoder=new TextDecoder();const accept=obj=>{if(obj.error||obj.type==='error'||obj.type==='response.failed')throw Error('Il servizio AI ha interrotto la risposta.');let delta=c.type==='anthropic'?(obj.type==='content_block_delta'&&obj.delta?.type==='text_delta'?obj.delta.text:''):c.type==='openai'?(obj.type==='response.output_text.delta'?obj.delta:''):c.type==='ollama'?obj.message?.content:obj.choices?.[0]?.delta?.content;if(typeof delta==='string'&&delta){text+=delta;onDelta?.(delta);}};
  if(!response.body)throw Error('Risposta AI vuota.');
  for await(const chunk of response.body){total+=chunk.length;if(total>4*1024*1024)throw Error('Risposta AI troppo grande.');buffer+=decoder.decode(chunk,{stream:true});let n;while((n=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,n).trim();buffer=buffer.slice(n+1);const raw=c.type==='ollama'?line:line.startsWith('data:')?line.slice(5).trim():'';if(!raw||raw==='[DONE]')continue;let obj;try{obj=JSON.parse(raw);}catch{throw Error('Flusso AI non valido.');}accept(obj);}}
  buffer+=decoder.decode();if(c.type==='ollama'&&buffer.trim())accept(JSON.parse(buffer));if(!text.trim())throw Error('Il modello non ha restituito testo utilizzabile.');return{text};
 }
}
module.exports={ProviderHub,validate};
