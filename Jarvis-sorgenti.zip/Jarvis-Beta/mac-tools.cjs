const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),{execFile}=require('node:child_process'),{promisify}=require('node:util');
const run=promisify(execFile);
const SCRIPTS={
 foreground_context:`tell application "System Events"
set p to first application process whose frontmost is true
return ((unix id of p) as text) & tab & (name of p)
end tell`,
 list_windows:`set out to ""
tell application "System Events"
repeat with p in (application processes whose background only is false)
try
repeat with w in windows of p
set out to out & ((unix id of p) as text) & tab & (name of p) & tab & (name of w) & linefeed
end repeat
end try
end repeat
end tell
return out`,
 system_volume:`set v to get volume settings
return ((output volume of v) as text) & tab & ((output muted of v) as text)`,
 window_control:`on run argv
set pidValue to (item 1 of argv) as integer
set actionName to item 2 of argv
tell application "System Events"
set p to first application process whose unix id is pidValue
if actionName is "focus" then
set frontmost of p to true
else if actionName is "minimize" then
set value of attribute "AXMinimized" of front window of p to true
else if actionName is "close" then
click button 1 of front window of p
else
error "Azione finestra non disponibile nella beta Mac"
end if
end tell
return "ok"
end run`,
 type_text:`on run argv
set pidValue to (item 1 of argv) as integer
tell application "System Events"
set frontmost of (first application process whose unix id is pidValue) to true
keystroke (item 2 of argv)
end tell
return "ok"
end run`,
 inspect_window:`on run argv
tell application "System Events"
set p to first application process whose unix id is ((item 1 of argv) as integer)
return name of front window of p
end tell
end run`
};
class MacTools{
 constructor({runner=run,shell,clipboard}={}){this.run=runner;this.shell=shell;this.clipboard=clipboard;}
 async apple(script,args=[],signal){try{return(await this.run('/usr/bin/osascript',['-e',script,...args.map(String)],{timeout:15000,maxBuffer:100000,signal})).stdout.trim();}catch{throw Error('Controllo macOS non disponibile: verifica i permessi Accessibilità e Automazione di Jarvis nelle impostazioni del Mac.');}}
 async execute(name,args,user,signal){
  if(name==='system_volume'){if(args.volume!==undefined||args.muted!==undefined){if(args.volume!==undefined&&(!Number.isFinite(args.volume)||args.volume<0||args.volume>100))throw Error('Volume tra 0 e 100.');if(args.muted!==undefined&&typeof args.muted!=='boolean')throw Error('Muto non valido.');const changes=[];if(args.volume!==undefined)changes.push('set volume output volume '+Math.round(args.volume));if(args.muted!==undefined)changes.push('set volume output muted '+String(args.muted));await this.apple(changes.join('\n'),[],signal);}const [v,m]= (await this.apple(SCRIPTS.system_volume,[],signal)).split('\t');return{volume:Number(v),muted:m==='true',verified:true};}
  if(name==='system_diagnostics')return{platform:'macOS',memory:{total:os.totalmem(),free:os.freemem()},cpus:os.cpus().length,uptime:os.uptime()};
  if(name==='installed_apps'){const roots=['/Applications','/System/Applications',path.join(os.homedir(),'Applications')],apps=[];for(const root of roots)for(const item of await fs.readdir(root).catch(()=>[]))if(item.endsWith('.app')&&item.toLowerCase().includes(String(args.query||'').toLowerCase()))apps.push({name:item.slice(0,-4),path:path.join(root,item)});return{apps};}
  if(name==='launch_installed'){const query=String(args.query||'').trim();if(!query||query.length>120||query.startsWith('-'))throw Error('Nome app non valido.');await this.run('/usr/bin/open',['-a',query],{timeout:15000,signal});return{opened:query};}
  if(name==='foreground_context'){const [pid,name]= (await this.apple(SCRIPTS.foreground_context,[],signal)).split('\t');return{pid:Number(pid),name};}
  if(name==='list_windows')return{windows:(await this.apple(SCRIPTS.list_windows,[],signal)).split('\n').filter(Boolean).map(line=>{const [pid,app,title]=line.split('\t');return{pid:Number(pid),app,title};})};
  if(['window_control','type_text','inspect_window'].includes(name)){if(!Number.isSafeInteger(args.pid)||args.pid<=0||args.pid===process.pid)throw Error('Scegli un PID reale diverso da Jarvis.');if(name==='type_text'&&(typeof args.text!=='string'||args.text.length>12000))throw Error('Testo non valido.');if(name==='window_control'&&!['focus','minimize','close'].includes(args.action))throw Error('Nella beta Mac usa focus, minimize o close.');const result=await this.apple(SCRIPTS[name],[args.pid,name==='type_text'?args.text:args.action||''],signal);return{name,result,verified:false};}
  throw Error('Questo controllo non è ancora implementato nella beta macOS. Sono disponibili app, finestre di base, volume, file di testo e memoria.');
 }
}
module.exports={MacTools,SCRIPTS};
