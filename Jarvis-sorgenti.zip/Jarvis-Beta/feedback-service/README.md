# Raccolta feedback facoltativa

Il client raccoglie solo conteggi per categorie predefinite dopo consenso. Nessuna chat, nome utente, IP, chiave, percorso o contenuto dei file viene incluso nel report. Nessun identificativo persistente di installazione. Il servizio non aggiunge questi dati ai record; il provider di hosting può avere log di rete propri.

Il punto di raccolta non è attivo finché non viene distribuito e impostato in feedback-service.json. Il client senza endpoint non invia nulla. Per predisporlo su Cloudflare Workers con D1 occorre un account del proprietario: creare il database, applicare schema.sql e associarlo al binding REPORTS. Impostare ADMIN_TOKEN come segreto solo sul server. Non inserirlo nel client, nei sorgenti o nei report. Configurare limiti di richieste sul servizio pubblico.

POST /report accetta soltanto versione, sistema, architettura e conteggi di massimo cinque categorie. GET /summary richiede l’autorizzazione amministratore. Questi report non arrivano direttamente a una chat AI: il manutentore può consultarli tramite il servizio e usarli come dati per gli aggiornamenti.

Il piano gratuito e le quote dell’hosting vanno verificati prima della distribuzione. Non attivare fatturazione automaticamente. La gestione automatica dei feedback deve sempre restare visibile e revocabile nelle impostazioni.
