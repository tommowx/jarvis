CREATE TABLE IF NOT EXISTS reports (
 day TEXT NOT NULL, version TEXT NOT NULL, platform TEXT NOT NULL,
 arch TEXT NOT NULL, category TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(day,version,platform,arch,category)
);
