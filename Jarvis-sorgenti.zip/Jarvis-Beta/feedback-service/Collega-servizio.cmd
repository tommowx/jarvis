@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collega-servizio.ps1"
pause
