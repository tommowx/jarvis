param([string]$DatabaseId='')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
if(!(Get-Command npx.cmd -ErrorAction SilentlyContinue)){throw 'Serve Node.js sul PC del manutentore per collegare il servizio.'}
Write-Host 'Collegamento del servizio report al tuo account Cloudflare. Non attivare piani a pagamento.'
& npx.cmd --yes wrangler@4 login
if($LASTEXITCODE -ne 0){throw 'Completa l''accesso al tuo account prima di proseguire.'}
if(!$DatabaseId){
  $created=(& npx.cmd --yes wrangler@4 d1 create jarvis-feedback 2>&1 | Out-String)
  if($LASTEXITCODE -ne 0){throw 'Database non creato. Se esiste già, richiama lo script con -DatabaseId e il suo identificativo.'}
  $match=[regex]::Match($created,'["'']?database_id["'']?\s*[:=]\s*["'']([a-fA-F0-9-]{36})["'']')
  if(!$match.Success){throw 'Copia l''identificativo database dal pannello Cloudflare e richiama lo script con -DatabaseId.'}
  $DatabaseId=$match.Groups[1].Value
}
if($DatabaseId -notmatch '^[a-fA-F0-9-]{36}$'){throw 'Identificativo database non valido.'}
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'wrangler.template.jsonc') -Raw
$config.Replace('DA_CONFIGURARE',$DatabaseId) | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'wrangler.jsonc') -Encoding UTF8
& npx.cmd --yes wrangler@4 d1 execute jarvis-feedback --remote --file schema.sql --yes --config wrangler.jsonc
if($LASTEXITCODE -ne 0){throw 'Schema non applicato; distribuzione interrotta.'}
$result=(& npx.cmd --yes wrangler@4 deploy --config wrangler.jsonc 2>&1 | Out-String)
if($LASTEXITCODE -ne 0){throw 'Distribuzione non riuscita. Nessun endpoint è stato attivato nell''app.'}
$bytes=New-Object byte[] 32
$generator=[Security.Cryptography.RandomNumberGenerator]::Create();$generator.GetBytes($bytes);$generator.Dispose()
$adminSecret=($bytes|ForEach-Object {$_.ToString('x2')}) -join ''
$privateFolder=Join-Path $env:LOCALAPPDATA 'JarvisBeta\publisher'
New-Item -ItemType Directory -Path $privateFolder -Force | Out-Null
$protected=ConvertTo-SecureString -String $adminSecret -AsPlainText -Force | ConvertFrom-SecureString
$protected | Set-Content -LiteralPath (Join-Path $privateFolder 'feedback-admin.dpapi') -Encoding UTF8
$adminSecret | & npx.cmd --yes wrangler@4 secret put ADMIN_TOKEN --config wrangler.jsonc
$adminSecret=$null
if($LASTEXITCODE -ne 0){throw 'Segreto amministratore non salvato nel servizio.'}
$endpoint=[regex]::Match($result,'https://[a-zA-Z0-9.-]+\.workers\.dev').Value
if(!$endpoint){throw 'Distribuzione terminata: recupera l''indirizzo dal pannello Cloudflare.'}
@{endpoint=($endpoint+'/report');summary=($endpoint+'/summary');status='Servizio distribuito; collegare endpoint alla prossima release firmata di Jarvis.'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'servizio-collegato.json') -Encoding UTF8
Write-Host ('Servizio preparato: '+$endpoint)
Write-Host 'Il segreto amministratore è protetto sul tuo PC, fuori dai sorgenti e dal vault. Non condividerlo.'
Write-Host 'L''app non è stata modificata: l''indirizzo deve entrare in una release verificata, con consenso degli utenti.'
