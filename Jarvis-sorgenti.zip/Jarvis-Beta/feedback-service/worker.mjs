const allowed=new Set(['app_error','request_error','voice_error','memory_error','update_error']);
export default {async fetch(request,env){
 const url=new URL(request.url);
 if(url.pathname==='/report'&&request.method==='POST'){
  if(Number(request.headers.get('content-length')||0)>8192)return new Response('Too large',{status:413});const text=await request.text();if(text.length>8192)return new Response('Too large',{status:413});let report;try{report=JSON.parse(text);}catch{return new Response('Invalid',{status:400});}
  if(!report||typeof report!=='object'||Array.isArray(report))return new Response('Invalid',{status:400});
  if(!/^\d+\.\d+\.\d+$/.test(report.version||'')||!['win32','darwin','linux'].includes(report.platform)||!['x64','arm64'].includes(report.arch)||!report.counts||typeof report.counts!=='object'||Array.isArray(report.counts)||Object.keys(report).some(k=>!['version','platform','arch','counts'].includes(k)))return new Response('Invalid',{status:400});
  const day=new Date().toISOString().slice(0,10),statements=[];for(const[key,value]of Object.entries(report.counts)){if(!allowed.has(key)||!Number.isSafeInteger(value)||value<0||value>1000)return new Response('Invalid',{status:400});statements.push(env.REPORTS.prepare('INSERT INTO reports(day,version,platform,arch,category,count) VALUES(?,?,?,?,?,?) ON CONFLICT(day,version,platform,arch,category) DO UPDATE SET count=count+excluded.count').bind(day,report.version,report.platform,report.arch,key,value));}if(statements.length)await env.REPORTS.batch(statements);return new Response('Accepted',{status:202});
 }
 if(url.pathname==='/summary'&&request.method==='GET'){if(!env.ADMIN_TOKEN||request.headers.get('authorization')!=='Bearer '+env.ADMIN_TOKEN)return new Response('Unauthorized',{status:401});const result=await env.REPORTS.prepare('SELECT * FROM reports ORDER BY day DESC LIMIT 500').all();return Response.json(result.results,{headers:{'Cache-Control':'no-store'}});}
 return new Response('Not found',{status:404});
}};
