"""Offline speech input. NDJSON commands on stdin; never stores microphone audio."""
import sys, os, json, queue, threading, time, re, base64
from contextlib import nullcontext
sys.stdout.reconfigure(encoding='utf-8')
sys.stdin.reconfigure(encoding='utf-8')
import vosk
import sounddevice as sd
vosk.SetLogLevel(-1)
def emit(kind, **data):
    print(json.dumps(dict(type=kind, **data), ensure_ascii=False), flush=True)
mode = 'once'
paused = False
closing = False
wake_until = 0
wake_words=['jarvis','giarvis','giorgis','cervis','giavis']
commands = queue.Queue()
audio = queue.Queue(maxsize=50)
external = '--external' in sys.argv
def command_reader():
    for line in sys.stdin:
        try:
            command=json.loads(line)
            if command.get('command')=='audio':
                if external and not paused:
                    try: audio.put_nowait(base64.b64decode(command.get('data','')))
                    except queue.Full: pass
            else: commands.put(command)
        except Exception: pass
    commands.put({'command': 'quit'})
threading.Thread(target=command_reader, daemon=True).start()
try:
    model = vosk.Model(sys.argv[1])
    device = {'name':'Microfono con elaborazione browser'} if external else sd.query_devices(kind='input')
    rate = 16000 if external else int(device['default_samplerate'])
    recognizer = vosk.KaldiRecognizer(model, rate)
    recognizer.SetWords(True)
    def capture(data, frames, timing, status):
        if not paused:
            try: audio.put_nowait(bytes(data))
            except queue.Full: pass
    with (nullcontext() if external else sd.RawInputStream(samplerate=rate, blocksize=4000, dtype='int16', channels=1, callback=capture)):
        emit('ready', device=str(device['name']))
        last_partial = ''
        while not closing:
            while not commands.empty():
                command = commands.get_nowait()
                if command.get('command') == 'quit': closing = True
                if command.get('command') == 'wake_words': wake_words=[str(w) for w in command.get('value',[]) if str(w).strip()][:10]
                if command.get('command') == 'mode': mode = command.get('value', 'once'); wake_until = 0; recognizer.Reset()
                if command.get('command') == 'pause':
                    paused = bool(command.get('value'))
                    recognizer.Reset()
                    while not audio.empty(): audio.get_nowait()
            if closing: break
            if paused: time.sleep(.05); continue
            try: block = audio.get(timeout=.1)
            except queue.Empty: continue
            if recognizer.AcceptWaveform(block):
                result = json.loads(recognizer.Result()); text = result.get('text', '').strip()
                words = result.get('result', [])
                confidence = sum(w.get('conf', 0) for w in words) / max(1, len(words))
                if not text or confidence < .55: continue
                if mode == 'wake':
                    if re.match(r'^(?:accendi|avvia) (?:i )?motori(?: per favore)?$', text, re.I):
                        emit('text', text=text, confidence=round(confidence, 3)); paused = True; continue
                    match = re.match(r'^(?:hey |ehi )?(?:'+'|'.join(re.escape(w) for w in wake_words)+r')\b[ ,]*', text, re.I)
                    if match:
                        text = text[match.end():].strip(); wake_until = time.monotonic() + 9
                        emit('wake')
                    elif time.monotonic() > wake_until: continue
                    if not text: continue
                    wake_until = 0
                emit('text', text=text, confidence=round(confidence, 3))
                if mode == 'once': closing = True
                elif mode != 'continuous': paused = True
            elif mode != 'wake' or time.monotonic() < wake_until:
                partial = json.loads(recognizer.PartialResult()).get('partial', '')
                if partial and partial != last_partial: emit('partial', text=partial); last_partial = partial
    emit('stopped')
except Exception:
    emit('error', message='Non riesco ad accedere al microfono locale. Controlla il dispositivo e i permessi Windows.')
    sys.exit(1)
