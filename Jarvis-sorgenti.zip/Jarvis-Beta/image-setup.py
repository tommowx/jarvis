"""Private, on-demand image runtime. Does not change system Python or drivers."""
import os,sys,json,urllib.request,subprocess,importlib.metadata
from pathlib import Path
root=Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'images'
packages=root/'packages';packages.mkdir(parents=True,exist_ok=True)
revision='b261bac6fd2cf515557d5d0707481eafa0485ec2'
def notice(text):print(json.dumps({'status':text},ensure_ascii=False),flush=True)
pip=root/'pip.pyz'
if not pip.exists():
 notice('Preparo il download dei componenti immagini...')
 urllib.request.urlretrieve('https://bootstrap.pypa.io/pip/pip.pyz',pip)
def install(args):
 result=subprocess.run([sys.executable,str(pip),'install','--disable-pip-version-check','--no-warn-script-location','--only-binary=:all:','--target',str(packages)]+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
 if result.returncode:raise RuntimeError('Installazione librerie immagini non riuscita: '+result.stdout[-1200:])
try:torch_version=importlib.metadata.version('torch')
except importlib.metadata.PackageNotFoundError:torch_version=''
if torch_version!='2.5.1+cu118':
 notice('Scarico il motore immagini locale (primo avvio, circa 3 GB)...')
 install(['torch==2.5.1+cu118','--index-url','https://download.pytorch.org/whl/cu118'])
try:version=importlib.metadata.version('diffusers')
except importlib.metadata.PackageNotFoundError:version=''
required={'diffusers':'0.35.1','transformers':'4.44.2','accelerate':'1.1.1','safetensors':'0.4.5','numpy':'1.26.4','Pillow':'11.0.0','huggingface_hub':'0.34.4'}
def valid(name,wanted):
 try:return importlib.metadata.version(name)==wanted
 except importlib.metadata.PackageNotFoundError:return False
if not all(valid(name,wanted) for name,wanted in required.items()):
 notice('Preparo i componenti del generatore immagini...')
 install(['--upgrade','--no-deps','diffusers==0.35.1','transformers==4.44.2','accelerate==1.1.1','safetensors==0.4.5','Pillow==11.0.0','huggingface_hub==0.34.4','numpy==1.26.4','packaging==25.0','psutil==7.1.0','pyyaml==6.0.3','regex==2024.11.6','requests==2.32.5','urllib3==2.5.0','certifi==2025.10.5','idna==3.11','charset-normalizer==3.4.4','tqdm==4.67.1','tokenizers==0.19.1','importlib-metadata==8.7.0','zipp==3.23.0','colorama==0.4.6'])
sys.path.insert(0,str(packages))
model=root/'model'
needed=['model_index.json','unet/diffusion_pytorch_model.fp16.safetensors','vae/diffusion_pytorch_model.fp16.safetensors','text_encoder/model.fp16.safetensors']
if not all((model/file).is_file() for file in needed):
 notice('Scarico il modello immagini locale (solo la prima volta)...')
 os.environ['HF_HUB_DISABLE_XET']='1';os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING']='1'
 from huggingface_hub import snapshot_download
 snapshot_download('stabilityai/sd-turbo',revision=revision,local_dir=str(model),max_workers=2,token=False,allow_patterns=['model_index.json','scheduler/*.json','tokenizer/*','text_encoder/config.json','text_encoder/model.fp16.safetensors','unet/config.json','unet/diffusion_pytorch_model.fp16.safetensors','vae/config.json','vae/diffusion_pytorch_model.fp16.safetensors','feature_extractor/*.json','README.md','LICENSE*'])
import torch,diffusers,numpy,PIL
if torch.__version__!='2.5.1+cu118':raise RuntimeError('Motore immagini non compatibile.')
(root/'ready.json').write_text(json.dumps({'version':1,'model':'stabilityai/sd-turbo','revision':revision}),encoding='utf8')
notice('Generatore locale pronto.')
