const os=require('node:os'),path=require('node:path');
function configurePlatform(app,platform=process.platform,env=process.env){if(platform==='win32')return;const data=app.getPath('appData');env.LOCALAPPDATA ||=data;env.APPDATA ||=data;env.USERPROFILE ||=os.homedir();return{data,platform};}
module.exports={configurePlatform};
