const {execFile}=require('node:child_process');const {promisify}=require('node:util');const path=require('node:path');const {redact}=require('./vault-memory.cjs');const run=promisify(execFile);
class DocumentReader{
 async read(file,signal){const resources=path.join(process.env.LOCALAPPDATA,'JarvisBeta');try{const {stdout}=await run(path.join(resources,'voice','runtime','python.exe'),['-u',path.join(__dirname,'document-worker.py'),file],{windowsHide:true,timeout:20000,maxBuffer:1000000,signal,env:{...process.env,PYTHONPATH:path.join(resources,'documents','packages'),PYTHONIOENCODING:'utf-8'}});const result=JSON.parse(stdout);if(result.error)throw new Error(result.error);return{...result,text:redact(result.text)};}catch(e){let detail;try{detail=JSON.parse(e.stdout).error;}catch{}throw new Error(detail||'Non riesco a leggere il documento. Formati: PDF testuali, DOCX, XLSX.');}}
}
module.exports={DocumentReader};
