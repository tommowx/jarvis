﻿$ErrorActionPreference='Stop'
$jarvisData=Join-Path $env:APPDATA 'Jarvis Beta'
$jarvisRoot=Join-Path $env:LOCALAPPDATA 'JarvisBeta\App\resources\app'
$jarvisSource=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Codex\Jarvis-Beta'
$jarvisBackup=[IO.Path]::GetFullPath((Get-Content -LiteralPath (Join-Path $jarvisData 'last-self-change.json') -Raw|ConvertFrom-Json).backup)
$jarvisBackupRoot=[IO.Path]::GetFullPath((Join-Path $jarvisData 'self-changes'))+[IO.Path]::DirectorySeparatorChar
if(-not $jarvisBackup.StartsWith($jarvisBackupRoot,[StringComparison]::OrdinalIgnoreCase)){throw 'Percorso di recupero non valido'}
$jarvisRecord=Get-Content -LiteralPath (Join-Path $jarvisBackup 'change.json') -Raw|ConvertFrom-Json
if($jarvisRecord.source -ne $jarvisSource -or $jarvisRecord.installed -ne $jarvisRoot){throw 'Backup di un’altra installazione'}
$jarvisFiles=@('index.html','app.js','preload.cjs','styles.css','orb.css','reactor.css','orb-scene.mjs','orb-scene.js','orb-scene.js.LEGAL.txt','main.cjs','agent.cjs','local-tools.cjs','voice.cjs','voice-worker.py','whisper-worker.py','speech-recognizer.py','neural-voice.py','phone.cjs','phone-bridge.js','conversation-store.cjs','vault-memory.cjs','import-chatgpt.cjs','computer-tools.cjs','computer-worker.ps1','voice-commands.cjs','activity-store.cjs','audio-capture.js','audio-worklet.js','speech-flow.js','document-reader.cjs','document-worker.py','routine-store.cjs','portable-memory.cjs','request-language.cjs')
foreach($jarvisFile in @($jarvisRecord.files)+@($jarvisRecord.outputs)){if($jarvisFile -notin $jarvisFiles){throw 'File di recupero non valido'}}
$jarvisExe=Join-Path $env:LOCALAPPDATA 'JarvisBeta\App\Jarvis.exe'
Get-Process Jarvis -ErrorAction SilentlyContinue|Where-Object Path -eq $jarvisExe|Stop-Process -Force
foreach($jarvisFile in $jarvisRecord.files){Copy-Item -LiteralPath (Join-Path (Join-Path $jarvisBackup 'source') $jarvisFile) -Destination (Join-Path $jarvisSource $jarvisFile) -Force}
foreach($jarvisFile in $jarvisRecord.outputs){Copy-Item -LiteralPath (Join-Path (Join-Path $jarvisBackup 'installed') $jarvisFile) -Destination (Join-Path $jarvisRoot $jarvisFile) -Force}
Start-Process -FilePath $jarvisExe
