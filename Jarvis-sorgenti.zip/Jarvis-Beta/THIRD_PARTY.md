# Third-party software and visual research

The WebGL scene in `orb-scene.mjs` is original code in this project.
Visual research: layered holographic shells, Fresnel edges and moving orbital rings:

- [J.A.R.V.I.S. Holographic Orb by joehehe0426](https://github.com/joehehe0426/jarvis-orb) (README declares MIT).
- [Jarvis UI by kariimmoalla1-source](https://github.com/kariimmoalla1-source/jarvis-ui) (README declares MIT).
- [Three.js bloom example](https://threejs.org/examples/webgl_postprocessing_unreal_bloom.html).

No camera/gesture tracker or external project's executable code was imported.
Three.js and its postprocessing addons are bundled from the installed `three` package.
The complete MIT license is preserved in `licenses/three-LICENSE.txt` and the generated bundle.
The esbuild compiler is a development dependency; its license is in the installed package.
OpenAI Sign in with ChatGPT DevKit and its notices remain under `vendor/siwc`.

## Componenti aggiunti nella beta 0.2
Vosk (Apache-2.0), modello italiano small-it-0.22, sounddevice (MIT), Python e relative librerie nel pacchetto voce offline. Metadati e licenze conservati insieme ai componenti quando disponibili. Electron/Chromium conserva LICENSE e LICENSES.chromium.html nel programma distribuito. qrcode e adm-zip sono inclusi nel backend con le licenze dei rispettivi pacchetti sotto licenses. Nessuna voce dell’attore Jarvis è clonata: la sintesi è la voce Windows installata.

Voce neurale opzionale: edge-tts 7.3.1 e relative dipendenze installate nel pacchetto voice/neural-packages con i metadati dist-info e le rispettive licenze originali. Sorgente: https://github.com/rany2/edge-tts . L'uso del servizio online non costituisce una licenza sulla voce originale del film; qui vengono usate soltanto voci standard del catalogo Microsoft.

## Lettura documenti (beta 0.4)
pypdf 6.21.1, openpyxl 3.1.5, python-docx 1.2.0, lxml 6.1.3 e relative dipendenze sono distribuiti nel pacchetto documents/packages con dist-info e licenze originali. Le librerie sono usate per estrazione locale di testo e celle, non per OCR. WebRTC e AudioWorklet sono forniti da Chromium/Electron già distribuito.

## Riconoscimento beta 0.7
faster-whisper 1.2.1 (MIT), CTranslate2 4.8.3, ONNX Runtime 1.31.0, tokenizers 0.23.3 e dipendenze con licenze/dist-info conservati in voice/speech-packages. PyAV bloccato a 16.1.0: la 19.0.1 installata inizialmente non era compatibile con metadata_errors di faster-whisper, rilevato e corretto prima del rilascio. Modelli Systran/faster-whisper-base e Systran/faster-whisper-small da Hugging Face, convertiti da OpenAI Whisper (MIT): licenza in licenses/Whisper-MIT.txt e in ciascuna cartella modello. Fonte implementazione: https://github.com/SYSTRAN/faster-whisper . Le prove sotto docs/stt-fixtures sono sintesi di frasi di test pubbliche, non registrazioni dell’utente né una clonazione della voce di Jarvis.

Accelerazione verificata sulla GTX 1050 Ti del PC: nvidia-cublas-cu12 12.6.4.1, nvidia-cudnn-cu12 9.1.1.17, nvidia-cuda-runtime-cu12 12.6.77 e nvidia-cuda-nvrtc-cu12 12.9.86, conservati con metadata e licenze in voice/gpu-packages. Le directory DLL sono aggiunte solo al processo del riconoscitore; non viene installato un toolkit CUDA globale né sostituito il driver. Modello predefinito finale: Whisper small INT8, beam 5, suggerimenti di soli nomi propri. Il primo tentativo con base e beam 1 era più rapido su CPU ma non abbastanza accurato sui nomi; non è il modello selezionato nel rilascio.

## Immagini (beta 0.9)
Ricerca: Wikimedia Commons Action API, attribuzione e collegamento alla pagina fonte mostrati con il risultato. Ogni immagine mantiene la propria licenza. Generazione: stabilityai/sd-turbo, revisione b261bac6fd2cf515557d5d0707481eafa0485ec2, scaricato su richiesta con README e LICENSE.md originali: https://huggingface.co/stabilityai/sd-turbo . Diffusers, Transformers, Accelerate, PyTorch e dipendenze sono installati con metadata/licenze nel runtime privato; PyTorch 2.5.1+cu118 dal distributore ufficiale. Nessun driver globale viene sostituito.
