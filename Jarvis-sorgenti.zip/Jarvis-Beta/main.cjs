const { app, BrowserWindow, ipcMain, safeStorage, session, shell, clipboard, dialog, Tray, Menu, nativeImage, globalShortcut, Notification } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { VaultMemory, locateUsbVault, redact } = require('./vault-memory.cjs');
const { ConversationStore } = require('./conversation-store.cjs');
const { LocalTools } = require('./local-tools.cjs');
const { Voice } = require('./voice.cjs');
const { DocumentReader }=require('./document-reader.cjs');
const { RoutineStore }=require('./routine-store.cjs');
const { ActivityStore }=require('./activity-store.cjs');
const { Agent } = require('./agent.cjs');
const { SelfModify } = require('./self-modify.cjs');
const { AutoUpdate } = require('./auto-update.cjs');
const { PhoneGateway } = require('./phone.cjs');
const { importChatGPT, flushPendingImports } = require('./import-chatgpt.cjs');

const verification = process.env.JARVIS_VERIFY === '1';
const installedExe=path.join(process.env.LOCALAPPDATA,'JarvisBeta','App','Jarvis.exe');
if (!verification && !app.isPackaged && require('node:fs').existsSync(installedExe)) { require('node:child_process').spawn(installedExe,process.argv.includes('--background')?['--background']:[],{detached:true,stdio:'ignore',windowsHide:process.argv.includes('--background')}).unref(); app.exit(0); }
app.commandLine.appendSwitch('autoplay-policy','no-user-gesture-required');
app.setName('Jarvis Beta'); app.setAppUserModelId('Jarvis.Beta');
app.setPath('userData', verification&&process.env.JARVIS_SANDBOX_ROOT?process.env.JARVIS_SANDBOX_ROOT:path.join(app.getPath('appData'),'Jarvis Beta'));
const locked = app.requestSingleInstanceLock(); if (!locked) app.quit();
let mainWindow, tray, knowledge, client, store, tools, voice, agent, phone, activities, routines;
let updater;
let quitting = false, settings, settingsQueue = Promise.resolve(), stateRefresh = null, initialized;
let state = { session: { status: 'disconnected', sharing: false }, models: [] };
const userData = app.getPath('userData');
const appFileUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
const settingsPath = process.env.JARVIS_SANDBOX_ROOT&&verification?path.join(userData,'settings.json'): verification ? path.join(app.getPath('temp'), 'jarvis-test-settings.json') : path.join(userData, 'jarvis-settings.json');
const launchArgs = () => app.isPackaged ? ['--background'] : [__dirname, '--background'];
const defaults = { version: 1, startup: true, computerControl: true, acousticEcho: true, wakeWord:'jarvis',speechLanguage:'auto',speechQuality:'precise', inputDeviceId:'default',audioProfile:'speakers',subtitles:false,privacy:false,voiceMode: 'wake', voiceReply: true, voicePreset: 'neural-deep', voiceRate: -4, voiceVolume: 20, responseMode: 'fast', monitoring: false, monitorMinutes: 5, phoneEnabled: true, theme: { accent: '#51deef', speed: 1, scale: 1 } };
let lastInteraction=Date.now();
const methods = new Map();
const encrypted = text => { if (!safeStorage.isEncryptionAvailable()) throw new Error('Protezione Windows non disponibile.'); return safeStorage.encryptString(text); };
function emit(type, data) { if(type==='voice'&&['speech-start','text','partial'].includes(data?.type))lastInteraction=Date.now(); if(type==='window-mode'){if(!mainWindow)return;if(data==='full')mainWindow.setFullScreen(true);else{mainWindow.setFullScreen(false);mainWindow.setMinimumSize(data==='compact'?320:720,data==='compact'?320:560);mainWindow.setSize(data==='compact'?440:1360,data==='compact'?500:920);mainWindow.center();}return;} if (type === 'show-window') return showWindow(); if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('jarvis:' + type, data); if(type!=='voice'||!['audio','stop-audio','capture-start','capture-stop'].includes(data?.type))phone?.event(type, data); }
function showWindow() { lastInteraction=Date.now(); if (mainWindow && !mainWindow.isDestroyed()) { const wasHidden = !mainWindow.isVisible(); if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.show(); mainWindow.focus(); if (wasHidden && voice && !settings.privacy && settings.voiceMode !== 'manual') void voice.listen(settings.voiceMode).catch(e => emit('notice',e.message)); } }
function safeError(e) { if (typeof e?.toJSON === 'function') return e.toJSON(); return { code: 'local_error', message: redact(e?.message || 'Operazione non completata.').slice(0, 400), retryable: true }; }
async function refreshState() {
  if (stateRefresh) return stateRefresh;
  stateRefresh = (async () => { try { const current = await client.getSession(); state = { session: current, models: current.status === 'connected' && current.sharing ? await client.listModels() : [] }; } catch (e) { state = { ...state, session: { ...state.session, error: safeError(e) } }; } emit('state', state); return state; })().finally(() => { stateRefresh = null; });
  return stateRefresh;
}
function validateSettings(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('Impostazioni non valide.');
  const next = { ...settings, theme: { ...settings.theme } };
  for (const key of ['startup', 'voiceReply', 'monitoring', 'phoneEnabled', 'computerControl','subtitles','privacy','acousticEcho']) if (patch[key] !== undefined) { if (typeof patch[key] !== 'boolean') throw new Error('Impostazione non valida.'); next[key] = patch[key]; }
  if(patch.speechLanguage!==undefined){if(!['auto','it','en'].includes(patch.speechLanguage))throw new Error('Lingua di riconoscimento non valida.');next.speechLanguage=patch.speechLanguage;}
  if(patch.speechQuality!==undefined){if(!['balanced','precise'].includes(patch.speechQuality))throw new Error('Qualità riconoscimento non valida.');next.speechQuality=patch.speechQuality;}
  if(patch.wakeWord!==undefined){if(typeof patch.wakeWord!=='string'||! /^[a-zàèéìòù ]{2,24}$/i.test(patch.wakeWord))throw new Error('Parola di attivazione non valida.');next.wakeWord=patch.wakeWord.toLowerCase().trim();}
  if(patch.inputDeviceId!==undefined){if(typeof patch.inputDeviceId!=='string'||patch.inputDeviceId.length>250)throw new Error('Microfono non valido.');next.inputDeviceId=patch.inputDeviceId;}
  if(patch.audioProfile!==undefined){if(!['speakers','headphones'].includes(patch.audioProfile))throw new Error('Profilo audio non valido.');next.audioProfile=patch.audioProfile;}
  if (patch.responseMode !== undefined) { if (!['fast','balanced'].includes(patch.responseMode)) throw new Error('Modalità risposta non valida.'); next.responseMode=patch.responseMode; }
  if (patch.voicePreset !== undefined) { if (!['neural-deep', 'neural-natural', 'british', 'offline'].includes(patch.voicePreset)) throw new Error('Voce non valida.'); next.voicePreset = patch.voicePreset; }
  if (patch.voiceVolume !== undefined) { if (!Number.isInteger(patch.voiceVolume) || patch.voiceVolume < 0 || patch.voiceVolume > 100) throw new Error('Volume non valido.'); next.voiceVolume=patch.voiceVolume; }
  if (patch.voiceRate !== undefined) { if (!Number.isInteger(patch.voiceRate) || patch.voiceRate < -15 || patch.voiceRate > 15) throw new Error('Velocità voce non valida.'); next.voiceRate = patch.voiceRate; }
  if (patch.voiceMode !== undefined) { if (!['manual', 'wake', 'continuous'].includes(patch.voiceMode)) throw new Error('Modalità voce non valida.'); next.voiceMode = patch.voiceMode; }
  if (patch.monitorMinutes !== undefined) { if (!Number.isFinite(patch.monitorMinutes) || patch.monitorMinutes < 2 || patch.monitorMinutes > 120) throw new Error('Intervallo non valido.'); next.monitorMinutes = patch.monitorMinutes; }
  if (patch.theme !== undefined) {
    if (!patch.theme || typeof patch.theme !== 'object') throw new Error('Tema non valido.');
    if (patch.theme.accent !== undefined) { if (!/^#[a-f0-9]{6}$/i.test(patch.theme.accent)) throw new Error('Colore non valido.'); next.theme.accent = patch.theme.accent; }
    for (const [key, low, high] of [['speed', .2, 2], ['scale', .7, 1.25]]) if (patch.theme[key] !== undefined) { const value = patch.theme[key]; if (typeof value !== 'number' || !Number.isFinite(value) || value < low || value > high) throw new Error('Valore visivo non valido.'); next.theme[key] = value; }
  }
  return next;
}
function saveSettings(patch) {
  const work = settingsQueue.then(async () => {
    const previous = settings; const next = validateSettings(patch); if(previous.voiceVolume!==next.voiceVolume)voice?.stopSpeech();
    await fs.writeFile(settingsPath + '.tmp', JSON.stringify(next, null, 2)); await fs.rename(settingsPath + '.tmp', settingsPath); settings = next;
    if (!verification) app.setLoginItemSettings({ openAtLogin: next.startup, path: process.execPath, args: launchArgs() });
    if(previous.privacy!==next.privacy){if(next.privacy)voice.close();else if(next.voiceMode!=='manual'&&mainWindow?.isVisible())await voice.listen(next.voiceMode);}
    if(previous.speechLanguage!==next.speechLanguage)voice.configureRecognition();
    if(previous.speechQuality!==next.speechQuality&&voice.worker){const mode=voice.mode;voice.stop();if(!next.privacy&&mainWindow?.isVisible())await voice.listen(mode);}
    if(previous.wakeWord!==next.wakeWord)voice.configureWake();
    if(previous.inputDeviceId!==next.inputDeviceId||previous.audioProfile!==next.audioProfile)emit('voice',{type:'capture-restart'});
    if (previous.voiceMode !== next.voiceMode) { voice.stop(); if (next.voiceMode !== 'manual' && !next.privacy && mainWindow?.isVisible()) await voice.listen(next.voiceMode).catch(e => emit('notice', e.message)); }
    if (previous.phoneEnabled !== next.phoneEnabled) { if (next.phoneEnabled) await phone.start(); else await phone.stop(); }
    emit('settings', settings);
    const vault = verification ? null : await locateUsbVault().catch(() => null);
    if (vault) { const folder = path.join(vault, '02 Progetti', 'Jarvis - beta gratuita'); await fs.mkdir(folder, { recursive: true }); await fs.writeFile(path.join(folder, 'Impostazioni Jarvis.json'), JSON.stringify(settings, null, 2)); }
    return settings;
  }); settingsQueue = work.catch(() => {}); return work;
}
function register(name, handler) {
  methods.set(name, handler);
  ipcMain.handle('jarvis:' + name, async (event, ...args) => {
    if (!mainWindow || event.sender !== mainWindow.webContents || event.senderFrame !== event.sender.mainFrame || event.senderFrame.url !== appFileUrl) throw new Error('Richiesta non autorizzata.');
    try { return await handler(...args); } catch (e) { throw new Error(safeError(e).message); }
  });
}
function installMethods() {
  register('get-state', refreshState);
  register('activities',()=>activities.recent());
  register('conversation-control',async(text,status)=>{if(typeof text!=='string'||text.length>100||! /^(?:jarvis[, ]*)?(?:vai avanti|riprendi(?: a parlare)?|continua a parlare|resume speaking|continue speaking|go on|stop(?: speaking| talking)?|be quiet|cancel|enough|basta|fermati)[.! ]*$/i.test(text)||!['resumed','empty','stopped'].includes(status))throw new Error('Controllo conversazione non valido.');const reply=status==='resumed'?'Riprendo il testo preparato dall’inizio della frase interrotta.':status==='empty'?'Non ho una lettura interrotta da riprendere.':'Lettura fermata. La modalità di ascolto resta invariata.';if(!verification){await store.append('user',text,{kind:'voice-control'});await store.append('assistant',reply,{kind:'voice-control'});}return{text:reply};});
  register('pause-routine',async text=>{if(typeof text!=='string'||text.length>150||! /^(?:jarvis[, ]*)?(?:metti in pausa|pausa|sospendi|pause|suspend)(?: la| le| the)? routines?[.! ]*$/i.test(text))throw new Error('Comando pausa non valido.');const result=await routines.pause();const reply=result.requested?'Pausa richiesta: termino il passo corrente e salvo il punto di ripresa.':'Nessuna routine in esecuzione.';if(!verification){await store.append('user',text);await store.append('assistant',reply);}emit('notice',reply);return{text:reply,...result};});
  register('load-memory', () => store.messages.slice(-400));
  register('knowledge-status', () => ({ ...knowledge.status(), archive: store.archiveState }));
  register('refresh-knowledge', async () => { await store.archive(); await flushPendingImports(path.join(app.getPath('documents'), 'Codex')); return knowledge.sync({ force: true }); });
  register('get-settings', () => ({ ...settings, capabilities: tools.describe(), voice: voice.state() }));
  register('save-settings', saveSettings);
  register('phone-pairing', () => phone.pairing());
  ipcMain.on('jarvis:audio-chunk',(event,bytes)=>{if(event.sender!==mainWindow?.webContents||event.senderFrame!==event.sender.mainFrame||!mainWindow?.isVisible()||settings.privacy||!(bytes instanceof ArrayBuffer)||bytes.byteLength>16000)return;voice.acceptAudio(Buffer.from(bytes));});
  register('audio-capture-error',async()=>{const mode=voice.mode;if(mode==='off')return;voice.stop();await voice.listen(mode,false,true);emit('notice','Uso il microfono locale: elaborazione browser non disponibile.');return true;});
  register('playback-state',(id,state)=>voice.handlePlayback(id,state));
  register('voice-listen', mode => voice.listen(mode || 'once'));
  register('voice-stop', () => { voice.stop(); return voice.state(); });
  register('speak', text => { if (!mainWindow?.isVisible()) return false; if (typeof text !== 'string' || text.length > 20000) throw new Error('Testo voce non valido.'); return voice.speak(text); });
  register('stop-speech', () => { voice.stopSpeech(); return true; });
  register('cancel', () => { agent.cancel(); return { cancelled: true }; });
  register('send-message', async messages => {
    if (!Array.isArray(messages) || !messages.length || messages.length > 40) throw new Error('Richiesta non valida.');
    lastInteraction=Date.now();
    const message = messages.findLast(m => m?.role === 'user'); if (!message || typeof message.content !== 'string') throw new Error('Manca la richiesta.');
    return agent.turn(message.content);
  });
  register('open-memory-source', async id => { if (!/^[a-f0-9]{20}$/.test(String(id))) throw new Error('Fonte non valida.'); const error = await shell.openPath(await knowledge.resolveSource(id)); if (error) throw new Error('Non riesco ad aprire la fonte.'); return true; });
  register('source-text', async id => { if (!/^[a-f0-9]{20}$/.test(String(id))) throw new Error('Fonte non valida.'); const file = await knowledge.resolveSource(id); return { text: redact((await fs.readFile(file, 'utf8')).slice(0, 60000)), truncated: (await fs.stat(file)).size > 60000 }; });
  register('sign-in', async () => { const before = state.session; state.session = { ...before, status: 'connecting' }; emit('state', state); try { await client.signIn({ reconsent: before.status === 'connected' && !before.sharing }); return refreshState(); } catch (e) { state.session = { ...before, error: safeError(e) }; emit('state', state); throw e; } });
  register('disconnect', async () => { await client.disconnect(); return refreshState(); });
  register('hide-media',async(text,button=false)=>{if(button!==true&&!require('./media-commands.js').isHideMedia(text,true))throw new Error('Comando immagine non valido.');tools.images.hide();if(!verification&&button!==true){await store.append('user',text);await store.append('assistant','Immagine nascosta.',{kind:'voice-control'});}return{hidden:true,text:'Immagine nascosta.'};});
  register('pick-media', async () => {
    const selection = await dialog.showOpenDialog(mainWindow, { title: 'Mostra un’immagine in Jarvis', properties: ['openFile'], filters: [{ name: 'Immagini', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif','pdf','docx','xlsx'] }] });
    if (selection.canceled || !selection.filePaths[0]) return null;
    const file = selection.filePaths[0], ext = path.extname(file).toLowerCase(); const mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' }[ext];
    if(/\.(pdf|docx|xlsx)$/i.test(file)){const safe=await tools.computer.filePath(file);const result=await new DocumentReader().read(safe);return {kind:'document',...result};}
    if (!mime || (await fs.stat(file)).size > 15 * 1024 * 1024) throw new Error('Formato immagine non supportato o file oltre 15 MB.');
    const bytes = await fs.readFile(file), media = { name: path.basename(file), data: `data:${mime};base64,${bytes.toString('base64')}` }; emit('media', media); return media;
  });
  register('import-chatgpt', async () => {
    const selection = await dialog.showOpenDialog(mainWindow, { title: 'Importa l’esportazione ufficiale di ChatGPT', properties: ['openFile'], filters: [{ name: 'Esportazione ChatGPT', extensions: ['zip', 'json'] }] });
    if (selection.canceled || !selection.filePaths[0]) return null;
    const result = await importChatGPT(selection.filePaths[0], path.join(app.getPath('documents'), 'Codex')); await knowledge.sync({ force: true }); return result;
  });
}
function trayIcon() {
  const zlib = require('node:zlib'); const table = Array.from({ length: 256 }, (_, n) => { for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ n >>> 1 : n >>> 1; return n >>> 0; });
  const chunk = (name, data) => { const type = Buffer.from(name), body = Buffer.concat([type, data]); let crc = 0xffffffff; for (const byte of body) crc = table[(crc ^ byte) & 255] ^ crc >>> 8; const length = Buffer.alloc(4), tail = Buffer.alloc(4); length.writeUInt32BE(data.length); tail.writeUInt32BE((crc ^ 0xffffffff) >>> 0); return Buffer.concat([length, body, tail]); };
  const pixels = Buffer.alloc(32 * 129); for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) { const d = Math.hypot(x - 15.5, y - 15.5), i = y * 129 + 1 + x * 4, glow = d < 8 ? 1 - d / 12 : Math.abs(d - 12) < 1.1 ? .8 : .06; pixels[i] = 60 * glow; pixels[i + 1] = 230 * glow; pixels[i + 2] = 255 * glow; pixels[i + 3] = d < 15 ? 255 : 0; }
  const header = Buffer.alloc(13); header.writeUInt32BE(32); header.writeUInt32BE(32, 4); header[8] = 8; header[9] = 6;
  return nativeImage.createFromBuffer(Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', header), chunk('IDAT', zlib.deflateSync(pixels)), chunk('IEND', Buffer.alloc(0))]));
}
async function createWindow() {
  mainWindow = new BrowserWindow({ width: 1360, height: 920, minWidth: 720, minHeight: 560, show: !process.argv.includes('--background'), backgroundColor: '#050912', title: 'Jarvis', autoHideMenuBar: true, icon: trayIcon(), webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.cjs') } });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' })); mainWindow.webContents.on('will-navigate', (event, url) => { if (url !== appFileUrl) event.preventDefault(); });
  mainWindow.on('close', event => { if (!quitting) { event.preventDefault(); voice.close(); emit('voice',{type:'background'}); mainWindow.hide(); setTimeout(()=>updater?.apply(),1000).unref(); } });
  await mainWindow.loadFile(path.join(__dirname, 'index.html'));
  tray = new Tray(trayIcon()); tray.setToolTip('Jarvis — assistente personale'); tray.on('double-click', showWindow);
  tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Apri Jarvis', click: showWindow }, { label: 'Parla a Jarvis', click: () => { showWindow(); void voice.listen('once').catch(e => emit('notice', e.message)); } }, { label: 'Ferma microfono e voce', click: () => voice.close() }, { type: 'separator' }, { label: 'Esci da Jarvis', click: () => { quitting = true; app.quit(); } }]));
  globalShortcut.register('CommandOrControl+Alt+J', () => { showWindow(); void voice.listen('once').catch(e => emit('notice', e.message)); });
}
if (locked) {
  app.on('second-instance', showWindow);
  initialized = app.whenReady().then(async () => {
    settings = { ...defaults, theme: { ...defaults.theme } };
    try { const loaded = JSON.parse((await fs.readFile(settingsPath, 'utf8')).replace(/^\uFEFF/,'')); settings = validateSettings(loaded); } catch {}
    voice = new Voice({ canListen: () => Boolean(mainWindow?.isVisible()) && !settings?.privacy && (!agent?.busy || settings.voiceMode === 'continuous'), getPreferences: () => settings, resources: path.join(process.env.LOCALAPPDATA, 'JarvisBeta', 'voice'), emit: event => emit('voice', event) });
    knowledge = new VaultMemory({ cachePath: path.join(userData, 'vault-memory.dat'), encrypt: encrypted, decrypt: b => safeStorage.decryptString(b), onStatus: k => emit('knowledge', k) });
    store = new ConversationStore({ archiveEnabled:!verification, userData, documents: path.join(app.getPath('documents'), 'Codex'), encrypt: encrypted, decrypt: b => safeStorage.decryptString(b), onChange: history => emit('conversation', history.slice(-400)) }); await store.init();
    routines=new RoutineStore({file:path.join(userData,verification?'test-routines.dat':'routines.dat'),encrypt:encrypted,decrypt:b=>safeStorage.decryptString(b),emit:event=>{emit('notice',event.text);if(Notification.isSupported())new Notification({title:'Jarvis — promemoria',body:event.text}).show();}});await routines.load();
    tools = new LocalTools({ store, routines, shell, knowledge, getSettings: () => settings, saveSettings, emit: (type, data) => { if (type === 'project-change') { emit('notice', data.text); if (Notification.isSupported()) new Notification({ title: 'Jarvis — aggiornamento progetti', body: data.text }).show(); } else emit(type, data); }, voiceResources: voice.resources }); await tools.init();
    const { createChatGPT } = await import('@siwc/local');
    client = createChatGPT({ appName: 'Jarvis', appId: 'jarvis-beta', redirectPort: 0, storageDir: path.join(userData, 'chatgpt'), sendHostId: true, credentialEncryption: { id: 'electron-safe-storage-v1', isAvailable: () => safeStorage.isEncryptionAvailable(), encrypt: encrypted, decrypt: b => safeStorage.decryptString(Buffer.from(b)) }, openBrowser: async url => { if (new URL(url).origin !== 'https://auth.openai.com') throw new Error('Destinazione di accesso non valida.'); await shell.openExternal(url); } });
    client.subscribe(() => { void refreshState(); });
    const selfModify = new SelfModify({ client, getState: () => state, refreshState, sourceRoot: path.join(app.getPath('documents'),'Codex','Jarvis-Beta'), installedRoot: __dirname, dataRoot: userData, emit, restart: () => { if (verification) return; emit('notice','Modifica salvata. Jarvis si riavvia tra 15 secondi.'); setTimeout(() => { quitting = true; const args=process.argv.slice(1).filter(arg=>arg!=='--background'); if (!mainWindow?.isVisible()) args.push('--background'); app.relaunch({args}); app.quit(); },15000).unref(); } });
    activities=new ActivityStore({file:path.join(userData,verification?'test-activities.dat':'activities.dat'),encrypt:encrypted,decrypt:b=>safeStorage.decryptString(b)});await activities.load();
    agent = new Agent({ activities, selfModify, client, store, knowledge, tools, getState: () => state, refreshState, emit, clipboard, voice });
    phone = new PhoneGateway({ root: __dirname, invoke: (name, ...args) => { const method = methods.get(name); if (!method) throw new Error('Operazione non disponibile.'); return method(...args); } });
    installMethods(); session.defaultSession.setPermissionRequestHandler((_wc, permission, cb, details) => cb(permission === 'media' && details.mediaTypes?.includes('audio') && !details.mediaTypes.includes('video')));
    await createWindow(); await knowledge.load(); void knowledge.sync(); await refreshState();
    if (!verification) { app.setLoginItemSettings({ openAtLogin: settings.startup, path: process.execPath, args: launchArgs() }); await fs.writeFile(settingsPath, JSON.stringify(settings, null, 2)); await flushPendingImports(path.join(app.getPath('documents'), 'Codex')); }
    if (settings.phoneEnabled && !verification) await phone.start().catch(() => emit('notice', 'Accesso telefono non disponibile su questa rete.'));
    if (settings.voiceMode !== 'manual' && !settings.privacy && !verification && mainWindow.isVisible()) await voice.listen(settings.voiceMode).catch(e => emit('notice', e.message));
    const reminderTimer=setInterval(()=>{if(!verification)void routines.tick().catch(()=>{});},1000);reminderTimer.unref();
    let lastMonitor = 0;
    const timer = setInterval(() => { void knowledge.sync(); if (!verification) void flushPendingImports(path.join(app.getPath('documents'), 'Codex')).catch(() => {}); if (settings.monitoring && Date.now() - lastMonitor > settings.monitorMinutes * 60000) { lastMonitor = Date.now(); void tools.monitor().catch(() => emit('notice', 'Controllo progetti non completato.')); } void store.archive().catch(() => {}); }, 60000); timer.unref();
    if(!verification){updater=new AutoUpdate({root:path.join(process.env.LOCALAPPDATA,'JarvisBeta'),version:require('./package.json').version,emit,visible:()=>Boolean(mainWindow?.isVisible()),canApply:()=>!agent?.busy&&!selfModify.running&&!routines.running.size&&!voice?.state().speaking&&(!mainWindow?.isVisible()||(settings.voiceMode!=='continuous'&&Date.now()-lastInteraction>180000)),quit:()=>{quitting=true;app.quit();}});updater.start();}
    app.on('activate', showWindow);
  }).catch(e => { if(verification){console.error(safeError(e).message);app.exit(1);return;} dialog.showErrorBox('Jarvis non riesce ad avviarsi', safeError(e).message); quitting = true; app.quit(); });
  app.on('before-quit', () => { quitting = true; agent?.cancel(); voice?.close(); void phone?.stop(); globalShortcut.unregisterAll(); });
}
if (verification) module.exports = { ready: () => initialized, backend: () => ({ state, client, knowledge, tools, voice, phone, store, settings, window: mainWindow, emit, methods }), setAgent: replacement => { agent = replacement; } };
