const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const runFile = promisify(execFile);

const STOP = new Set('che come cosa cose dove quando quale quali quanto quanti delle degli della dello dalla dalle nella nelle negli alla alle agli sono essere anche ancora tutto tutti tutte questo questa questi quello quella vorrei vuoi devo deve devi fare fatto puoi posso dimmi sapere sai abbiamo nostro nostra nostri vostre molto solo loro una uno per con del dei nel sul sui gli non più più mio mia tuo tua adesso allora bene tipo ogni delle about the and from with have'.split(' '));
function normalize(text) {
  return String(text).normalize('NFD').replace(/\p{M}/gu, '').toLowerCase()
    .replace(/crypto[\s_-]*desk/g, 'cryptodesk crypto desk').replace(/turbo[\s_-]*stick/g, 'turbostick turbo stick');
}
function tokens(text) { return normalize(text).match(/[\p{L}\p{N}]{2,60}/gu)?.filter(t => !STOP.has(t)) || []; }
function hash(text) { return crypto.createHash('sha256').update(text).digest('hex'); }
function redact(text) {
  return text.replace(/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----/g, '[CHIAVE PRIVATA OMESSA]')
    .replace(/\b(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[baprs]-[A-Za-z0-9-]{15,})\b/g, '[CREDENZIALE OMESSA]')
    .replace(/\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\b/g, '[TOKEN OMESSO]')
    .replace(/((?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|password|passwd)\s*["']?\s*[:=]\s*)(?:"[^"\n]{4,}"|'[^'\n]{4,}'|[^\s,;\n]{4,})/gi, '$1[CREDENZIALE OMESSA]')
    .replace(/(\bBearer\s+)[A-Za-z0-9_.+/-]{12,}/gi, '$1[TOKEN OMESSO]');
}
function chunkDocument(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const parts = []; let buffer = '', start = 1, end = 1;
  function flush() {
    if (buffer.trim()) parts.push({ line: start, endLine: end, text: buffer.trim(), hash: hash(buffer.trim()) });
    buffer = '';
  }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (buffer && buffer.length + line.length > 2500) flush();
    if (!buffer) start = i + 1;
    if (line.length > 3200) {
      flush();
      for (let offset = 0; offset < line.length; offset += 2400) {
        const body = line.slice(offset, offset + 2700);
        parts.push({ line: i + 1, endLine: i + 1, text: body, hash: hash(body) });
      }
      continue;
    }
    buffer += line + '\n'; end = i + 1;
    if (buffer.length >= 1900 && (!line.trim() || /^#{1,3} /.test(lines[i + 1] || ''))) flush();
  }
  flush(); return parts;
}
async function locateUsbVault() {
  if (process.platform !== 'win32') return null;
  let config={};try{config=JSON.parse(await fs.readFile(path.join(process.env.APPDATA,'Jarvis Beta','vault-location.json'),'utf8'));}catch{}
  const serial=/^[A-F0-9]{8}$/i.test(config.serial||'')?config.serial:null;
  const filter=serial?"$_.VolumeSerialNumber -eq '"+serial+"'":"$_.DriveType -eq 2";
  const script = "@(Get-CimInstance Win32_LogicalDisk | Where-Object { "+filter+" } | Select-Object -ExpandProperty DeviceID) | ConvertTo-Json -Compress";
  const { stdout } = await runFile('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 15000, maxBuffer: 8192 });
  const result = stdout.trim() ? JSON.parse(stdout.trim()) : [];
  for (const drive of Array.isArray(result) ? result : [result]) {
    if (!/^[A-Z]:$/i.test(drive)) continue;
    const root = path.join(drive + path.sep, 'Obsidian');
    if ((await fs.stat(root).catch(() => null))?.isDirectory()) return await fs.realpath(root);
  }
  return null;
}
function within(root, relative) {
  if (typeof relative !== 'string' || path.isAbsolute(relative)) throw new Error('Fonte non valida.');
  const target = path.resolve(root, relative), check = path.relative(root, target);
  if (check.startsWith('..') || path.isAbsolute(check)) throw new Error('Fonte fuori dal vault.');
  return target;
}

class VaultMemory {
  constructor({ cachePath, encrypt, decrypt, locateVault = locateUsbVault, onStatus = () => {} }) {
    this.cachePath = cachePath; this.encrypt = encrypt; this.decrypt = decrypt; this.locateVault = locateVault; this.onStatus = onStatus;
    this.documents = []; this.chunks = []; this.postings = new Map(); this.syncPromise = null; this.lastCheck = 0;
    this.state = { phase: 'loading', files: 0, chunks: 0, empty: 0, skipped: 0, usbConnected: false, importedAt: null, error: null };
  }
  status() { return { ...this.state }; }
  report(update) { Object.assign(this.state, update); this.onStatus(this.status()); }
  async load() {
    try {
      const data = JSON.parse(this.decrypt(await fs.readFile(this.cachePath)));
      if (data.version !== 2 || !Array.isArray(data.documents)) throw new Error('Indice non compatibile.');
      this.documents = data.documents;
      this.buildIndex();
      this.report({ ...data.stats, phase: 'cached', usbConnected: false, error: null });
    } catch (error) {
      this.report({ phase: error.code === 'ENOENT' ? 'empty' : 'error', error: error.code === 'ENOENT' ? null : 'La copia della memoria non è leggibile; verrà reimportata dalla chiavetta.' });
    }
    return this.status();
  }
  sync({ force = false } = {}) {
    if (this.syncPromise) return this.syncPromise;
    if (!force && Date.now() - this.lastCheck < 60000) return Promise.resolve(this.status());
    this.syncPromise = this.performSync().catch(() => {
      this.report({ phase: this.documents.length ? 'cached' : 'error', error: 'Aggiornamento della memoria non completato. La copia precedente è conservata.' });
      return this.status();
    }).finally(() => { this.lastCheck = Date.now(); this.syncPromise = null; });
    return this.syncPromise;
  }
  async performSync() {
    const root = await this.locateVault();
    if (!root) { this.report({ phase: this.documents.length ? 'cached' : 'missing', usbConnected: false, error: null }); return this.status(); }
    this.report({ phase: 'importing', usbConnected: true, error: null });
    const files = []; let skipped = 0;
    const excluded = new Set(['node_modules', 'vendor', 'dist', 'build', 'backups', 'Templates']);
    async function walk(folder) {
      const entries = await fs.readdir(folder, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name.startsWith('.') || excluded.has(entry.name) || entry.isSymbolicLink()) continue;
        const absolute = path.join(folder, entry.name);
        if (entry.isDirectory()) await walk(absolute);
        else if (entry.isFile() && /\.md$/i.test(entry.name)) {
          if (/(?:credentials?|secrets?|passwords?|token[s]?|api[-_ ]?keys?)\.md$/i.test(entry.name)) { skipped++; continue; }
          const stat = await fs.stat(absolute);
          if (stat.size > 8 * 1024 * 1024) { skipped++; continue; }
          files.push({ relative: path.relative(root, absolute), size: stat.size, mtimeMs: stat.mtimeMs });
        }
      }
    }
    await walk(root);
    const previous = new Map(this.documents.map(d => [d.path, d]));
    const documents = []; let empty = 0, changed = 0;
    for (const file of files) {
      const old = previous.get(file.relative);
      if (old && old.size === file.size && Math.abs(old.mtimeMs - file.mtimeMs) < 1) { documents.push(old); continue; }
      let original;
      try { original = await fs.readFile(within(root, file.relative), 'utf8'); }
      catch { if (old) documents.push(old); skipped++; continue; }
      const text = redact(original.replace(/^\uFEFF/, ''));
      if (!text.trim()) { empty++; continue; }
      const title = text.match(/^#\s+(.+)$/m)?.[1]?.trim() || path.basename(file.relative, '.md');
      const date = text.match(/^(?:last_updated|updated|date):\s*["']?(\d{4}-\d{2}-\d{2})/m)?.[1]
        || path.basename(file.relative).match(/\d{4}-\d{2}-\d{2}/)?.[0] || new Date(file.mtimeMs).toISOString().slice(0, 10);
      documents.push({ id: hash(file.relative).slice(0, 20), path: file.relative, size: file.size, mtimeMs: file.mtimeMs, hash: hash(text), title: redact(title), date, chunks: chunkDocument(text) });
      changed++;
      if (documents.length % 80 === 0) await new Promise(resolve => setImmediate(resolve));
    }
    if (!changed && documents.length === previous.size && this.documents.length) {
      this.report({ phase: 'ready', usbConnected: true, changed: 0, empty, skipped, error: null });
      return this.status();
    }
    const oldDocuments = this.documents;
    this.documents = documents;
    this.buildIndex();
    const stats = { files: documents.length, chunks: this.chunks.length, empty, skipped, changed, importedAt: new Date().toISOString() };
    const encrypted = this.encrypt(JSON.stringify({ version: 2, documents, stats }));
    const temporary = this.cachePath + '.' + process.pid + '.tmp';
    try { await fs.mkdir(path.dirname(this.cachePath), { recursive: true }); await fs.writeFile(temporary, encrypted); await fs.rename(temporary, this.cachePath); }
    catch (error) { this.documents = oldDocuments; this.buildIndex(); throw error; }
    this.report({ ...stats, phase: 'ready', usbConnected: true, error: null });
    return this.status();
  }
  buildIndex() {
    this.chunks = []; this.postings = new Map(); const seen = new Set();
    // Canonical transcripts win over generated graph-node copies.
    const documents = [...this.documents].sort((a, b) => (a.path.startsWith('06 ') ? 1 : 0) - (b.path.startsWith('06 ') ? 1 : 0));
    for (const document of documents) for (const part of document.chunks) {
      if (seen.has(part.hash)) continue;
      seen.add(part.hash);
      const terms = tokens(part.text), frequency = new Map();
      for (const term of terms) frequency.set(term, (frequency.get(term) || 0) + 1);
      for (const term of tokens(document.title + ' ' + document.path)) frequency.set(term, (frequency.get(term) || 0) + 3);
      const i = this.chunks.length;
      this.chunks.push({ ...part, document, length: Math.max(1, terms.length) });
      for (const [term, count] of frequency) {
        if (!this.postings.has(term)) this.postings.set(term, new Map());
        this.postings.get(term).set(i, count);
      }
    }
    this.averageLength = this.chunks.reduce((sum, c) => sum + c.length, 0) / Math.max(1, this.chunks.length);
    this.state.files = this.documents.length; this.state.chunks = this.chunks.length;
  }
  search(query, { limit = 8, budget = 16000 } = {}) {
    const terms = [...new Set(tokens(query))].slice(0, 40), scores = new Map(), count = this.chunks.length;
    for (const term of terms) {
      const posting = this.postings.get(term); if (!posting) continue;
      const idf = Math.log(1 + (count - posting.size + .5) / (posting.size + .5));
      for (const [i, frequency] of posting) {
        const chunk = this.chunks[i];
        const bm25 = idf * frequency * 2.2 / (frequency + 1.2 * (.3 + .7 * chunk.length / this.averageLength));
        const canonical = chunk.document.path.startsWith('06 ') ? .45 : 1;
        scores.set(i, (scores.get(i) || 0) + bm25 * canonical);
      }
    }
    const ranked = [...scores].map(([i, score]) => ({ ...this.chunks[i], score })).sort((a, b) => b.score - a.score);
    const selected = [], perFile = new Map(); let used = 0;
    for (const item of ranked) {
      if ((perFile.get(item.document.path) || 0) >= 2 || used + item.text.length > budget) continue;
      // Suppress overlapping copies of the same archived message across notes.
      if (selected.some(s => s.text.length > 180 && item.text.includes(s.text.slice(0, 180)))) continue;
      selected.push(item); used += item.text.length;
      perFile.set(item.document.path, (perFile.get(item.document.path) || 0) + 1);
      if (selected.length >= limit) break;
    }
    return selected.map((item, i) => ({ ref: 'M' + (i + 1), id: item.document.id, title: item.document.title, path: item.document.path, date: item.document.date, line: item.line, endLine: item.endLine, text: item.text }));
  }
  recall(query, options = {}) {
    const results = this.search(query, options);
    const profile = this.documents.find(d => /^01 Memoria[\\/].*Identit/i.test(d.path));
    if (profile && !results.some(r => r.id === profile.id)) {
      results.push({ ref: 'P', id: profile.id, title: profile.title, path: profile.path, date: profile.date, line: 1, text: profile.chunks[0]?.text.slice(0, 2000) || '' });
    }
    return results;
  }
  async resolveSource(id) {
    const doc = this.documents.find(d => d.id === id); if (!doc) throw new Error('Fonte sconosciuta.');
    const root = await this.locateVault(); if (!root) throw new Error('Collega la chiavetta per aprire il documento originale.');
    const target = within(root, doc.path), real = await fs.realpath(target);
    const relative = path.relative(root, real);
    if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Fonte fuori dal vault.');
    return real;
  }
}
module.exports = { VaultMemory, locateUsbVault, chunkDocument, redact, tokens, within };
