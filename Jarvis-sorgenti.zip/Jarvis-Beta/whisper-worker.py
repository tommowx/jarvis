"""Multilingual final transcripts, fast Vosk activity detection, no microphone files."""
import sys, os, json, queue, threading, time, re, base64, math, importlib.util
from contextlib import nullcontext
from collections import deque
import numpy as np, vosk, sounddevice as sd
sys.stdout.reconfigure(encoding='utf-8'); sys.stdin.reconfigure(encoding='utf-8'); vosk.SetLogLevel(-1)
spec=importlib.util.spec_from_file_location('speech_recognizer',os.path.join(os.path.dirname(__file__),'speech-recognizer.py'))
decoder_module=importlib.util.module_from_spec(spec); spec.loader.exec_module(decoder_module)
audio=queue.Queue(maxsize=120); commands=queue.Queue(); jobs=queue.Queue(maxsize=3)
lock=threading.RLock(); output_lock=threading.Lock(); external='--external' in sys.argv
initial_mode=os.environ.get('JARVIS_INITIAL_MODE','once'); initial_language=os.environ.get('JARVIS_INITIAL_LANGUAGE','auto')
if initial_mode not in ['once','wake','continuous']:initial_mode='once'
if initial_language not in ['auto','it','en']:initial_language='auto'
state={'mode':initial_mode,'paused':False,'closing':False,'epoch':0,'language':initial_language,'once_pending':False,'wake_until':0,'wake_words':['jarvis','giarvis','giavis']}
def emit(kind,**data):
    with output_lock: print(json.dumps(dict(type=kind,**data),ensure_ascii=False),flush=True)
def reader():
    for line in sys.stdin:
        try:
            item=json.loads(line)
            if item.get('command')=='audio':
                if external and not state['paused'] and not state['once_pending']:
                    payload=base64.b64decode(item.get('data',''),validate=True)
                    if len(payload)<=16000:
                        try:audio.put_nowait(payload)
                        except queue.Full:emit('notice',message='Audio in attesa eccessivo: ripeti l’ultima frase.')
            else:commands.put(item)
        except Exception:pass
    commands.put({'command':'quit'})
threading.Thread(target=reader,daemon=True).start()
def invalidate():
    state['epoch']+=1;state['once_pending']=False;emit('transcribing',value=False)
    while not audio.empty():
        try:audio.get_nowait()
        except queue.Empty:break
    while not jobs.empty():
        try:jobs.get_nowait()
        except queue.Empty:break
try:
    emit('loading',message='Preparo il riconoscimento multilingue…')
    decoder=decoder_module.SpeechRecognizer(sys.argv[2]);fast=vosk.Model(sys.argv[1])
    device={'name':'Microfono con elaborazione browser'} if external else sd.query_devices(kind='input')
    rate=16000 if external else int(device['default_samplerate']); detector=vosk.KaldiRecognizer(fast,rate)
    detector.SetWords(True)
    def inference():
        while not state['closing']:
            try:epoch,pcm,language,had_words=jobs.get(timeout=.15)
            except queue.Empty:continue
            if epoch!=state['epoch']:continue
            emit('transcribing',value=True)
            try:
                result=decoder.transcribe(pcm,rate,language)
                if decoder.fallback_reason:
                    emit('notice',message=decoder.fallback_reason);decoder.fallback_reason=None
                with lock:
                    if epoch!=state['epoch'] or state['paused'] or state['closing']:continue
                    text=result.get('text','').strip();state['once_pending']=False
                    if not text:
                        if had_words and state['mode']!='wake':emit('notice',message='Non ho capito bene la frase: ripetila.')
                        continue
                    if state['mode']=='wake':
                        match=re.match(r'^(?:hey |ehi |hi )?(?:'+'|'.join(re.escape(w) for w in state['wake_words'])+r')\b[ ,.!:]*',text,re.I)
                        if match:
                            text=text[match.end():].strip();state['wake_until']=time.monotonic()+9;emit('wake')
                        elif not re.match(r'^(?:accendi|avvia) (?:i )?motori[.! ]*$',text,re.I) and time.monotonic()>state['wake_until']:continue
                        if not text:continue
                        state['wake_until']=0
                    emit('text',**{**result,'text':text})
                    if state['mode']=='once':state['closing']=True
                    elif state['mode']!='continuous':state['paused']=True
            except Exception:
                if epoch==state['epoch']:
                    state['once_pending']=False;emit('notice',message='Non ho trascritto la frase: ripetila. Nessun comando eseguito.')
            finally:
                if epoch==state['epoch']:emit('transcribing',value=False)
    threading.Thread(target=inference,daemon=True).start()
    def capture(data,frames,timing,status):
        if not state['paused'] and not state['once_pending']:
            try:audio.put_nowait(bytes(data))
            except queue.Full:pass
    buffer=bytearray(); speaking=False; quiet=0.; last_partial=''; activity_sent=False
    with (nullcontext() if external else sd.RawInputStream(samplerate=rate,blocksize=4000,dtype='int16',channels=1,callback=capture)):
        emit('ready',device=str(device['name']),engine=decoder.engine,recognitionDevice=decoder.device,multilingual=True)
        while not state['closing']:
            while not commands.empty():
                item=commands.get_nowait();kind=item.get('command');reset=False
                with lock:
                    if kind=='quit':state['closing']=True;invalidate()
                    if kind=='wake_words':state['wake_words']=[str(w) for w in item.get('value',[]) if str(w).strip()][:10]
                    if kind=='language' and item.get('value') in ['auto','it','en'] and state['language']!=item['value']:state['language']=item['value'];invalidate();reset=True
                    if kind=='mode' and item.get('value') in ['once','wake','continuous'] and state['mode']!=item['value']:state['mode']=item['value'];state['wake_until']=0;invalidate();reset=True
                    if kind=='pause' and state['paused']!=bool(item.get('value')):state['paused']=bool(item.get('value'));invalidate();reset=True
                if reset:detector.Reset();buffer.clear();speaking=False;quiet=0.;last_partial='';activity_sent=False
            if state['closing']:break
            if state['paused'] or state['once_pending']:time.sleep(.03);continue
            try:block=audio.get(timeout=.1)
            except queue.Empty:continue
            if len(block)%2:continue
            buffer.extend(block);samples=np.frombuffer(block,dtype=np.int16).astype(np.float32)/32768
            rms=float(np.sqrt(np.mean(samples*samples))) if len(samples) else 0
            if rms>.0035:speaking=True;quiet=0.
            else:quiet+=len(block)/(rate*2)
            if detector.AcceptWaveform(block):candidate=json.loads(detector.Result()).get('text','')
            else:candidate=json.loads(detector.PartialResult()).get('partial','')
            if candidate:
                if candidate!=last_partial:quiet=0.
                speaking=True
                if not activity_sent and (state['mode']!='wake' or time.monotonic()<state['wake_until']):
                    emit('speech-start',text=candidate);activity_sent=True
                if re.fullmatch(r'(?:stop|basta|fermati)',candidate,re.I) and candidate!=last_partial:emit('partial',text=candidate)
                last_partial=candidate
            if not speaking and len(buffer)>rate:buffer=buffer[-int(rate*.8):]
            if speaking and (quiet>=.85 or len(buffer)>=rate*2*30):
                try:
                    jobs.put_nowait((state['epoch'],bytes(buffer),state['language'],len(last_partial.split())>=2))
                    if state['mode']=='once':state['once_pending']=True
                except queue.Full:emit('notice',message='Sto ancora trascrivendo: ripeti l’ultima frase tra poco.')
                buffer.clear();speaking=False;quiet=0.;last_partial='';activity_sent=False;detector.Reset()
    state['closing']=True;emit('stopped')
except Exception:
    emit('error',message='Riconoscimento multilingue non disponibile. Controlla microfono e risorse vocali.');sys.exit(1)
