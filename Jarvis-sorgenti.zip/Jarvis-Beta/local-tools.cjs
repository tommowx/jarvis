const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { spawn, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const { redact, within } = require('./vault-memory.cjs');
const {guardText,negativeAction}=require('./request-language.cjs');
const { ComputerTools } = require('./computer-tools.cjs');
const { createHash } = require('node:crypto');
const plain = value => String(value).normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
const exists = async p => Boolean(await fs.stat(p).catch(() => null));

class LocalTools {
  constructor({ shell, knowledge, getSettings, saveSettings, emit, voiceResources, routines, store }) { Object.assign(this, { shell, knowledge, getSettings, saveSettings, emit, voiceResources, routines, store }); this.computer = new ComputerTools({shell,emit,getSettings}); this.projects = {}; this.apps = {}; this.lastMonitor = null; this.monitorBusy = false; }
  async init() {
    const home = os.homedir(), local = process.env.LOCALAPPDATA;
    this.projects = {
      turbostick: { name: 'TurboStick', root: path.join(local, 'TurboStick'), executable: path.join(local, 'TurboStick', 'TurboStick.exe') },
      cryptodesk: { name: 'CryptoDesk', root: path.join(local, 'CryptoDesk') },
      simio: { name: 'Simio', root: path.join(home, 'Documents', 'Simio') }
    };
    try{const roots=JSON.parse(await fs.readFile(path.join(process.env.APPDATA,'Jarvis Beta','project-roots.json'),'utf8'));for(const [id,root] of Object.entries(roots))if(this.projects[id]&&typeof root==='string'&&path.isAbsolute(root))this.projects[id].root=await fs.realpath(root);}catch{}
    const wsh = "$w=New-Object -ComObject WScript.Shell; @('Discord','Obsidian','TurboStick','Crypto Desk')|ForEach-Object {$p=Join-Path ([Environment]::GetFolderPath('Desktop')) ($_+'.lnk'); if(Test-Path -LiteralPath $p){$l=$w.CreateShortcut($p); [pscustomobject]@{name=$_;shortcut=$p;target=$l.TargetPath}}}|ConvertTo-Json -Compress";
    try { const { stdout } = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', wsh], { windowsHide: true, timeout: 10000 }); const entries = JSON.parse(stdout); for (const e of Array.isArray(entries) ? entries : [entries]) this.apps[plain(e.name).replace(/\s/g, '')] = { name: e.name, shortcut: e.shortcut }; } catch {}
    try { const { stdout } = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "@(Get-StartApps|Where-Object {$_.Name -match '^ChatGPT'}|Select-Object Name,AppID)|ConvertTo-Json -Compress"], { windowsHide: true, timeout: 10000 }); const items = JSON.parse(stdout); const app = (Array.isArray(items) ? items : [items]).find(x => x.Name === 'ChatGPT Classic') || (Array.isArray(items) ? items : [items])[0]; if (app && /^[A-Za-z0-9_.!-]+$/.test(app.AppID)) this.apps.chatgpt = { name: 'ChatGPT', appId: app.AppID }; } catch {}
    this.apps.jarvis = { name: 'Jarvis' };
    for (const [id, p] of Object.entries(this.projects)) p.available = await exists(p.root);
    return this.describe();
  }
  describe() { return { apps: Object.keys(this.apps), projects: Object.entries(this.projects).map(([id, p]) => ({ id, name: p.name, available: p.available })) }; }
  catalog() { return [
    {name:'register_project',description:'Collega un progetto a una cartella locale esistente indicata esplicitamente dall’utente, su questo PC. Non trasferisce file né account.',args:{project:'turbostick|cryptodesk|simio',root:'percorso assoluto reale fornito dall’utente'}},
    { name: 'project_status', description: 'Legge lo stato locale attuale, versione e note di TurboStick, CryptoDesk o Simio, oppure tutti.', args: { project: 'all|turbostick|cryptodesk|simio' } },
    { name: 'list_files', description: 'Elenca i file della cartella attiva di un progetto, senza modifiche.', args: { project: 'id', relative: 'sottocartella relativa facoltativa' } },
    { name: 'read_file', description: 'Legge un file di testo di progetto con percorso relativo, filtrando credenziali riconoscibili.', args: { project: 'id', relative: 'file relativo' } },
    { name: 'open_app', description: 'Apre un’app installata. Per ChatGPT e Discord prova a posizionare la finestra sui due monitor separati.', args: { app: Object.keys(this.apps).join('|') } },
    { name: 'update_project', description: 'Usa l’aggiornamento ufficiale locale di CryptoDesk solo se l’utente lo ha chiesto. Per gli altri riporta gli aggiornamenti non automatizzabili.', args: { project: 'all|turbostick|cryptodesk|simio' } },
    {name:'export_memory',description:'Esporta su richiesta la memoria accessibile in ZIP Markdown verificato, senza credenziali. USB assente: soltanto estratti cache, dichiarati. Non include chat cloud non importate o allegati binari.',args:{}},
    { name: 'search_memory', description: 'Cerca estratti nel vault importato.', args: { query: 'testo della ricerca' } },
    { name: 'remember', description: 'Salva una nuova preferenza o informazione esplicitamente fornita dall’utente nella memoria persistente.', args: { text: 'informazione da ricordare' } },
    {name:'save_routine',description:'Salva una routine richiesta dall’utente, con massimo 10 passi: open_app, project_status, set_theme, search_memory.',args:{name:'nome',steps:'array di {name,args}'}},
    {name:'run_routine',description:'Avvia una routine salvata richiesta dall’utente.',args:{name:'nome esatto da list_routines'}},
    {name:'pause_routine',description:'Richiede pausa delle routine attive al termine del passo corrente, conservando i passi completati.',args:{}},
    {name:'resume_routine',description:'Riprende una routine in pausa dal primo passo non eseguito. Non ripete passi completati; rifiuta passi incerti dopo un crash.',args:{name:'nome esatto'}},
    {name:'list_routines',description:'Elenca routine e promemoria realmente salvati.',args:{}},
    {name:'reminder',description:'Crea un promemoria locale richiesto, con durata relativa in minuti. Notifica con PC e Jarvis accesi, oppure al prossimo avvio.',args:{text:'testo promemoria',minutes:'numero positivo di minuti'}},
    {name:'jarvis_window',description:'Imposta Jarvis a schermo intero, compatto o normale.',args:{mode:'full|compact|normal'}},
    {name:'preferences',description:'Applica sottotitoli, privacy e parola di attivazione di Jarvis su richiesta esplicita.',args:{subtitles:'booleano facoltativo',privacy:'booleano facoltativo',wakeWord:'testo facoltativo',speechLanguage:'auto|it|en facoltativo',speechQuality:'balanced|precise facoltativo'}},
    { name: 'set_voice', description: 'Applica realmente volume della voce 0–100, ritmo -15–15 e timbro. Non dichiarare cambiamenti senza eseguire questo strumento.', args: {volume:'numero 0–100 facoltativo',rate:'numero -15–15 facoltativo',preset:'neural-deep|neural-natural|british|offline facoltativo'} },
    { name: 'set_theme', description: 'Modifica colore, scala e velocità del nucleo animato.', args: { accent: 'colore esadecimale #RRGGBB facoltativo', speed: 'numero 0.2–2 facoltativo', scale: 'numero 0.7–1.25 facoltativo' } },
    { name: 'monitor_projects', description: 'Attiva o disattiva il controllo dei progetti sul PC mentre Jarvis è aperto. Avvisa solo sui cambiamenti.', args: { enabled: 'booleano', minutes: 'intervallo tra 2 e 120 minuti' } },
    { name: 'open_url', description: 'Apre un indirizzo web esplicitamente fornito dall’utente.', args: { url: 'https://...' } },
    { name: 'read_web', description: 'Legge testo da un indirizzo HTTPS esplicitamente fornito dall’utente.', args: { url: 'https://...' } },
    { name: 'web_search', description: 'Apre nel browser una ricerca web richiesta dall’utente; non legge i risultati.', args: { query: 'ricerca pubblica, massimo 160 caratteri' } },
    ...this.computer.catalog(),
    { name: 'show_media', description: 'Mostra un’immagine presente nei file di un progetto.', args: { project: 'id', relative: 'immagine relativa' } }
  ]; }
  project(id) { const project = this.projects[plain(id || '').replace(/[\s_-]/g, '')]; if (!project || !project.available) throw new Error('Progetto locale non trovato.'); return project; }
  async activeRoot(project) {
    if (project.name !== 'CryptoDesk') return project.root;
    const version = (await fs.readFile(path.join(project.root, 'current.txt'), 'utf8')).trim();
    if (!/^[0-9A-Za-z.-]+$/.test(version)) throw new Error('Versione CryptoDesk non valida.');
    return within(path.join(project.root, 'versions'), version);
  }
  async status(id = 'all') {
    const ids = id === 'all' ? Object.keys(this.projects) : [plain(id).replace(/[\s_-]/g, '')];
    const snapshots = [];
    for (const key of ids) {
      const p = this.projects[key]; if (!p) throw new Error('Progetto sconosciuto.');
      const item = { id: key, name: p.name, available: p.available, checkedAt: new Date().toISOString(), root: p.root };
      if (p.available) {
        const root = await this.activeRoot(p); item.activeRoot = root;
        const entries = await fs.readdir(root, { withFileTypes: true }); item.files = entries.filter(x => x.isFile()).map(x => x.name).slice(0, 35);
        if (key === 'cryptodesk') item.version = (await fs.readFile(path.join(root, 'version.txt'), 'utf8').catch(() => 'non disponibile')).trim();
        if (key === 'turbostick') {
          const { stdout } = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "$item=Get-Item -LiteralPath (Join-Path (Join-Path $env:LOCALAPPDATA 'TurboStick') 'TurboStick.exe'); if($item.VersionInfo.ProductVersion){$item.VersionInfo.ProductVersion}else{$item.VersionInfo.FileVersion}"], { windowsHide: true, timeout: 8000 }); item.version = stdout.trim() || null;
        }
        if (key === 'simio') {
          const note = path.join(root, 'STATO_RIPRESA.md');
          item.note = redact((await fs.readFile(note, 'utf8').catch(() => 'Nota di stato non disponibile.')).slice(0, 9500));
          item.noteUpdatedAt = (await fs.stat(note).catch(() => null))?.mtime.toISOString();
        }
      }
      snapshots.push(item);
    }
    return snapshots;
  }
  async file(projectId, relative, media = false) {
    const project = this.project(projectId), root = await this.activeRoot(project);
    if (typeof relative !== 'string' || /(^|[\\/])\.|(?:secret|credential|password|token|api[_-]?key|auth)/i.test(relative)) throw new Error('Questo file non è disponibile come contenuto del progetto.');
    const target = within(root, relative), real = await fs.realpath(target), check = path.relative(root, real);
    if (check.startsWith('..') || path.isAbsolute(check)) throw new Error('Percorso fuori dal progetto.');
    const stat = await fs.stat(real); if (!stat.isFile() || stat.size > (media ? 15 * 1024 * 1024 : 512 * 1024)) throw new Error('File troppo grande o non supportato.');
    if (media) {
      const ext = path.extname(real).toLowerCase(), mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' }[ext];
      if (!mime) throw new Error('Formato immagine non supportato.');
      return { name: path.basename(real), data: `data:${mime};base64,${(await fs.readFile(real)).toString('base64')}` };
    }
    if (!/\.(md|txt|json|jsonl|py|js|cjs|mjs|ts|tsx|html|css|cs|toml|yaml|yml|xml|log)$/i.test(real)) throw new Error('Formato testuale non supportato.');
    return { project: project.name, path: relative, modifiedAt: stat.mtime.toISOString(), text: redact((await fs.readFile(real, 'utf8')).slice(0, 18000)), truncated: stat.size > 18000 };
  }
  async openApp(name) {
    const id = plain(name).replace(/[\s_-]/g, ''), app = this.apps[id]; if (!app) throw new Error('App non registrata. Disponibili: ' + Object.keys(this.apps).join(', '));
    if (id === 'jarvis') { this.emit('show-window'); return { opened: 'Jarvis' }; }
    if (app.appId) spawn('explorer.exe', ['shell:AppsFolder\\' + app.appId], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
    else { const error = await this.shell.openPath(app.shortcut); if (error) throw new Error('Windows non riesce ad aprire ' + app.name); }
    if (id === 'chatgpt' || id === 'discord') { let positioned = false; for (const delay of [2500, 6000, 11000]) setTimeout(() => { if (!positioned) void this.positionApp(id).then(r => { positioned = Boolean(r.positioned); }).catch(() => {}); }, delay).unref(); }
    return { opened: app.name, position: ['chatgpt', 'discord'].includes(id) ? 'Posizionamento sui monitor richiesto; dipende dalla finestra resa disponibile dall’app.' : null };
  }
  async positionApp(id) {
    const processName = id === 'discord' ? 'Discord' : 'ChatGPT'; const index = id === 'discord' ? 1 : 0;
    const packageName = id === 'chatgpt' ? this.apps.chatgpt?.appId?.split('_')[0] : null;
    if (packageName && !/^[A-Za-z0-9.-]+$/.test(packageName)) throw new Error('App non valida.');
    const filter = packageName ? " -and $_.Path -like '*" + packageName + "*'" : '';
    const script = "Add-Type -AssemblyName System.Windows.Forms; Add-Type 'using System; using System.Runtime.InteropServices; public class JarvisWindows { [DllImport(\"user32.dll\")] public static extern bool SetWindowPos(IntPtr h,IntPtr a,int x,int y,int w,int z,uint f); [DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h,int c); }'; $screens=@([System.Windows.Forms.Screen]::AllScreens|Sort-Object -Property @{Expression='Primary';Descending=$true},DeviceName); $p=Get-Process -Name '" + processName + "' -ErrorAction SilentlyContinue|Where-Object {$_.MainWindowHandle -ne 0" + filter + "}|Select-Object -First 1; if($p){$i=[Math]::Min(" + index + ",$screens.Length-1); $r=$screens[$i].WorkingArea; [JarvisWindows]::ShowWindow($p.MainWindowHandle,9)|Out-Null; $ok=[JarvisWindows]::SetWindowPos($p.MainWindowHandle,[IntPtr]::Zero,$r.X,$r.Y,$r.Width,$r.Height,4); [pscustomobject]@{positioned=$ok;screen=($i+1);screens=$screens.Length}|ConvertTo-Json -Compress}else{'{\"positioned\":false}'}";
    const { stdout } = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 10000 }); return JSON.parse(stdout.trim());
  }
  async execute(name, args = {}, user = '', signal) {
    if(negativeAction(user))throw new Error('Richiesta negativa: nessuna azione eseguita.');
    if (!this.catalog().some(t => t.name === name)) throw new Error('Azione non disponibile.');
    if (!args || typeof args !== 'object' || Array.isArray(args)) throw new Error('Parametri non validi.');
    if (this.computer.catalog().some(t=>t.name===name)) return this.computer.execute(name,args,user,signal);
    const request = plain(guardText(user));
    if (['open_app', 'open_url'].includes(name) && !/apri|avvia|lancia|accendi|mostra|vai|porta|motori/.test(request)) throw new Error('L’apertura richiede una richiesta dell’utente.');
    if(name==='pause_routine'){if(!/pausa|sospendi/i.test(request))throw new Error('Pausa non richiesta.');return this.routines.pause();}
    if(name==='export_memory'){if(/\bnon\s+(?:esport|salv|copi)/i.test(request)||!/esporta|salva|backup|copia/i.test(request)||!/memoria|ricordi|archivio/i.test(request))throw new Error('Esportazione memoria non richiesta.');return require('./portable-memory.cjs').exportMemory({messages:this.store?.messages||[],knowledge:this.knowledge,settings:this.getSettings(),routines:this.routines?.data||{}});}
    if(name==='register_project'){if(!/collega|configura|imposta|registra|salva|connect|register|set/i.test(request)||typeof args.root!=='string'||!request.includes(plain(args.root)))throw new Error('Indica la cartella del progetto da collegare nella richiesta.');const p=this.projects[args.project];if(!p)throw new Error('Progetto sconosciuto.');const root=await this.computer.filePath(args.root);if(!(await fs.stat(root)).isDirectory())throw new Error('Serve una cartella.');const file=path.join(process.env.APPDATA,'Jarvis Beta','project-roots.json');let roots={};try{roots=JSON.parse(await fs.readFile(file,'utf8'));}catch{}roots[args.project]=root;await fs.writeFile(file+'.tmp',JSON.stringify(roots,null,2));await fs.rename(file+'.tmp',file);p.root=root;p.available=true;if(args.project==='turbostick')p.executable=path.join(root,'TurboStick.exe');return{connected:true,project:p.name,root,verified:true};}
    if (name === 'project_status') return this.status(args.project || 'all');
    if (name === 'list_files') { const p = this.project(args.project), root = await this.activeRoot(p), target = within(root, args.relative || ''); const real = await fs.realpath(target); const rel = path.relative(root, real); if (rel.startsWith('..') || path.isAbsolute(rel)) throw new Error('Percorso fuori dal progetto.'); return (await fs.readdir(real, { withFileTypes: true })).filter(e => !e.name.startsWith('.')).slice(0, 120).map(e => ({ name: e.name, directory: e.isDirectory() })); }
    if (name === 'read_file') return this.file(args.project, args.relative);
    if (name === 'open_app') return this.openApp(args.app);
    if (name === 'search_memory') return this.knowledge.search(String(args.query || '').slice(0, 2000));
    if (name === 'remember') {
      if (!/ricorda|memorizza|salva|tieni a mente/.test(request)) throw new Error('Per aggiungere un ricordo serve la richiesta esplicita.');
      const text = redact(String(args.text || '').trim()).slice(0, 6000); if (!text) throw new Error('Ricordo vuoto.');
      // The user/assistant turn itself is persisted and exported by ConversationStore.
      return { saved: true, text, destination: 'Conversazione persistente Jarvis e archivio USB quando disponibile.' };
    }
    if(['save_routine','run_routine','resume_routine','list_routines','reminder'].includes(name)){if(!this.routines)throw new Error('Routine non inizializzate.');if(name==='list_routines')return this.routines.list();if(name==='save_routine'){if(!/crea|salva|imposta|aggiungi/i.test(request)||!/routine/i.test(request))throw new Error('Creazione routine non richiesta.');return this.routines.define(args.name,args.steps,user);}if(name==='run_routine'||name==='resume_routine'){if(!(name==='resume_routine'?/riprendi|continua/:/avvia|esegui|inizia|attiva/).test(request))throw new Error('Avvio routine non richiesto.');return this.routines.run(args.name,(action,data,request)=>action==='open_app'?this.openApp(data.app):this.execute(action,data,request,signal),signal,name==='resume_routine');}if(!/ricorda|promemoria|avvisa|ricordam/i.test(request))throw new Error('Promemoria non richiesto.');return this.routines.reminder(args.text,Number(args.minutes));}
    if(name==='jarvis_window'){if(!['full','compact','normal'].includes(args.mode))throw new Error('Modalità finestra non valida.');this.emit('window-mode',args.mode);return {requested:args.mode};}
    if(name==='preferences'){const patch={};for(const key of ['subtitles','privacy','wakeWord','speechLanguage','speechQuality'])if(args[key]!==undefined)patch[key]=args[key];await this.saveSettings(patch);return {applied:true,...patch};}
    if (name === 'set_voice') { if (!/voce|volume|audio|piano|forte|per.?cento|%|abbass|alza|silenzia|parl/i.test(request)) throw new Error('Modifica vocale non richiesta.'); const patch={};if(args.volume!==undefined)patch.voiceVolume=args.volume;if(args.rate!==undefined)patch.voiceRate=args.rate;if(args.preset!==undefined)patch.voicePreset=args.preset;const next=await this.saveSettings(patch);return {applied:true,volume:next.voiceVolume,rate:next.voiceRate,preset:next.voicePreset}; }
    if (name === 'set_theme') {
      if (!/cambia|modifica|colore|veloce|lento|grande|piccolo|tema|animazione|nucleo/.test(request)) throw new Error('Modifica visiva non richiesta.');
      const theme = { ...this.getSettings().theme };
      if (args.accent !== undefined) { if (!/^#[a-f0-9]{6}$/i.test(args.accent)) throw new Error('Colore non valido.'); theme.accent = args.accent; }
      for (const [k, low, high] of [['speed', .2, 2], ['scale', .7, 1.25]]) if (args[k] !== undefined) { if (typeof args[k] !== 'number' || args[k] < low || args[k] > high) throw new Error('Valore visivo fuori intervallo.'); theme[k] = args[k]; }
      await this.saveSettings({ theme }); return { applied: theme };
    }
    if (name === 'monitor_projects') { if (!/monitora|controlla|avvisa|sorveglia|disattiva/.test(request)) throw new Error('Monitoraggio non richiesto.'); if (typeof args.enabled !== 'boolean') throw new Error('Stato monitoraggio non valido.'); const minutes = Number(args.minutes || 5); if (!Number.isFinite(minutes) || minutes < 2 || minutes > 120) throw new Error('Intervallo non valido.'); await this.saveSettings({ monitoring: args.enabled, monitorMinutes: minutes }); return { enabled: args.enabled, minutes, limit: 'Controllo locale mentre questo PC e Jarvis sono accesi.' }; }
    if (name === 'update_project') {
      if (!/aggiorna|aggiornamento|installa/.test(request)) throw new Error('Aggiornamento non richiesto.');
      const ids = args.project === 'all' ? Object.keys(this.projects) : [args.project]; const results = [];
      for (const id of ids) {
        const p = this.project(id);
        if (p.name !== 'CryptoDesk') { results.push({ project: p.name, updated: false, reason: p.name === 'Simio' ? 'È un progetto di lavoro: non esiste un aggiornamento software da installare. Posso leggere lo stato, non avviare altre chat AI da questa app.' : 'L’aggiornamento integrato di TurboStick va attivato dalla sua finestra; nessun file è stato sostituito da Jarvis.' }); continue; }
        const script = "import importlib.util,json,sys; from pathlib import Path; p=Path(sys.argv[1]); s=importlib.util.spec_from_file_location('crypto_update',p/'updater.py'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); r=m.check_and_update(p); print(json.dumps({'project':'CryptoDesk','release':r[0],'message':r[1],'updated':r[2]},ensure_ascii=False))";
        const { stdout } = await run(path.join(this.voiceResources, 'runtime', 'python.exe'), ['-c', script, p.root], { windowsHide: true, timeout: 120000, maxBuffer: 100000 }); results.push(JSON.parse(stdout.trim()));
      }
      return results;
    }
    if (name === 'open_url' || name === 'read_web') {
      const url = new URL(args.url); if (url.protocol !== 'https:' || url.username || url.password || !user.includes(url.href) && !user.includes(args.url)) throw new Error('Fornisci direttamente l’indirizzo HTTPS da aprire o leggere.');
      if (name === 'open_url') { await this.shell.openExternal(url.href); return { opened: url.href }; }
      const response = await fetch(url, { signal: AbortSignal.timeout(20000), redirect: 'error' }); if (!response.ok) throw new Error('La pagina non è accessibile.');
      const length = Number(response.headers.get('content-length') || 0); if (length > 2e6) throw new Error('Pagina troppo grande.');
      const reader = response.body.getReader(); let size = 0; const buffers = [];
      while (true) { const next = await reader.read(); if (next.done) break; size += next.value.length; if (size > 2e6) { await reader.cancel(); throw new Error('Pagina troppo grande.'); } buffers.push(next.value); }
      const html = Buffer.concat(buffers).toString('utf8').replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
      return { url: url.href, untrustedText: redact(html).slice(0, 16000) };
    }
    if (name === 'web_search') {
      if (!/cerca|ricerca|online|internet|web/.test(request)) throw new Error('Ricerca web non richiesta.');
      const query = String(args.query || '').trim(); if (!query || query.length > 160 || redact(query) !== query) throw new Error('Ricerca non valida.');
      const url = 'https://www.google.com/search?q=' + encodeURIComponent(query); await this.shell.openExternal(url);
      return { opened: url, query, limit: 'Ricerca aperta nel browser. Non ho letto né verificato i risultati.' };
    }
    if (name === 'show_media') { const media = await this.file(args.project, args.relative, true); this.emit('media', media); return { displayed: media.name }; }
  }
  async monitor() {
    if (!this.getSettings().monitoring || this.monitorBusy) return;
    this.monitorBusy = true;
    try {
      const status = await this.status();
      const stable = status.map(p => ({ id: p.id, version: p.version, available: p.available, note: p.note?.split('\n').slice(0, 5).join('\n') }));
      const hash = createHash('sha256').update(JSON.stringify(stable)).digest('hex');
      if (this.lastMonitor && hash !== this.lastMonitor) this.emit('project-change', { text: 'È cambiato lo stato di un progetto locale. Chiedimi «come stanno i progetti?» per i dettagli.', checkedAt: new Date().toISOString() });
      this.lastMonitor = hash;
    } finally { this.monitorBusy = false; }
  }
}
module.exports = { LocalTools, plain };
