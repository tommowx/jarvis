import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

// Original scene; visual research and dependency licenses are in THIRD_PARTY.md.
const wrap = document.getElementById('orb-wrap');
const canvas = document.getElementById('orb-canvas');
const TAU = Math.PI * 2;
let renderer;
try { renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' }); }
catch { wrap.classList.add('webgl-unavailable'); }

if (renderer) {
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setClearColor(0x050912, 0);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(34, 1, .1, 40);
  camera.position.set(0, .12, 8.7);
  const root = new THREE.Group(); scene.add(root);
  scene.add(new THREE.AmbientLight(0x8fbad4, 2.1));
  const key = new THREE.DirectionalLight(0xb5faff, 5); key.position.set(-3, 4, 5); scene.add(key);
  const rim = new THREE.PointLight(0x796bff, 18, 12); rim.position.set(3, -2, 2); scene.add(rim);
  const target = new THREE.WebGLRenderTarget(600, 600, { type: THREE.HalfFloatType, samples: Math.min(4, renderer.capabilities.maxSamples) });
  const composer = new EffectComposer(renderer, target);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(600, 600), .52, .62, .78);
  composer.addPass(bloom); composer.addPass(new OutputPass());

  const uniforms = { uTime: { value: 0 }, uEnergy: { value: 0 }, uColor: { value: new THREE.Color('#4de7ff') } };
  const vertex = `
    varying vec3 vNormal; varying vec3 vView; varying vec3 vPosition; varying vec2 vUv;
    void main() {
      vUv=uv; vPosition=position; vNormal=normalize(normalMatrix*normal);
      vec4 p=modelViewMatrix*vec4(position,1.); vView=normalize(-p.xyz);
      gl_Position=projectionMatrix*p;
    }`;
  const coreMaterial = new THREE.ShaderMaterial({
    uniforms, vertexShader: vertex,
    fragmentShader: `
      uniform float uTime; uniform float uEnergy; uniform vec3 uColor;
      varying vec3 vNormal; varying vec3 vView; varying vec3 vPosition; varying vec2 vUv;
      float wave(vec3 p) {
        return sin(p.x*5.+uTime*.7)*sin(p.y*4.-uTime*.45)+sin(p.z*6.+uTime*.4)*.6;
      }
      void main() {
        vec3 n=normalize(vNormal); float facing=max(dot(n,normalize(vView)),0.);
        float fresnel=pow(1.-facing,2.8);
        float light=max(dot(n,normalize(vec3(-.7,.9,1.))),0.);
        float w=wave(vPosition*2.1);
        float threads=pow(max(0.,1.-abs(sin(w*3.6+vPosition.y*9.-uTime*.65))),13.);
        float sweep=pow(max(0.,1.-abs(vPosition.y-sin(uTime*.45)*.75)),28.);
        float meridians=pow(max(0.,sin(vUv.x*100.53)),30.)*.05;
        float latitude=pow(max(0.,sin(vUv.y*81.68)),28.)*.045;
        vec3 body=mix(vec3(.005,.017,.04),vec3(.026,.12,.18),light);
        body+=uColor*(threads*(.13+uEnergy*.18)+fresnel*(.7+uEnergy*.5)+sweep*.19+meridians+latitude);
        body+=pow(light,38.)*vec3(.55,.8,.86)*.8;
        gl_FragColor=vec4(body,1.);
      }`
  });
  const core = new THREE.Mesh(new THREE.SphereGeometry(.89, 96, 64), coreMaterial); root.add(core);
  const aura = new THREE.Mesh(new THREE.SphereGeometry(.99, 64, 48), new THREE.ShaderMaterial({
    uniforms, vertexShader: vertex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
    fragmentShader: `uniform vec3 uColor; uniform float uTime; varying vec3 vNormal; varying vec3 vView; varying vec3 vPosition;
      void main(){ float edge=pow(1.-abs(dot(normalize(vNormal),normalize(vView))),3.8);
      float lines=.7+.3*sin(vPosition.y*110.+uTime*1.5);
      gl_FragColor=vec4(uColor*1.1,edge*.22*lines); }`
  })); root.add(aura);
  const shell = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(1.07, 2)), new THREE.LineBasicMaterial({ color: 0x63c8df, transparent: true, opacity: .075 })); root.add(shell);
  const shell2 = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(1.12, 1)), new THREE.LineBasicMaterial({ color: 0x92a4f8, transparent: true, opacity: .06 })); root.add(shell2);

  const cyan = new THREE.MeshStandardMaterial({ color: 0x24879b, emissive: 0x19c7df, emissiveIntensity: .75, metalness: .72, roughness: .31 });
  const pale = new THREE.MeshStandardMaterial({ color: 0x9bd1db, emissive: 0x69c7df, emissiveIntensity: .38, metalness: .8, roughness: .3 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x0e3549, emissive: 0x074558, emissiveIntensity: .55, metalness: .82, roughness: .32 });
  const white = new THREE.MeshBasicMaterial({ color: new THREE.Color('#a9f4ff').multiplyScalar(1.65) });
  const lavender = new THREE.MeshStandardMaterial({ color: 0x495e9a, emissive: 0x6a78cf, emissiveIntensity: .6, metalness: .7, roughness: .34 });
  const moving = [], orbiters = [], panels = [];
  function arc(radius, width, start, length, material, depth = .018) {
    const shape = new THREE.Shape();
    shape.absarc(0, 0, radius + width / 2, start, start + length, false);
    shape.absarc(0, 0, radius - width / 2, start + length, start, true); shape.closePath();
    const geometry = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 36 }); geometry.translate(0, 0, -depth / 2);
    return new THREE.Mesh(geometry, material);
  }
  function ringLine(radius, color = 0x4fb2ce, opacity = .27, tube = .003) {
    return new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 5, 180), new THREE.MeshBasicMaterial({ color, transparent: true, opacity }));
  }
  function ticks(group, radius, count, color, opacity, height = .032) {
    const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity });
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(.006, height, .014), material, count);
    const matrix = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const a = i * TAU / count;
      matrix.position.set(Math.cos(a) * radius, Math.sin(a) * radius, 0);
      matrix.rotation.z = a - Math.PI / 2; matrix.scale.y = i % 8 === 0 ? 1.8 : 1;
      matrix.updateMatrix(); mesh.setMatrixAt(i, matrix.matrix);
    }
    group.add(mesh);
  }
  function band(radius, width, count, tilt, speed, primary) {
    const pivot = new THREE.Group(); pivot.rotation.set(...tilt); root.add(pivot);
    const spin = new THREE.Group(); pivot.add(spin);
    spin.add(ringLine(radius - width * .8, 0x4ba0bd, .32), ringLine(radius + width * .8, 0x81d8ed, .3));
    for (let i = 0; i < count; i++) {
      const a = i * TAU / count;
      spin.add(arc(radius, width, a + .018, TAU / count * (i % 4 === 0 ? .77 : .6), i % 5 === 0 ? primary : i % 3 === 0 ? pale : dark, .025));
      if (i % 3 === 0) spin.add(arc(radius + width * 1.25, .012, a, .035, white, .014));
    }
    ticks(spin, radius - width * 1.8, count * 6, 0x72d3e9, .53);
    moving.push({ pivot, spin, speed, tilt });
    return pivot;
  }
  band(1.37, .055, 20, [.22, -.22, -.13], .13, cyan);
  band(1.67, .075, 28, [.95, .34, .25], -.16, cyan);
  band(1.91, .043, 16, [-.58, -.38, -.2], .085, lavender);
  const outer = new THREE.Group(); root.add(outer);
  outer.add(ringLine(2.19, 0x4c99ba, .21), ringLine(2.14, 0x3b7d96, .13));
  ticks(outer, 2.16, 160, 0x82c1d2, .35, .022);
  for (let i = 0; i < 4; i++) outer.add(arc(2.19, .016, i * Math.PI / 2 + .21, .23, i % 2 ? lavender : cyan));
  moving.push({ pivot: outer, spin: outer, speed: -.025, tilt: [0, 0, 0], fixed: true });

  for (let i = 0; i < 3; i++) {
    const gyro = new THREE.Group(); gyro.rotation.set(.75 + i * .33, .55 + i * .4, i * 1.1); root.add(gyro);
    gyro.add(ringLine(1.18 + i * .04, i === 1 ? 0x8c9fe1 : 0x73dce9, .48, .005));
    const bead = new THREE.Mesh(new THREE.SphereGeometry(.018, 12, 8), white); gyro.add(bead);
    const trail = arc(1.18 + i * .04, .012, 0, .22, cyan, .008); gyro.add(trail);
    orbiters.push({ group: gyro, bead, trail, radius: 1.18 + i * .04, offset: i * 2.1, speed: .22 + i * .08 });
  }
  // Surface cells, rather than a dense network floating across the silhouette.
  for (let i = 0; i < 28; i++) {
    const y = 1 - 2 * (i + .5) / 28, a = i * 2.39996, r = Math.sqrt(1 - y * y);
    const p = new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r).multiplyScalar(1.095);
    const geo = new THREE.CircleGeometry(.036 + (i % 3) * .006, 6);
    const material = new THREE.MeshBasicMaterial({ color: i % 4 === 0 ? 0xa0b2f7 : 0x5edcea, transparent: true, opacity: .17, side: THREE.DoubleSide, depthWrite: false });
    const panel = new THREE.Mesh(geo, material); panel.position.copy(p); panel.lookAt(p.clone().multiplyScalar(2));
    root.add(panel); panels.push(panel);
  }
  const dustGeometry = new THREE.BufferGeometry(); const positions = [], colors = [];
  for (let i = 0; i < 90; i++) {
    const a = i * 2.39996, y = 1 - 2 * (i + .5) / 90, r = Math.sqrt(1 - y * y), radius = 2.25 + (i % 9) * .035;
    positions.push(Math.cos(a) * r * radius, y * radius, Math.sin(a) * r * radius);
    const c = new THREE.Color(i % 6 === 0 ? '#91a3e8' : '#619eaf'); colors.push(c.r, c.g, c.b);
  }
  dustGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  dustGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  const dust = new THREE.Points(dustGeometry, new THREE.PointsMaterial({ size: .012, vertexColors: true, transparent: true, opacity: .28, sizeAttenuation: true, depthWrite: false })); root.add(dust);

  let pointerX = 0, pointerY = 0, dragging = false, downX = 0, downY = 0, dragX = 0, dragY = 0;
  wrap.addEventListener('pointermove', event => {
    const rect = wrap.getBoundingClientRect();
    pointerX = ((event.clientX - rect.left) / rect.width - .5) * .24;
    pointerY = ((event.clientY - rect.top) / rect.height - .5) * .18;
    if (dragging) { dragX += (event.clientX - downX) * .005; dragY += (event.clientY - downY) * .004; downX = event.clientX; downY = event.clientY; wrap.dataset.draggedUntil = String(Date.now() + 250); }
  });
  wrap.addEventListener('pointerleave', () => { pointerX = pointerY = 0; dragging = false; });
  wrap.addEventListener('pointerdown', event => { dragging = true; downX = event.clientX; downY = event.clientY; });
  window.addEventListener('pointerup', () => { dragging = false; });
  const resize = () => { const size = wrap.getBoundingClientRect().width; if (!size) return; renderer.setSize(size, size, false); composer.setSize(size, size); camera.aspect = 1; camera.updateProjectionMatrix(); };
  new ResizeObserver(resize).observe(wrap); resize();
  wrap.classList.add('webgl-ready');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let previous = 0, time = 0, motion = 0, frames = 0, meterAt = 0, meterFrames = 0, fps = 0;
  let preferences = { accent: '#51deef', speed: 1, scale: 1 };
  let audioLevels={input:0,output:0};
  const normalColor = new THREE.Color('#51deef'), listeningColor = new THREE.Color('#6ff0ce'), thinkingColor = new THREE.Color('#7ca6ff');
  renderer.setAnimationLoop(now => {
    if (document.hidden || now - previous < 1000 / (reduced ? 24 : 50)) return;
    const delta = Math.min((now - previous) / 1000 || .016, .08); previous = now;
    const speaking = wrap.classList.contains('speaking'), thinking = wrap.classList.contains('thinking'), listening = wrap.classList.contains('listening');
    const target = speaking ? Math.min(1,.18+audioLevels.output*35) : thinking ? .5 : listening ? Math.min(.85,.12+audioLevels.input*10) : 0;
    motion = THREE.MathUtils.lerp(motion, target, .06); time += delta * (reduced ? .12 : (1 + motion * .5) * preferences.speed);
    uniforms.uTime.value = time; uniforms.uEnergy.value = motion;
    uniforms.uColor.value.lerp(listening ? listeningColor : thinking ? thinkingColor : normalColor, .035);
    root.rotation.y = THREE.MathUtils.lerp(root.rotation.y, pointerX + dragX + Math.sin(time * .13) * .07, .035);
    root.rotation.x = THREE.MathUtils.lerp(root.rotation.x, -pointerY + dragY, .035);
    root.position.y = Math.sin(time * .45) * .025;
    root.scale.setScalar(preferences.scale);
    core.rotation.y = time * .065; core.rotation.z = Math.sin(time * .15) * .05;
    core.scale.setScalar(1 + Math.sin(time * 1.2) * .008 + motion * .018);
    shell.rotation.set(time * .015, -time * .035, .16); shell2.rotation.set(-time * .027, time * .018, -.12);
    for (const item of moving) {
      item.spin.rotation.z = time * item.speed;
      if (!item.fixed) { item.pivot.rotation.x = item.tilt[0] + Math.sin(time * .19) * .1; item.pivot.rotation.y = item.tilt[1] + Math.cos(time * .15) * .08; }
    }
    for (const item of orbiters) {
      const a = time * item.speed + item.offset;
      item.bead.position.set(Math.cos(a) * item.radius, Math.sin(a) * item.radius, 0); item.trail.rotation.z = a - .24;
      item.group.rotation.z = Math.sin(time * .12 + item.offset) * .35;
    }
    for (let i = 0; i < panels.length; i++) panels[i].material.opacity = .035 + .07 * (.5 + .5 * Math.sin(time * .7 + i * .9));
    dust.rotation.y = time * .014; dust.rotation.z = -time * .009;
    bloom.strength = .48 + motion * .22;
    composer.render(); frames++; meterFrames++;
    if (now - meterAt >= 1000) { fps = Math.round(meterFrames * 1000 / (now - meterAt)); meterFrames = 0; meterAt = now; }
  });
  canvas.addEventListener('webglcontextlost', () => { wrap.classList.remove('webgl-ready'); wrap.classList.add('webgl-unavailable'); });
  window.jarvisVisual = { setAudioLevels:value=>{audioLevels={input:Math.max(0,Number(value.input)||0),output:Math.max(0,Number(value.output)||0)};}, setPreferences: value => { preferences = { ...preferences, ...value }; if (/^#[a-f0-9]{6}$/i.test(preferences.accent)) normalColor.set(preferences.accent); }, stats: () => ({ renderer: 'WebGL / Three.js', revision: THREE.REVISION, frames, fps, geometries: renderer.info.memory.geometries, threeDimensional: true }) };
}
