import sys, json, zipfile
from pathlib import Path

def extract(file):
 p=Path(file);extension=p.suffix.lower();parts=[];truncated=False;meta={}
 if p.stat().st_size>50*1024*1024: raise ValueError('Documento oltre 50 MB')
 if extension in ('.docx','.xlsx'):
  with zipfile.ZipFile(p) as archive:
   if len(archive.infolist())>10000 or sum(e.file_size for e in archive.infolist())>100*1024*1024: raise ValueError('Documento compresso troppo grande')
 if extension=='.pdf':
  from pypdf import PdfReader
  pdf=PdfReader(p);meta={'pages':len(pdf.pages)}
  if pdf.is_encrypted: raise ValueError('PDF protetto: serve una copia leggibile senza password')
  for i,page in enumerate(pdf.pages):
   if i>=150: truncated=True;break
   parts.append(f'[Pagina {i+1}]\n'+(page.extract_text() or ''))
   if sum(map(len,parts))>45000:truncated=True;break
 elif extension=='.docx':
  from docx import Document
  document=Document(p)
  parts=[para.text for para in document.paragraphs[:1500]]
  for table in document.tables[:40]:
   for row in table.rows[:150]:parts.append(' | '.join(cell.text for cell in row.cells[:30]))
  truncated=len(document.paragraphs)>1500 or len(document.tables)>40
 elif extension=='.xlsx':
  from openpyxl import load_workbook
  workbook=load_workbook(p,read_only=True,data_only=True);meta={'sheets':workbook.sheetnames}
  for sheet in workbook.worksheets[:8]:
   parts.append('[Foglio '+sheet.title+']')
   for row in sheet.iter_rows(min_row=1,max_row=min(sheet.max_row or 0,200),max_col=min(sheet.max_column or 0,30),values_only=True):
    parts.append(' | '.join('' if value is None else str(value) for value in row))
   if (sheet.max_row or 0)>200 or (sheet.max_column or 0)>30:truncated=True
  if len(workbook.worksheets)>8:truncated=True
  workbook.close()
 else: raise ValueError('Formato non supportato')
 text='\n'.join(parts)
 if len(text)>45000:truncated=True;text=text[:45000]
 meaningful=text
 if extension=='.pdf':
  import re
  meaningful=re.sub(r'\[Pagina \d+\]','',text).strip()
 return {'format':extension[1:],'name':p.name,'text':text,'truncated':truncated,'needsOCR':extension=='.pdf' and not meaningful,**meta}

if __name__=='__main__':
 sys.stdout.reconfigure(encoding='utf-8')
 try: print(json.dumps(extract(sys.argv[1]),ensure_ascii=False))
 except Exception as error: print(json.dumps({'error':str(error)[:300]},ensure_ascii=False));sys.exit(1)
