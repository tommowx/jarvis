﻿$ErrorActionPreference='Stop'
[Console]::InputEncoding=[Text.Encoding]::UTF8
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$data=[Console]::In.ReadToEnd()|ConvertFrom-Json
function Result($value){ConvertTo-Json -InputObject $value -Depth 6 -Compress}
if($data.operation -eq 'system_diagnostics'){
 $os=Get-CimInstance Win32_OperatingSystem
 $disks=@(Get-CimInstance Win32_LogicalDisk|Where-Object {$_.DriveType -in 2,3}|ForEach-Object {@{drive=$_.DeviceID;label=$_.VolumeName;bytes=$_.Size;freeBytes=$_.FreeSpace}})
 $processes=@(Get-Process|Sort-Object WorkingSet64 -Descending|Select-Object -First 12|ForEach-Object {@{pid=$_.Id;name=$_.ProcessName;memoryBytes=$_.WorkingSet64;cpuSecondsSinceStart=$_.CPU}})
 Result @{checkedAt=[DateTime]::UtcNow.ToString('o');ramTotalBytes=([double]$os.TotalVisibleMemorySize*1024);ramFreeBytes=([double]$os.FreePhysicalMemory*1024);disks=$disks;processesByMemory=$processes;note='CPU cumulativa in secondi, non carico istantaneo. Nessun processo modificato.'};exit
}
if($data.operation -eq 'installed_apps' -or $data.operation -eq 'launch_installed'){
 $query=[string]$data.query
 $apps=@(Get-StartApps|Where-Object { $_.Name.IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0 }|Sort-Object Name)
 if($data.operation -eq 'installed_apps'){Result @($apps|Select-Object -First 60 Name,AppID);exit}
 $exact=@($apps|Where-Object Name -eq $query)
 if($exact.Count -eq 1){$selected=$exact[0]}elseif($apps.Count -eq 1){$selected=$apps[0]}else{Result @{opened=$false;choices=@($apps|Select-Object -First 15 Name,AppID)};exit}
 Start-Process -FilePath explorer.exe -ArgumentList ('shell:AppsFolder\'+$selected.AppID) -WindowStyle Hidden
 Result @{opened=$true;name=$selected.Name};exit
}
if($data.operation -eq 'explorer_selection'){$items=@();$desktopShell=New-Object -ComObject Shell.Application;foreach($view in $desktopShell.Windows()){try{foreach($selected in $view.Document.SelectedItems()){$items+=@{path=$selected.Path;folder=$selected.IsFolder;window=$view.LocationName}}}catch{}};Result $items;exit}
if($data.operation -eq 'windows_command'){
 if($data.cwd){Set-Location -LiteralPath ([string]$data.cwd)}
 $output=& ([ScriptBlock]::Create([string]$data.script)) 2>&1|Out-String -Width 180
 if($output.Length -gt 20000){$output=$output.Substring(0,20000)+' [output troncato]'}
 $nativeExit=$LASTEXITCODE;Result @{output=$output;exitCode=$nativeExit;completed=($null -eq $nativeExit -or $nativeExit -eq 0)};exit
}
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class JarvisWindowRecord { public long Handle; public int Pid; public string Title; public string ClassName; }
public class JarvisWindowInventory {
 public delegate bool Callback(IntPtr h,IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback c,IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h,Callback c,IntPtr l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",EntryPoint="GetWindowLongW")] static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 public static void Focus(IntPtr h){uint pid;uint current=GetCurrentThreadId(),front=GetWindowThreadProcessId(GetForegroundWindow(),out pid),target=GetWindowThreadProcessId(h,out pid);bool a=false,b=false;try{if(front!=0&&front!=current)a=AttachThreadInput(current,front,true);if(target!=0&&target!=current&&target!=front)b=AttachThreadInput(current,target,true);SetForegroundWindow(h);}finally{if(b)AttachThreadInput(current,target,false);if(a)AttachThreadInput(current,front,false);}}
 public static JarvisWindowRecord Foreground(){var h=GetForegroundWindow();uint p;GetWindowThreadProcessId(h,out p);var title=new StringBuilder(1024);GetWindowText(h,title,1024);return new JarvisWindowRecord{Handle=h.ToInt64(),Pid=(int)p,Title=title.ToString()};}
 public static JarvisWindowRecord[] All(){var result=new List<JarvisWindowRecord>();EnumWindows((h,l)=>{if(IsWindowVisible(h)){var title=new StringBuilder(1024);GetWindowText(h,title,title.Capacity);if(title.Length>0){uint p;GetWindowThreadProcessId(h,out p);result.Add(new JarvisWindowRecord{Handle=h.ToInt64(),Pid=(int)p,Title=title.ToString()});}}return true;},IntPtr.Zero);return result.ToArray();}
 public static JarvisWindowRecord[] Children(long parent){var result=new List<JarvisWindowRecord>();EnumChildWindows(new IntPtr(parent),(h,l)=>{if(IsWindowVisible(h)){var cls=new StringBuilder(256);GetClassName(h,cls,256);if(cls.ToString().IndexOf("edit",StringComparison.OrdinalIgnoreCase)>=0&&(GetWindowLong(h,-16)&32)!=0)return true;var text=new StringBuilder(1024);GetWindowText(h,text,1024);uint p;GetWindowThreadProcessId(h,out p);result.Add(new JarvisWindowRecord{Handle=h.ToInt64(),Pid=(int)p,Title=text.ToString(),ClassName=cls.ToString()});}return result.Count<200;},IntPtr.Zero);return result.ToArray();}
}
'@
$visibleWindows=@([JarvisWindowInventory]::All())
if($data.operation -eq 'foreground_context'){Result ([JarvisWindowInventory]::Foreground());exit}
if($data.operation -eq 'list_windows'){$windowList=@();foreach($win in $visibleWindows|Select-Object -First 70){$proc=Get-Process -Id $win.Pid -ErrorAction SilentlyContinue;$windowList+=@{pid=$win.Pid;ProcessName=$proc.ProcessName;MainWindowTitle=$win.Title}};Result $windowList;exit}
$targetPid=[int]$data.pid
$targetProcess=Get-Process -Id $targetPid
$matchingWindows=@($visibleWindows|Where-Object {$_.Pid -eq $targetPid -and (-not $data.title -or $_.Title -eq [string]$data.title)})
if($matchingWindows.Count -gt 1){throw 'Il processo ha più finestre: specifica il titolo esatto restituito da list_windows'}
$targetWindow=$matchingWindows|Select-Object -First 1
$handle=if($targetWindow){[IntPtr][long]$targetWindow.Handle}else{[IntPtr]::Zero}
if($handle -eq 0){throw 'La finestra non è più disponibile'}
if($data.operation -eq 'inspect_window' -or $data.operation -eq 'click_control'){
 Add-Type -AssemblyName UIAutomationClient
 Add-Type -AssemblyName UIAutomationTypes
 $root=[System.Windows.Automation.AutomationElement]::FromHandle($handle)
 $all=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
 $controls=@();$scanErrors=@();$offscreenCount=0;$limit=[Math]::Min($all.Count,160)
 for($i=0;$i -lt $limit;$i++){try{$item=$all[$i].Current;if(-not $item.IsPassword){$controls+=@{index=$i;name=([string]$item.Name).Substring(0,[Math]::Min(250,([string]$item.Name).Length));offscreen=$item.IsOffscreen;type=$item.ControlType.ProgrammaticName}}}catch{$scanErrors+=@($_.Exception.Message)}}
 if($data.operation -eq 'inspect_window'){Result @{title=$targetWindow.Title;nativeControls=@([JarvisWindowInventory]::Children($handle.ToInt64()));total=$all.Count;issues=@($scanErrors|Select-Object -First 3);controls=$controls;truncated=($all.Count -gt $limit)};exit}
 $index=[int]$data.index;if($index -lt 0 -or $index -ge $all.Count){throw 'Controllo non più disponibile'}
 $element=$all[$index]
 if($element.Current.IsPassword -or $element.Current.IsOffscreen){throw 'Controllo non disponibile'}
 $pattern=$null
 if($element.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$pattern)){$pattern.Invoke();Result @{invoked=$true;name=$element.Current.Name};exit}
 if($element.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern,[ref]$pattern)){$pattern.Select();Result @{selected=$true;name=$element.Current.Name};exit}
 $element.SetFocus();Result @{focused=$true;name=$element.Current.Name;note='Controllo attivato; non supporta clic accessibile automatico'};exit
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type 'using System; using System.Runtime.InteropServices; public class JarvisControl { [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr a,int x,int y,int w,int z,uint f); [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l); }'
if($data.operation -eq 'window_control'){
 $ok=$false
 switch($data.action){
 'focus' { [JarvisControl]::ShowWindow($handle,9)|Out-Null;$ok=[JarvisControl]::SetForegroundWindow($handle) }
 'minimize' { [JarvisControl]::ShowWindow($handle,6)|Out-Null;$ok=$true }
 'maximize' { [JarvisControl]::ShowWindow($handle,3)|Out-Null;$ok=$true }
 'close' { $ok=[JarvisControl]::PostMessage($handle,16,[IntPtr]::Zero,[IntPtr]::Zero) }
 'place' {
 $screens=@([System.Windows.Forms.Screen]::AllScreens|Sort-Object -Property @{Expression='Primary';Descending=$true},DeviceName)
 $index=[int]$data.monitor-1;if($index -lt 0 -or $index -ge $screens.Length){throw 'Monitor non disponibile'}
 $area=$screens[$index].WorkingArea;$x=$area.X;$w=$area.Width
 if($data.layout -eq 'left' -or $data.layout -eq 'right'){$w=[int]($w/2);if($data.layout -eq 'right'){$x+=$w}}
 [JarvisControl]::ShowWindow($handle,9)|Out-Null;$ok=[JarvisControl]::SetWindowPos($handle,[IntPtr]::Zero,$x,$area.Y,$w,$area.Height,4)
 }
 }
 Result @{requested=$data.action;applied=$ok;pid=$targetPid;title=$targetWindow.Title};exit
}
if([JarvisControl]::IsIconic($handle)){[JarvisControl]::ShowWindow($handle,9)|Out-Null}
[void][JarvisControl]::SetForegroundWindow($handle)
Start-Sleep -Milliseconds 180
if(([JarvisWindowInventory]::Foreground()).Handle -ne $handle.ToInt64()){[JarvisWindowInventory]::Focus($handle);Start-Sleep -Milliseconds 120}
if(([JarvisWindowInventory]::Foreground()).Handle -ne $handle.ToInt64()){throw 'Windows non ha concesso il focus: nessun tasto inviato'}
if($data.operation -eq 'type_text'){
 $previous=$null;try{$previous=[System.Windows.Forms.Clipboard]::GetText()}catch{}
 try{[System.Windows.Forms.Clipboard]::SetText([string]$data.text);[System.Windows.Forms.SendKeys]::SendWait('^v');Start-Sleep -Milliseconds 300}finally{if($null -ne $previous){if($previous){[System.Windows.Forms.Clipboard]::SetText($previous)}else{[System.Windows.Forms.Clipboard]::Clear()}}}
 Result @{typed=$true;pid=$targetPid;characters=([string]$data.text).Length};exit
}
if($data.operation -eq 'press_keys'){[System.Windows.Forms.SendKeys]::SendWait([string]$data.keys);Result @{keysSent=$true;pid=$targetPid};exit}
throw 'Operazione non disponibile'
