(()=>{
 const bridge=window.jarvis;if(!bridge||bridge.isPhone)return;
 let stream,context,source,processor,sink,starting=null,epoch=0,audio=null,audioId=null;
 let prefs={},playContext,outputAnalyser,outputSource;const outputData=new Float32Array(512);let levelFrame;const levels={input:0,output:0};
 const stats={peakOutput:0,chunks:0,samples:0,active:false,echoCancellation:false,noiseSuppression:false};
 bridge.getSettings().then(value=>{prefs=value;}).catch(()=>{});bridge.onSettings(value=>{prefs=value;});
 function animateLevels(){if(outputAnalyser&&audio){outputAnalyser.getFloatTimeDomainData(outputData);levels.output=Math.sqrt(outputData.reduce((sum,n)=>sum+n*n,0)/outputData.length);stats.peakOutput=Math.max(stats.peakOutput,levels.output);}else levels.output=0;window.jarvisVisual?.setAudioLevels(levels);levelFrame=requestAnimationFrame(animateLevels);}
 animateLevels();
 async function stop(){levels.input=0;epoch++;if(processor){processor.port.onmessage=null;processor.disconnect();processor=null;}source?.disconnect();sink?.disconnect();stream?.getTracks().forEach(t=>t.stop());stream=null;stats.active=false;const old=context;context=null;await old?.close().catch(()=>{});}
 async function start(){if(stats.active||starting)return starting;const current=epoch;
  starting=(async()=>{try{
   const constraints={echoCancellation:prefs.audioProfile!=='headphones',noiseSuppression:true,autoGainControl:false,channelCount:1};if(prefs.inputDeviceId&&prefs.inputDeviceId!=='default')constraints.deviceId={exact:prefs.inputDeviceId};let capture;try{capture=await navigator.mediaDevices.getUserMedia({audio:constraints,video:false});}catch(e){if(!constraints.deviceId)throw e;delete constraints.deviceId;capture=await navigator.mediaDevices.getUserMedia({audio:constraints,video:false});}
   if(current!==epoch){capture.getTracks().forEach(t=>t.stop());return;}
   stream=capture;const properties=stream.getAudioTracks()[0].getSettings();stats.echoCancellation=Boolean(properties.echoCancellation);stats.noiseSuppression=Boolean(properties.noiseSuppression);
   context=new AudioContext();await context.audioWorklet.addModule('audio-worklet.js');if(current!==epoch){await stop();return;}
   source=context.createMediaStreamSource(stream);processor=new AudioWorkletNode(context,'jarvis-capture');sink=context.createGain();sink.gain.value=0;
   processor.port.onmessage=e=>{if(current!==epoch)return;stats.chunks++;stats.samples+=e.data.byteLength/2;const values=new Int16Array(e.data);levels.input=Math.sqrt(values.reduce((sum,n)=>sum+(n/32768)**2,0)/values.length);bridge.pushAudio(e.data);};source.connect(processor);processor.connect(sink);sink.connect(context.destination);await context.resume();stats.active=true;
  }catch(e){await stop();await bridge.audioCaptureError(String(e.message).slice(0,180)).catch(()=>{});}finally{starting=null;}})();return starting;
 }
 function stopAudio(){if(audio){const id=audioId;audio.pause();audio.removeAttribute('src');audio.load();audio=null;audioId=null;void bridge.playbackState(id,'cancelled').catch(()=>{});}}
 bridge.onVoice(event=>{
  if(event.type==='capture-start')void start();
  if(event.type==='capture-stop'||event.type==='background')void stop();
  if(event.type==='capture-restart'&&stats.active)void stop().then(start);
  if(event.type==='stop-audio')stopAudio();
  if(event.type==='audio'){
   stopAudio();if(!/^data:audio\/(?:mpeg|wav);base64,[A-Za-z0-9+/=]+$/.test(event.data))return;
   const player=new Audio(event.data);if(Number.isFinite(event.volume))player.volume=Math.max(0,Math.min(1,event.volume));audio=player;audioId=event.id;try{playContext ||=new AudioContext();outputSource=playContext.createMediaElementSource(player);outputAnalyser=playContext.createAnalyser();outputAnalyser.fftSize=512;outputSource.connect(outputAnalyser);outputAnalyser.connect(playContext.destination);void playContext.resume();}catch{outputAnalyser=null;}
   player.onplaying=()=>void bridge.playbackState(event.id,'started').catch(()=>{});
   const end=kind=>{if(audio===player){audio=null;audioId=null;}void bridge.playbackState(event.id,kind).catch(()=>{});};
   player.onended=()=>end('ended');player.onerror=()=>end('error');void player.play().catch(()=>end('error'));
  }
 });
 navigator.mediaDevices?.addEventListener('devicechange',()=>{if(stats.active)void stop().then(start);});
 window.jarvisAudio={stats:()=>({...stats,context:context?.state||'closed'}),stop};
})();
