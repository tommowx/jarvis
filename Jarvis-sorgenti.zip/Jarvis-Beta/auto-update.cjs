const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const PUBLIC=require('./update-public-key.json');
const REPO='tommowx/jarvis';
const VERSION=/^\d+\.\d+\.\d+$/;
function newer(a,b){if(!VERSION.test(a)||!VERSION.test(b))return false;const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++){if(x[i]!==y[i])return x[i]>y[i];}return false;}
function manifest(envelope,key=PUBLIC.pem){
 if(!envelope||typeof envelope.payload!=='string'||envelope.payload.length>50000||typeof envelope.signature!=='string')throw Error('Manifest aggiornamento non valido.');
 const bytes=Buffer.from(envelope.payload,'base64');if(!crypto.verify('RSA-SHA256',bytes,key,Buffer.from(envelope.signature,'base64')))throw Error('Firma aggiornamento non valida.');
 const data=JSON.parse(bytes.toString('utf8'));if(!VERSION.test(data.version)||!Array.isArray(data.assets))throw Error('Versione aggiornamento non valida.');
 for(const a of data.assets){if(!['app','voice','documents'].includes(a.id)||!/^Jarvis-[A-Za-z0-9.-]+\.zip$/.test(a.name)||! /^[a-f0-9]{64}$/.test(a.sha256)||!Number.isSafeInteger(a.bytes)||a.bytes<1||a.bytes>2147483647)throw Error('Pacchetto non valido.');if(a.url!==`https://github.com/${REPO}/releases/download/v${data.version}/${a.name}`)throw Error('Origine aggiornamento non autorizzata.');}return data;
}
async function download(url,file,asset){
 const res=await fetch(url,{signal:AbortSignal.timeout(20*60*1000),headers:{'User-Agent':'Jarvis-Updater'}});if(!res.ok)throw Error('Download non disponibile: '+res.status);
 const f=await fs.open(file,'wx'),hash=crypto.createHash('sha256');let bytes=0;
 try{for await(const chunk of res.body){bytes+=chunk.length;if(bytes>asset.bytes)throw Error('Download troppo grande.');hash.update(chunk);let offset=0;while(offset<chunk.length){const result=await f.write(chunk,offset,chunk.length-offset);if(!result.bytesWritten)throw Error('Scrittura download interrotta.');offset+=result.bytesWritten;}}if(bytes!==asset.bytes||hash.digest('hex')!==asset.sha256)throw Error('Integrità aggiornamento non valida.');}finally{await f.close();}
}
async function extractApp(zip,dest){
 const Zip=require('adm-zip'),archive=new Zip(zip),entries=archive.getEntries();if(entries.length>10000)throw Error('Pacchetto troppo esteso.');let total=0;
 for(const e of entries){const name=e.entryName;if(!name.startsWith('App/')||name.includes('\\')||name.includes(':')||name.split('/').some(x=>x==='..')||((e.attr>>>16)&0xf000)===0xa000)throw Error('Percorso pacchetto non valido.');total+=e.header.size;if(total>1500000000)throw Error('Pacchetto troppo grande.');}
 archive.extractAllTo(dest,false);const pkg=JSON.parse(await fs.readFile(path.join(dest,'App/resources/app/package.json'),'utf8'));if(!(await fs.stat(path.join(dest,'App/Jarvis.exe'))).isFile())throw Error('Programma assente.');return pkg.version;
}
class AutoUpdate{
 constructor({root,version,emit=()=>{},canApply=()=>false,visible=()=>false,quit=()=>{},publicKey,worker=path.join(__dirname,'Apply-Update.ps1')}){Object.assign(this,{root,version,emit,canApply,visible,quit,worker,publicKey});this.busy=false;this.pending=null;}
 async check(){if(this.busy)return;this.busy=true;let stage;
  try{const r=await fetch(`https://github.com/${REPO}/releases/latest/download/update.json`,{signal:AbortSignal.timeout(20000)});if(r.status===404)return;if(!r.ok)throw Error('Controllo aggiornamenti non disponibile.');const raw=await r.text();if(raw.length>70000)throw Error('Manifest troppo grande.');const m=manifest(JSON.parse(raw),this.publicKey);if(!newer(m.version,this.version))return;
   if(!m.assets.some(a=>a.id==='app'))throw Error('Programma aggiornato assente.');stage=await fs.mkdtemp(path.join(this.root,'update-'));
   let installed={};try{installed=JSON.parse((await fs.readFile(path.join(this.root,'updates/components.json'),'utf8')).replace(/^\uFEFF/,''));}catch{}
   const components={...installed};for(const a of m.assets){components[a.id]=a.sha256;if(a.id!=='app'&&installed[a.id]===a.sha256)continue;const zip=path.join(stage,a.name);await download(a.url,zip,a);if(a.id==='app'){if(await extractApp(zip,stage)!==m.version)throw Error('Versione pacchetto diversa dal manifest.');}else{await require('node:util').promisify(require('node:child_process').execFile)('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'Extract-Package.ps1'),'-Zip',zip,'-Stage',stage,'-Top',a.id],{windowsHide:true,timeout:15*60*1000});}await fs.unlink(zip);}
   await fs.writeFile(path.join(stage,'components.json'),JSON.stringify(components));await fs.copyFile(this.worker,path.join(stage,'Apply-Update.ps1'));this.pending={stage,version:m.version};this.emit('notice','Aggiornamento '+m.version+' pronto. Jarvis si riavvierà automaticamente appena inattivo.');
  }catch(e){this.emit('update-status',{error:e.message});if(stage)await fs.rm(stage,{recursive:true,force:true}).catch(()=>{});}finally{this.busy=false;}
 }
 apply(){if(!this.pending||!this.canApply()||this.busy)return false;const {stage,version}=this.pending;this.pending=null;const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(stage,'Apply-Update.ps1'),'-Root',this.root,'-Stage',stage,'-OldPid',String(process.pid),'-Version',version,...(this.visible()?['-ShowWindow']:[])],{detached:true,windowsHide:true,stdio:'ignore'});child.once('spawn',()=>{child.unref();this.quit();});child.once('error',()=>{this.pending={stage,version};});return true;}
 async healthy(){await fs.mkdir(path.join(this.root,'updates'),{recursive:true});await fs.writeFile(path.join(this.root,'updates','health-'+this.version+'.json'),JSON.stringify({version:this.version,pid:process.pid,at:Date.now()}));}
 start(){void this.healthy();const initial=setTimeout(()=>void this.check(),45000);initial.unref();this.timer=setInterval(()=>{if(this.pending)this.apply();else void this.check();},30*60*1000);this.timer.unref();this.idle=setInterval(()=>this.apply(),10000);this.idle.unref();}
}
module.exports={AutoUpdate,newer,manifest,extractApp,download};
