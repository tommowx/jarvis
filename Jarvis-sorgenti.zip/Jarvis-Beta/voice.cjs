const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
class Voice {
  constructor({ emit, resources, getPreferences = () => ({}), canListen = () => true }) { this.canListen = canListen; this.getPreferences = getPreferences; this.speechGeneration = 0; this.spokenReference = ''; this.echoUntil = 0; this.lastError = null; this.ready=false; this.emit = emit; this.resources = resources; this.worker = null; this.speaker = null; this.mode = 'off'; this.backgroundMode = 'manual'; this.paused = false; this.resumeTimer = null; }
  state() { return { error: this.lastError, available: fs.existsSync(path.join(this.resources, 'runtime', 'python.exe')), listening: Boolean(this.worker)&&!this.paused&&this.ready, running:Boolean(this.worker),engine:this.recognitionEngine||null,recognitionDevice:this.recognitionDevice||null, paused:this.paused, mode: this.mode, speaking: Boolean(this.speaker) }; }
  command(command) { if (this.worker?.stdin.writable) this.worker.stdin.write(JSON.stringify(command) + '\n'); }
  isEcho(text) { if (Date.now()>this.echoUntil) return false; const clean=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim(); const phrase=clean(text), reference=clean(this.spokenReference); if (!phrase||/^(?:stop(?: speaking| talking)?|be quiet|cancel|enough|basta|fermati|vai avanti|riprendi|resume speaking|continue speaking|go on|piu piano|parla piu piano)$/.test(phrase)) return false; if ((' '+reference+' ').includes(' '+phrase+' ')) return true; const words=phrase.split(' '), known=new Set(reference.split(' ')); return words.length>=3 && words.filter(w=>known.has(w)).length/words.length>=.85; }
  rememberSpoken(text) { this.spokenReference=(this.spokenReference+' '+text).slice(-1800); this.echoUntil=Date.now()+120000; }
  pause(value) { if (this.mode === 'continuous' && this.canListen()) value = false; if (!value && !this.canListen()) { clearTimeout(this.resumeTimer); if (this.worker) this.resumeTimer = setTimeout(() => this.pause(false),300); return; } const changed=this.paused!==value; this.paused = value; clearTimeout(this.resumeTimer); if (changed) this.command({ command: 'pause', value }); if (this.worker) this.emit({type:'listening',value:!value&&this.ready,mode:this.mode}); }
  async listen(mode = 'once', preservePause = false, forceNative = false) {
    if(this.getPreferences().privacy)throw new Error('Modalità riservata attiva: riattivala dalle impostazioni prima di usare il microfono.');
    if (!['once', 'wake', 'continuous'].includes(mode)) throw new Error('Modalità vocale non valida.');
    const wasPaused = this.paused; if (!preservePause) this.stopSpeech(); this.mode = mode; if (mode !== 'once') this.backgroundMode = mode;
    if (this.worker) { this.command({ command: 'mode', value: mode }); this.pause(false); return this.state(); }
    const python = path.join(this.resources, 'runtime', 'python.exe');
    const model = path.join(this.resources, 'model');
    if (!fs.existsSync(python) || !fs.existsSync(model)) throw new Error('Risorse vocali locali non installate.');
    this.external=this.getPreferences().acousticEcho===true&&!forceNative;
    const quality=this.getPreferences().speechQuality||'precise';const whisper=path.join(this.resources,quality==='precise'?'whisper-small':'whisper-base');const multilingual=fs.existsSync(path.join(whisper,'model.bin'))&&fs.existsSync(path.join(this.resources,'speech-packages','faster_whisper'));this.recognitionEngine=multilingual?'whisper-'+(quality==='precise'?'small':'base')+'-int8':'vosk-it';this.emit({type:'loading',message:'Preparo il riconoscimento multilingue…'});if(!multilingual)this.emit({type:'notice',message:'Risorse multilingue assenti: riconoscimento essenziale solo italiano.'});
    const worker = spawn(python, ['-u', path.join(__dirname, multilingual?'whisper-worker.py':'voice-worker.py'), model,...(multilingual?[whisper]:[]),...(this.external?['--external']:[])], { windowsHide: true, env: { ...process.env, PYTHONPATH: [path.join(this.resources,'speech-packages'),path.join(this.resources,'site-packages')].join(path.delimiter), PYTHONIOENCODING: 'utf-8',JARVIS_INITIAL_MODE:mode,JARVIS_INITIAL_LANGUAGE:this.getPreferences().speechLanguage||'auto' }, stdio: ['pipe', 'pipe', 'pipe'] });
    this.worker = worker; if(this.external)this.emit({type:'capture-start'}); let buffer = '';
    worker.stdout.setEncoding('utf8');
    worker.stdout.on('data', data => { buffer += data; if (buffer.length > 100000) buffer = ''; let end;
      while ((end = buffer.indexOf('\n')) >= 0) { const line = buffer.slice(0, end); buffer = buffer.slice(end + 1); try { const event = JSON.parse(line); if (this.worker !== worker) continue; if (this.mode === 'continuous' && ['text','partial','speech-start'].includes(event.type) && this.isEcho(event.text)) continue; if(event.type==='text'&&event.device)this.recognitionDevice=event.device; if (event.type === 'error') this.lastError=event.message; if (event.type === 'ready') { this.lastError=null; this.ready=true;this.recognitionEngine=event.engine||this.recognitionEngine;this.recognitionDevice=event.recognitionDevice||null; this.configureWake();this.configureRecognition(); event.mode = this.mode; this.command({ command: 'mode', value: this.mode }); this.command({ command: 'pause', value: this.paused }); this.emit({type:'listening',value:!this.paused,mode:this.mode}); } this.emit(event); } catch {} }
    });
    worker.stderr.resume();
    worker.stdin.on('error', () => {});
    worker.on('error', () => { this.lastError='Impossibile avviare la voce locale.'; this.emit({ type: 'error', message: this.lastError }); });
    worker.on('exit', code => { if (this.worker === worker) { this.worker = null; this.emit({ type: 'stopped' }); if (code === 0 && this.backgroundMode !== 'manual' && this.mode !== 'off') setTimeout(() => { if (!this.worker && this.backgroundMode !== 'manual') void this.listen(this.backgroundMode, true).catch(() => {}); }, 1000).unref(); } });
    this.pause(preservePause ? wasPaused : false); return this.state();
  }
  configureWake(){const word=this.getPreferences().wakeWord||'jarvis';this.command({command:'wake_words',value:word==='jarvis'?['jarvis','giarvis','giorgis','cervis','giavis']:[word]});}
  configureRecognition(){this.command({command:'language',value:this.getPreferences().speechLanguage||'auto'});}
  acceptAudio(bytes){if(this.external&&this.worker?.stdin.writable&&this.worker.stdin.writableLength<262144)this.command({command:'audio',data:bytes.toString('base64')});}
  handlePlayback(id,state){if(!this.playback||this.playback.id!==id||!['started','ended','error','cancelled'].includes(state))return false;this.playback.event(state);return true;}
  stop() { this.emit({type:'capture-stop'}); this.ready=false; this.mode = 'off'; this.backgroundMode = 'manual'; this.command({ command: 'quit' }); const worker = this.worker; this.worker = null; if (worker) setTimeout(() => { if (worker.exitCode === null) worker.kill(); }, 1200).unref(); this.emit({ type: 'stopped' }); }
  stopSpeech() { this.emit({type:'stop-audio'}); if(this.playback){const pending=this.playback;this.playback=null;this.speechGeneration++;pending.event('cancelled');} this.echoUntil=Math.min(this.echoUntil,Date.now()+1400); this.speechGeneration++; clearTimeout(this.resumeTimer); if (this.speaker) { this.speaker.kill(); this.speaker = null; } this.emit({ type: 'speaking', value: false }); if (this.worker) this.resumeTimer = setTimeout(() => this.pause(false), 900); }
  speak(text) {
    const prefs = this.getPreferences(); if(prefs.voiceVolume===0)return Promise.resolve();
    if (prefs.voicePreset === 'offline' || !fs.existsSync(path.join(this.resources, 'neural-packages', 'edge_tts'))) return this.speakWindows(text);
    this.stopSpeech(); this.pause(true); const generation = this.speechGeneration;
    const body = String(text).replace(/```[\s\S]*?```/g, 'blocco di codice').replace(/https?:\/\/\S+/g, 'link').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/\[(?:M\d+|P)\]/g, '').replace(/[*_#>`~]/g, '').slice(0, 18000);
    return new Promise((resolve, reject) => {
      const child = spawn(path.join(this.resources, 'runtime', 'python.exe'), ['-u', path.join(__dirname, 'neural-voice.py')], { windowsHide: true, env: { ...process.env, PYTHONPATH: path.join(this.resources, 'neural-packages'), PYTHONIOENCODING: 'utf-8' }, stdio: ['pipe', 'pipe', 'ignore'] });
      const browser=prefs.acousticEcho===true; let hasAudio=false,stdout='',settled=false,playTimer;
      this.speaker=child;this.emit({type:'preparing'});
      child.stdin.on('error',()=>{});child.stdin.end(JSON.stringify({text:body,preset:prefs.voicePreset||'neural-deep',rate:prefs.voiceRate??-4,volume:prefs.voiceVolume??20,synthesize_only:browser}),'utf8');
      const done=code=>{
        if(settled)return;settled=true;clearTimeout(playTimer);if(this.playback?.id===generation)this.playback=null;
        if(generation!==this.speechGeneration)return resolve();this.speaker=null;this.echoUntil=Date.now()+1400;this.emit({type:'speaking',value:false});
        if(code!==0){this.emit({type:'notice',message:'Voce naturale non raggiungibile: uso la voce offline.'});this.speakWindows(text).then(resolve,reject);}else{this.resumeTimer=setTimeout(()=>this.pause(false),900);resolve();}
      };
      child.stdout.on('data',data=>{stdout+=data.toString('utf8');if(stdout.length>5000000){child.kill();done(1);return;}let end;
        while((end=stdout.indexOf('\n'))>=0){const line=stdout.slice(0,end);stdout=stdout.slice(end+1);let event;try{event=JSON.parse(line);}catch{continue;}
          if(generation!==this.speechGeneration)continue;
          if(event.type==='playing'){this.rememberSpoken(body);this.emit({type:'speaking',value:true});}
          if(event.type==='audio'&&browser){hasAudio=true;this.playback={id:generation,event:state=>{if(state==='started'){this.rememberSpoken(body);this.emit({type:'speaking',value:true});}else done(state==='error'?1:0);}};playTimer=setTimeout(()=>{this.emit({type:'stop-audio'});done(1);},120000);this.emit({type:'audio',id:generation,data:'data:audio/mpeg;base64,'+event.data});}
        }
      });
      child.on('error',()=>done(1));child.on('exit',code=>{if(code!==0||!browser||!hasAudio)done(code||(!hasAudio&&browser?1:0));});

    });
  }
  speakWindows(text) {
    this.stopSpeech(); this.pause(true);
    const body = String(text).replace(/```[\s\S]*?```/g, 'blocco di codice').replace(/https?:\/\/\S+/g, 'link').replace(/\[(?:M\d+|P)\]/g, '').replace(/[*_#>`~]/g, '').slice(0, 18000);
    const script = "$ErrorActionPreference='Stop'; [Console]::InputEncoding=[System.Text.Encoding]::UTF8; Add-Type -AssemblyName System.Speech; $data=[Console]::In.ReadToEnd()|ConvertFrom-Json; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $voices=@($s.GetInstalledVoices()|ForEach-Object {$_.VoiceInfo}); $voice=$voices|Where-Object {$_.Name -match 'Cosimo'}|Select-Object -First 1; if(-not $voice){$voice=$voices|Where-Object {$_.Culture.Name -eq 'it-IT'}|Select-Object -First 1}; if($voice){$s.SelectVoice($voice.Name)}; $s.Rate=-1; $s.Volume=[int]$data.volume; $s.Speak([string]$data.text); $s.Dispose()";
    return new Promise((resolve, reject) => {
      const process = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] });
      this.speaker = process; this.rememberSpoken(body); this.emit({ type: 'speaking', value: true });
      process.stdin.on('error', () => {});
      process.stdin.end(JSON.stringify({ text: body, volume: this.getPreferences().voiceVolume ?? 70 }), 'utf8');
      process.on('error', () => { if (this.speaker === process) this.speaker = null; this.emit({ type: 'speaking', value: false }); reject(new Error('La voce Windows non è disponibile.')); });
      process.on('exit', code => { if (this.speaker === process) { this.speaker = null; this.echoUntil=Date.now()+1400; this.emit({ type: 'speaking', value: false }); this.resumeTimer = setTimeout(() => this.pause(false), 900); } code === 0 || code === null ? resolve() : reject(new Error('Lettura interrotta.')); });
    });
  }
  close() { this.stop(); this.stopSpeech(); }
}
module.exports = { Voice };
