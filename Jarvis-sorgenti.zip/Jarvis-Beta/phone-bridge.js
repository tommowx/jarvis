if (!window.jarvis) {
  const listeners = new Map(); let pairing;
  const token = location.hash.slice(1); history.replaceState(null, '', location.pathname);
  pairing = token ? fetch('/pair', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) }).then(r => { if (!r.ok) throw new Error('Scansiona il codice di associazione sul PC.'); }) : Promise.resolve();
  let events;
  const connected = pairing.then(() => { events = new EventSource('/events'); events.onmessage = event => { try { const message = JSON.parse(event.data); for (const callback of listeners.get(message.type) || []) callback(message.data); } catch {} }; });
  const rpc = async (method, ...args) => { await connected; const response = await fetch('/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ method, args }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Jarvis sul PC non è raggiungibile.'); return data.result; };
  const on = name => callback => { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(callback); return () => listeners.get(name)?.delete(callback); };
  window.jarvis = {
    isPhone: true, getState: () => rpc('get-state'), loadMemory: () => rpc('load-memory'), getKnowledge: () => rpc('knowledge-status'), refreshKnowledge: () => rpc('refresh-knowledge'), sendMessage: messages => rpc('send-message', messages), cancel: () => rpc('cancel'),
    conversationControl:(text,status)=>rpc('conversation-control',text,status), pauseRoutine:text=>rpc('pause-routine',text), getActivities:()=>rpc('activities'), getSettings: () => rpc('get-settings'), saveSettings: settings => rpc('save-settings', settings),
    openMemorySource: async id => { const source = await rpc('source-text', id); const dialog = document.createElement('dialog'), pre = document.createElement('pre'), close = document.createElement('button'); pre.textContent = source.text; close.textContent = 'Chiudi'; close.onclick = () => { dialog.close(); dialog.remove(); }; dialog.append(close, pre); document.body.append(dialog); dialog.showModal(); },
    signIn: () => Promise.reject(new Error('Completa il collegamento ChatGPT dalla finestra sul PC.')), disconnect: () => Promise.reject(new Error('Gestisci il collegamento dal PC.')),
    onState: on('state'), onDelta: on('delta'), onSources: on('sources'), onKnowledge: on('knowledge'), onActivity: on('activity'), onConversation: on('conversation'), onSettings: on('settings'), onMedia: on('media'), onVoice: on('voice'), onDeltaReset: on('delta-reset'), onNotice: on('notice')
  };
}
