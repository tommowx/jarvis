import asyncio, ctypes, json, os, sys, tempfile, time, base64
import edge_tts

async def main():
    data = json.loads(sys.stdin.read())
    presets = {'neural-deep': ('it-IT-DiegoNeural', '-8Hz'), 'neural-natural': ('it-IT-DiegoNeural', '+0Hz'), 'british': ('en-GB-RyanNeural', '-4Hz')}
    voice, pitch = presets.get(data.get('preset'), presets['neural-deep'])
    rate = max(-15, min(15, int(data.get('rate', -4))))
    volume=max(0,min(100,int(data.get('volume',30))))
    handle, file = tempfile.mkstemp(prefix='jarvis-voice-', suffix='.mp3'); os.close(handle)
    alias = 'jarvis_speech'
    winmm = ctypes.windll.winmm
    def command(text):
        error = winmm.mciSendStringW(text, None, 0, None)
        if error: raise RuntimeError('Riproduzione audio non disponibile')
    try:
        await asyncio.wait_for(edge_tts.Communicate(str(data['text']), voice, rate=f'{rate:+d}%', pitch=pitch, volume=f'{volume-100:+d}%').save(file), timeout=25)
        if data.get('synthesize_only'):
            with open(file,'rb') as audio_file: print(json.dumps({'type':'audio','data':base64.b64encode(audio_file.read()).decode('ascii')}),flush=True)
            return
        command(f'open "{file}" type mpegvideo alias {alias}')
        command(f'setaudio {alias} volume to 1000')
        command(f'play {alias}')
        print(json.dumps({'type': 'playing'}), flush=True)
        while True:
            state = ctypes.create_unicode_buffer(64)
            if winmm.mciSendStringW(f'status {alias} mode', state, 64, None): break
            if state.value != 'playing': break
            time.sleep(.08)
    finally:
        winmm.mciSendStringW(f'close {alias}', None, 0, None)
        try: os.unlink(file)
        except OSError: pass

try: asyncio.run(main())
except Exception:
    print(json.dumps({'type': 'error', 'message': 'Voce naturale online non disponibile'}), flush=True)
    sys.exit(1)
