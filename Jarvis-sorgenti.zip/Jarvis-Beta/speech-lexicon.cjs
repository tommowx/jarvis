const fs=require('node:fs/promises'),path=require('node:path');
class SpeechLexicon{
 constructor(file){this.file=file;this.entries=[];this.queue=Promise.resolve();}
 async load(){try{this.entries=JSON.parse(await fs.readFile(this.file,'utf8'));if(!Array.isArray(this.entries))throw Error();}catch(e){if(e.code!=='ENOENT')throw Error('Dizionario voce non leggibile.');}return this;}
 async add(heard,correct){if(typeof heard!=='string'||typeof correct!=='string'||heard.trim().length<2||heard.length>80||!correct.trim()||correct.length>80||/[\r\n<>]/.test(heard+correct))throw Error('Correzione vocale non valida.');const job=this.queue.then(async()=>{const old=this.entries.findIndex(x=>x.heard.toLocaleLowerCase()===heard.trim().toLocaleLowerCase());const entry={heard:heard.trim(),correct:correct.trim()};if(old>=0)this.entries[old]=entry;else{if(this.entries.length>=200)throw Error('Dizionario pieno.');this.entries.push(entry);}await fs.mkdir(path.dirname(this.file),{recursive:true});await fs.writeFile(this.file+'.next',JSON.stringify(this.entries));await fs.rename(this.file+'.next',this.file);return entry;});this.queue=job.catch(()=>{});return job;}
 apply(text){let result=String(text);for(const e of [...this.entries].sort((a,b)=>b.heard.length-a.heard.length)){const escaped=e.heard.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');result=result.replace(new RegExp('(?<![\\p{L}\\p{N}])'+escaped+'(?![\\p{L}\\p{N}])','giu'),()=>e.correct);}return result;}
 hints(){return ['Jarvis','TurboStick','CryptoDesk','Simio','Obsidian','ChatGPT','Discord',...this.entries.map(x=>x.correct)].join(', ').slice(0,1800);}
}
module.exports={SpeechLexicon};
