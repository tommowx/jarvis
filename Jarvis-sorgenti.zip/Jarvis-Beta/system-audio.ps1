$ErrorActionPreference='Stop'
$data=[Console]::In.ReadToEnd()|ConvertFrom-Json
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class AudioEnumerator {}
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IDevices {
 int EnumAudioEndpoints(int flow,int state,out IntPtr devices);
 int GetDefaultAudioEndpoint(int flow,int role,out IDevice device);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IDevice {
 int Activate(ref Guid id,int context,IntPtr activation,[MarshalAs(UnmanagedType.IUnknown)]out object instance);
}
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IVolume {
 int RegisterControlChangeNotify(IntPtr notify); int UnregisterControlChangeNotify(IntPtr notify); int GetChannelCount(out uint count);
 int SetMasterVolumeLevel(float level,Guid context); int SetMasterVolumeLevelScalar(float level,Guid context);
 int GetMasterVolumeLevel(out float level); int GetMasterVolumeLevelScalar(out float level);
 int SetChannelVolumeLevel(uint channel,float level,Guid context); int SetChannelVolumeLevelScalar(uint channel,float level,Guid context);
 int GetChannelVolumeLevel(uint channel,out float level); int GetChannelVolumeLevelScalar(uint channel,out float level);
 int SetMute([MarshalAs(UnmanagedType.Bool)]bool mute,Guid context); int GetMute([MarshalAs(UnmanagedType.Bool)]out bool mute);
}
public static class JarvisAudio {
 static IVolume Endpoint(){IDevice device;Marshal.ThrowExceptionForHR(((IDevices)new AudioEnumerator()).GetDefaultAudioEndpoint(0,1,out device));object obj;Guid id=typeof(IVolume).GUID;Marshal.ThrowExceptionForHR(device.Activate(ref id,23,IntPtr.Zero,out obj));return (IVolume)obj;}
 public static float Get(){float v;Marshal.ThrowExceptionForHR(Endpoint().GetMasterVolumeLevelScalar(out v));return v*100;}
 public static bool Muted(){bool v;Marshal.ThrowExceptionForHR(Endpoint().GetMute(out v));return v;}
 public static void Set(float value){if(value<0||value>100)throw new ArgumentException();Marshal.ThrowExceptionForHR(Endpoint().SetMasterVolumeLevelScalar(value/100,Guid.Empty));}
 public static void Mute(bool value){Marshal.ThrowExceptionForHR(Endpoint().SetMute(value,Guid.Empty));}
}
'@
$before=@{volume=[Math]::Round([JarvisAudio]::Get(),2);muted=[JarvisAudio]::Muted()}
if($null -ne $data.volume){[JarvisAudio]::Set([float]$data.volume)}
if($null -ne $data.muted){[JarvisAudio]::Mute([bool]$data.muted)}
@{before=$before;volume=[Math]::Round([JarvisAudio]::Get(),2);muted=[JarvisAudio]::Muted();device='Uscita predefinita Windows';verified=$true}|ConvertTo-Json -Compress
