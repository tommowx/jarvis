const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {execFile}=require('node:child_process'),run=require('node:util').promisify(execFile);
const {redact}=require('./vault-memory.cjs'),{negativeAction,actualRequest}=require('./request-language.cjs');
const TASK_FILE='JARVIS-ATTIVITA.json';
const queues=new Map();
async function tasks(root){
 const file=path.join(await fs.realpath(root),TASK_FILE),st=await fs.lstat(file).catch(e=>{if(e.code==='ENOENT')return null;throw e});
 if(!st)return{version:1,tasks:[]};if(!st.isFile()||st.isSymbolicLink()||st.size>256000)throw Error('Archivio attività non valido: file conservato.');
 const data=JSON.parse(await fs.readFile(file,'utf8'));if(data.version!==1||!Array.isArray(data.tasks)||data.tasks.length>300||data.tasks.some(t=>!t||! /^[a-f0-9-]{36}$/.test(t.id)||typeof t.title!=='string'||!['todo','doing','blocked','done'].includes(t.status)))throw Error('Formato attività non valido: file conservato.');return data;
}
async function updateTask(root,args,user,project){
 const request=actualRequest(user);if(negativeAction(request)||!request.toLowerCase().replace(/\s/g,'').includes(project.toLowerCase().replace(/\s/g,'')))throw Error('Indica il progetto nella richiesta di modifica attività.');
 const action=args.action;if(!['add','status'].includes(action))throw Error('Azione attività non valida.');
 if(!/aggiung|crea|salva|segna|imposta|metti|completa|chiudi|sposta|add|create|save|mark|set|complete|close|move/i.test(request))throw Error('Modifica attività non richiesta.');
 root=await fs.realpath(root);const previous=queues.get(root)||Promise.resolve();const work=previous.catch(()=>{}).then(async()=>{
  const data=await tasks(root);let task;
  if(action==='add'){if(typeof args.title!=='string'||!args.title.trim()||args.title.length>300)throw Error('Titolo attività non valido.');const title=redact(args.title.trim());const existing=data.tasks.find(t=>t.title.toLowerCase()===title.toLowerCase()&&t.status!=='done');if(existing)return{task:existing,duplicate:true,saved:true,source:path.join(root,TASK_FILE)};if(data.tasks.length>=300)throw Error('Archivio attività pieno.');task={id:crypto.randomUUID(),title,status:'todo',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};data.tasks.push(task);}
  else{task=data.tasks.find(t=>t.id===args.id);if(!task)throw Error('Attività non trovata: usa prima project_tasks list.');if(!['todo','doing','blocked','done'].includes(args.status))throw Error('Stato attività non valido.');task.status=args.status;task.updatedAt=new Date().toISOString();}
  const target=path.join(root,TASK_FILE),temp=target+'.'+crypto.randomUUID()+'.next';await fs.writeFile(temp,JSON.stringify(data,null,2),{flag:'wx'});try{await fs.rename(temp,target);}catch(e){await fs.unlink(temp).catch(()=>{});throw e;}const check=await tasks(root);if(JSON.stringify(check)!==JSON.stringify(data))throw Error('Attività salvata ma verifica fallita.');return{saved:true,verified:true,task,source:target};
 });queues.set(root,work);try{return await work;}finally{if(queues.get(root)===work)queues.delete(root);}
}
async function brief(root){
 root=await fs.realpath(root);const sources=[],signals=[],recent=[],stack=[[root,0]];let scanned=0,truncated=false,total=0;
 while(stack.length){const [folder,depth]=stack.pop();for(const e of await fs.readdir(folder,{withFileTypes:true}).catch(()=>[])){
  if(++scanned>1500){truncated=true;stack.length=0;break;}if(e.isSymbolicLink()||e.name.startsWith('.')||/node_modules|^vendor$|^runtime$|^packages$|^data$|^versions$|^backups?$|^logs?$|__pycache__|^dist$|^build$/i.test(e.name))continue;
  const file=path.join(folder,e.name);if(e.isDirectory()){if(depth<2)stack.push([file,depth+1]);continue;}if(!e.isFile()||!/\.(md|txt|json|py|js|cjs|mjs|ts|tsx|cs|html|css)$/i.test(e.name)||/secret|credential|password|token|auth|session|account|cookie/i.test(e.name))continue;
  const real=await fs.realpath(file).catch(()=>null);if(!real||!real.startsWith(root+path.sep))continue;const st=await fs.stat(real);const rel=path.relative(root,real);recent.push({file:rel,modifiedAt:st.mtime.toISOString()});
  if(!/^(?:readme|stato(?:[_ -].*)?|status|todo|tasks|roadmap|next[_ -]?steps|piano(?:[_ -].*)?|package|version)(?:\.[^.]+)$/i.test(e.name)||st.size>256000||total>=24000||sources.length>=12)continue;
  const text=redact((await fs.readFile(real,'utf8')).slice(0,Math.min(5000,24000-total)));total+=text.length;sources.push({file:rel,modifiedAt:st.mtime.toISOString(),text,truncated:st.size>Buffer.byteLength(text)});
  for(const [i,line]of text.split(/\r?\n/).entries())if(/\[ \]|\bTODO\b|prossim|da fare|bloccat|in corso|next step|blocked|pending/i.test(line)&&signals.length<30)signals.push({file:rel,line:i+1,text:line.trim().slice(0,350)});
 }}
 let git=null;if(await fs.lstat(path.join(root,'.git')).catch(()=>null)){try{const opts={windowsHide:true,timeout:6000,maxBuffer:16000,env:{...process.env,GIT_TERMINAL_PROMPT:'0',GIT_OPTIONAL_LOCKS:'0'}};const {stdout:top}=await run('git',['-c','core.fsmonitor=false','-C',root,'rev-parse','--show-toplevel'],opts);if(path.resolve(top.trim()).toLowerCase()===root.toLowerCase()){const {stdout}=await run('git',['-c','core.fsmonitor=false','-C',root,'status','--short','--branch','--untracked-files=no'],opts);const log=await run('git',['-c','core.fsmonitor=false','-C',root,'log','-3','--format=%h %cs %s'],opts).catch(()=>({stdout:''}));git={status:redact(stdout),commits:redact(log.stdout)};}}catch{git={error:'Stato Git non disponibile.'};}}
 const activity=await tasks(root).catch(e=>({tasks:[],error:e.message}));return{checkedAt:new Date().toISOString(),sources,openSignals:signals,recentFiles:recent.sort((a,b)=>b.modifiedAt.localeCompare(a.modifiedAt)).slice(0,8),git,tasks:activity.tasks,taskError:activity.error||null,taskSource:path.join(root,TASK_FILE),scan:{files:scanned,truncated,depth:2},scope:'Riepilogo di file locali e attività salvate, non verifica del funzionamento del progetto. I punti aperti citati dai documenti possono essere superati: considerare data e fonte.'};
}
module.exports={brief,tasks,updateTask,TASK_FILE};
