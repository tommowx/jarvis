"""Controlled synthetic speech comparison; never records the user's microphone."""
import sys, os, json, time, asyncio, re, unicodedata
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8'); sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import edge_tts, numpy as np, vosk
from faster_whisper.audio import decode_audio
from importlib.util import spec_from_file_location, module_from_spec
spec=spec_from_file_location('speech_recognizer',Path(__file__).resolve().parent.parent/'speech-recognizer.py');module=module_from_spec(spec);spec.loader.exec_module(module)
root=Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'voice'; fixtures=Path(__file__).resolve().parent.parent/'docs'/'stt-fixtures';fixtures.mkdir(parents=True,exist_ok=True)
cases=[('italian','Vorrei controllare lo stato dei nostri progetti e abbassare il volume della voce al cinque per cento.','it-IT-DiegoNeural'),('english','Please open Discord and check the latest project updates.','en-GB-RyanNeural'),('mixed','Apri CryptoDesk e poi controlla il progetto TurboStick. Show me the latest update.','it-IT-DiegoNeural'),('names','Jarvis, controlla il progetto Simio e apri Obsidian.','it-IT-DiegoNeural')]
async def generate():
    for name,text,voice in cases:
        file=fixtures/(name+'.mp3')
        if not file.exists(): await edge_tts.Communicate(text,voice,rate='-5%').save(str(file))
asyncio.run(generate())
vosk.SetLogLevel(-1); old=vosk.Model(str(root/'model'));started=time.monotonic();recognizer=module.SpeechRecognizer(str(root/os.environ.get('JARVIS_STT_MODEL','whisper-small')));print(json.dumps({'loadedMs':round((time.monotonic()-started)*1000)}),flush=True)
def words(text):
    text=module.canonical_names(text).lower();text=''.join(c for c in unicodedata.normalize('NFD',text) if not unicodedata.combining(c));return re.findall(r'[a-z0-9]+',text)
def wer(expected,actual):
    a,b=words(expected),words(actual);d=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,d[j]+1,d[j-1]+(x!=y)))
        d=row
    return round(d[-1]/max(1,len(a)),3)
results=[]
for name,text,_ in cases:
    samples=decode_audio(str(fixtures/(name+'.mp3')));pcm=(np.clip(samples,-1,1)*32767).astype(np.int16).tobytes();baseline=vosk.KaldiRecognizer(old,16000);parts=[]
    for n in range(0,len(pcm),3200):
        if baseline.AcceptWaveform(pcm[n:n+3200]):parts.append(json.loads(baseline.Result()).get('text',''))
    parts.append(json.loads(baseline.FinalResult()).get('text',''));previous=' '.join(parts);new=recognizer.transcribe(pcm)
    result={'case':name,'expected':text,'previous':previous,'current':new,'previousWER':wer(text,previous),'currentWER':wer(text,new['text'])};results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
silence=recognizer.transcribe(bytes(16000*2*2));assert not silence['text']
report={'checkedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Synthetic controlled voices, not the user microphone or accents. WER on only four samples; not general accuracy.','results':results,'silenceRejected':True}
report['ok']=sum(r['currentWER'] for r in results)<sum(r['previousWER'] for r in results) and all(r['currentWER']<.4 for r in results)
(fixtures.parent/'evidence'/('speech-recognition-'+os.environ.get('JARVIS_STT_MODEL','whisper-small')+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
if not report['ok']:raise SystemExit('Benchmark thresholds not met')
