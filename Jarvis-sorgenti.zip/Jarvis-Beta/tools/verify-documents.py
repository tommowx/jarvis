import sys,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import importlib.util
spec=importlib.util.spec_from_file_location('document_worker',Path(__file__).resolve().parent.parent/'document-worker.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);extract=module.extract
from docx import Document
from openpyxl import Workbook
root=Path(tempfile.mkdtemp(prefix='jarvis-docs-'))
doc=Document();doc.add_paragraph('Jarvis documento verificato');table=doc.add_table(rows=1,cols=2);table.cell(0,0).text='Progetto';table.cell(0,1).text='Simio';doc.save(root/'sample.docx')
assert 'Simio' in extract(root/'sample.docx')['text']
book=Workbook();sheet=book.active;sheet.title='Dati';sheet.append(['Progetto','Stato']);sheet.append(['TurboStick','attivo']);book.save(root/'sample.xlsx');assert 'TurboStick' in extract(root/'sample.xlsx')['text']
stream=b'BT /F1 12 Tf 20 100 Td (Jarvis testo verificato) Tj ET'
objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream']
content=b'%PDF-1.4\n';offsets=[0]
for i,obj in enumerate(objects):offsets.append(len(content));content+=str(i+1).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
xref=len(content);content+=b'xref\n0 6\n0000000000 65535 f \n'
for off in offsets[1:]:content+=f'{off:010d} 00000 n \n'.encode()
content+=b'trailer << /Size 6 /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF'
(root/'sample.pdf').write_bytes(content);pdf=extract(root/'sample.pdf');assert 'Jarvis testo verificato' in pdf['text'];assert not pdf['needsOCR']
from pypdf import PdfWriter
blank=PdfWriter();blank.add_blank_page(300,200);blank.write(root/'scan.pdf');assert extract(root/'scan.pdf')['needsOCR']
long=Document()
for i in range(1600):long.add_paragraph('riga '*20)
long.save(root/'long.docx');assert extract(root/'long.docx')['truncated']
print(json.dumps({'ok':True,'checked':['DOCX paragraphs and tables','XLSX cells','PDF text','scanned PDF detection','bounded document extraction']}))
