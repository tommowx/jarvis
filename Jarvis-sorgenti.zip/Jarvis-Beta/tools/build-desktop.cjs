const fs = require('node:fs/promises');
const path = require('node:path');
const esbuild = require('esbuild');
(async () => {
  const root = path.resolve(__dirname, '..');
  const destination = process.env.JARVIS_BUILD_DEST || path.join(process.env.LOCALAPPDATA, 'JarvisBeta', 'App');
  await fs.mkdir(destination, { recursive: true });
  await fs.cp(path.join(root, 'node_modules', 'electron', 'dist'), destination, { recursive: true });
  const binary = path.join(destination, 'Jarvis.exe'); await fs.copyFile(path.join(destination, 'electron.exe'), binary); await fs.unlink(path.join(destination, 'electron.exe'));
  const target = path.join(destination, 'resources', 'app'); await fs.mkdir(target, { recursive: true });
  const built = await esbuild.build({ entryPoints: [path.join(root, 'main.cjs')], bundle: true, platform: 'node', format: 'cjs', external: ['electron'], outfile: path.join(target, 'main.cjs'), legalComments: 'linked', metafile: true, logLevel: 'warning' });
  for (const name of ['memory-map.js','image-setup.py','image-worker.py','media-commands.js','Extract-Package.ps1', 'system-audio.ps1', 'Apply-Update.ps1', 'update-public-key.json', 'preload.cjs', 'index.html', 'app.js', 'phone-bridge.js', 'audio-capture.js', 'audio-worklet.js','speech-flow.js', 'styles.css', 'orb.css', 'reactor.css', 'orb-scene.js', 'orb-scene.js.LEGAL.txt', 'voice-worker.py','whisper-worker.py','speech-recognizer.py', 'neural-voice.py', 'Recover-Jarvis.ps1', 'computer-worker.ps1', 'document-worker.py', 'candidate-check.cjs', 'README.md', 'THIRD_PARTY.md']) await fs.copyFile(path.join(root, name), path.join(target, name));
  await fs.writeFile(path.join(target, 'package.json'), JSON.stringify({ name: 'jarvis-beta', productName: 'Jarvis', version: JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8')).version, main: 'main.cjs', private: true }, null, 2));
  const licenses = path.join(target, 'licenses'); await fs.mkdir(licenses, { recursive: true });
  await fs.cp(path.join(root, 'licenses'), licenses, { recursive: true });
  const packages = new Set();
  for (const file of Object.keys(built.metafile.inputs)) { const tail = file.split('node_modules/').at(-1); if (tail !== file) packages.add(tail.startsWith('@') ? tail.split('/').slice(0, 2).join('/') : tail.split('/')[0]); }
  for (const name of packages) { const folder = path.join(root, 'node_modules', name); for (const file of await fs.readdir(folder).catch(() => [])) if (/^(LICENSE|LICENCE|NOTICE|COPYING)/i.test(file) && (await fs.stat(path.join(folder, file))).isFile()) await fs.copyFile(path.join(folder, file), path.join(licenses, name.replace('/', '-') + '-' + file)); }
  for (const file of await fs.readdir(path.join(root, 'vendor', 'siwc'))) if (/^(LICENSE|NOTICE)/i.test(file)) await fs.copyFile(path.join(root, 'vendor', 'siwc', file), path.join(licenses, 'OpenAI-DevKit-' + file));
  console.log(JSON.stringify({ built: true, executable: binary, main: path.join(target, 'main.cjs'), packages: packages.size }));
})().catch(error => { console.error(error); process.exitCode = 1; });
