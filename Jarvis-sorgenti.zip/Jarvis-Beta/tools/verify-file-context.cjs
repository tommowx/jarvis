const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const {ComputerTools}=require('../computer-tools.cjs');
(async()=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'jarvis-file-context-'));let privacy=false;
 const tools=new ComputerTools({shell:{},emit(){},getSettings:()=>({computerControl:true,privacy})});
 await fs.writeFile(path.join(root,'fattura ieri.pdf'),'fixture');await fs.writeFile(path.join(root,'fattura oggi.txt'),'fixture');
 const yesterday=new Date(Date.now()-86400000);await fs.utimes(path.join(root,'fattura ieri.pdf'),yesterday,yesterday);
 let result=await tools.execute('find_files',{root,query:'fattura',extension:'pdf',modified:'yesterday'},'trova il PDF di ieri');assert.equal(result.results.length,1);assert.equal(result.results[0].name,'fattura ieri.pdf');
 result=await tools.execute('find_files',{root,query:'fattura',modified:'today'},'trova fattura di oggi');assert.equal(result.results.length,1);assert.equal(result.results[0].name,'fattura oggi.txt');
 const foreground=await tools.execute('foreground_context',{},'questa finestra');assert(foreground&&typeof foreground==='object');
 const selected=await tools.execute('explorer_selection',{},'questo file');assert(selected&&typeof selected==='object');
 privacy=true;await assert.rejects(()=>tools.execute('find_files',{root},'cerca file'),/riservata/);await assert.rejects(()=>tools.execute('foreground_context',{},'questa finestra'),/riservata/);
 const report={ok:true,checkedAt:new Date().toISOString(),checks:['real filename and extension search','yesterday filter','today filter','foreground Windows context shape','Explorer selection shape without guessing','privacy blocks search and window context']};
 await fs.mkdir(path.join(__dirname,'../docs/evidence'),{recursive:true});await fs.writeFile(path.join(__dirname,'../docs/evidence/file-context.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
})().catch(e=>{console.error(e);process.exitCode=1;});
