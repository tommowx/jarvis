"""Real model through the app's external-PCM protocol. Synthetic fixtures only."""
import os,sys,json,subprocess,threading,queue,time
from pathlib import Path
import numpy as np
from faster_whisper.audio import decode_audio
sys.stdout.reconfigure(encoding='utf-8');root=Path(__file__).resolve().parent.parent;resources=Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'voice';events=queue.Queue();seen=[]
process=subprocess.Popen([sys.executable,'-u',str(root/'whisper-worker.py'),str(resources/'model'),str(resources/os.environ.get('JARVIS_STT_MODEL','whisper-small')),'--external'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',creationflags=0x08000000,env={**os.environ,'JARVIS_INITIAL_MODE':'continuous'})
def read():
 for line in process.stdout:
  try:item=json.loads(line);seen.append(item);events.put(item)
  except Exception:pass
threading.Thread(target=read,daemon=True).start()
def send(command,**data):process.stdin.write(json.dumps(dict(command=command,**data))+'\n');process.stdin.flush()
def wait(kind,timeout=25,predicate=None):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  try:item=events.get(timeout=.2)
  except queue.Empty:continue
  if item.get('type')=='error':raise RuntimeError(item)
  if item.get('type')==kind and (predicate is None or predicate(item)):return item
 raise RuntimeError('Missing worker event: '+kind)
def feed(name):
 import base64
 samples=decode_audio(str(root/'docs'/'stt-fixtures'/(name+'.mp3')));pcm=(np.clip(samples,-1,1)*32767).astype(np.int16).tobytes()+bytes(16000*2*2)
 for offset in range(0,len(pcm),3200):send('audio',data=base64.b64encode(pcm[offset:offset+3200]).decode());time.sleep(.003)
try:
 feed('english');ready=wait('ready');assert ready['engine']=='whisper-small-int8';send('mode',value='continuous');send('language',value='auto');time.sleep(.35)
 english=wait('text');assert 'open discord' in english['text'].lower(),english
 feed('mixed');mixed=wait('text');mixed_parts=[mixed];assert 'CryptoDesk' in mixed['text'] and 'TurboStick' in mixed['text'],mixed
 if 'show me' not in mixed['text'].lower():mixed_parts.append(wait('text'))
 assert 'show me' in ' '.join(p['text'] for p in mixed_parts).lower(),mixed_parts
 before=len([e for e in seen if e.get('type')=='text']);feed('english');wait('transcribing',predicate=lambda e:e.get('value') is True);send('pause',value=True);time.sleep(5);after=len([e for e in seen if e.get('type')=='text']);assert before==after,'stale transcription escaped pause'
 send('pause',value=False);send('language',value='en');time.sleep(.35);feed('english');again=wait('text');assert 'discord' in again['text'].lower();send('quit');process.wait(timeout=6)
 report={'ok':True,'checkedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Real model and protocol, synthetic audio, no live user recording.','checks':['early audio preserved during model loading','multilingual model ready','English final transcript','mixed-language project names','pause discards stale inference','language reconfiguration','recognition after resume','graceful worker shutdown'],'english':english,'mixedSegments':mixed_parts}
 (root/'docs'/'evidence'/'stt-worker.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
finally:
 if process.poll() is None:process.kill()
