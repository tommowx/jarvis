"""Pack only distributable software; never reads the user's memory/account profile."""
from pathlib import Path
import os, json, zipfile, shutil, hashlib
root=Path(__file__).resolve().parent.parent
out=root/'release';out.mkdir(exist_ok=True)
installed=Path(os.environ['JARVIS_RELEASE_APP']) if os.environ.get('JARVIS_RELEASE_APP') else Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'App'
version=json.loads((installed/'resources/app/package.json').read_text(encoding='utf-8-sig'))['version']
def pack(source,target,top,exclude=()):
    with zipfile.ZipFile(target.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
        for folder,dirs,files in os.walk(source):
            dirs[:]=[d for d in dirs if d not in exclude]
            for name in files:
                if name.endswith(('.pyc','.log')) or name.startswith('.env'): continue
                file=Path(folder)/name
                archive.write(file,str(Path(top)/file.relative_to(source)).replace('\\','/'))
    target.with_suffix('.tmp').replace(target)
    with zipfile.ZipFile(target) as archive:
        bad=archive.testzip()
        if bad:raise RuntimeError('CRC: '+bad)
    print(json.dumps({'asset':target.name,'bytes':target.stat().st_size}),flush=True)
pack(installed,out/'Jarvis-programma.zip','App',('__pycache__',))
voice=Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'voice'
# Existing immutable verified runtime can be reused for code-only releases.
if not (out/'Jarvis-voce-offline.zip').exists():pack(voice,out/'Jarvis-voce-offline.zip','voice',('__pycache__','.cache'))
if not (out/'Jarvis-documenti.zip').exists():pack(Path(os.environ['LOCALAPPDATA'])/'JarvisBeta'/'documents',out/'Jarvis-documenti.zip','documents',('__pycache__',))
with zipfile.ZipFile(out/'Jarvis-Setup.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in ('Install-Jarvis.ps1','Scarica-e-installa-Jarvis.cmd'):archive.write(root/name,name)
assets=[]
for id,name in [('app','Jarvis-programma.zip'),('voice','Jarvis-voce-offline.zip'),('documents','Jarvis-documenti.zip')]:
    file=out/name;digest=hashlib.sha256()
    with file.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
    if file.stat().st_size>=2147483648:raise RuntimeError('GitHub asset too large')
    assets.append(dict(id=id,name=name,bytes=file.stat().st_size,sha256=digest.hexdigest(),url=f'https://github.com/tommowx/jarvis/releases/download/v{version}/{name}'))
reuse=json.loads((out/'reuse-components.json').read_text()) if (out/'reuse-components.json').exists() else []
install_assets=[next((old for old in reuse if old['id']==a['id'] and old['sha256']==a['sha256'] and old['bytes']==a['bytes']),a) for a in assets]
update_assets=[a for a in assets if not any(old['id']==a['id'] and old['sha256']==a['sha256'] and old['bytes']==a['bytes'] for old in reuse)]
(out/'manifest-unsigned.json').write_text(json.dumps(dict(version=version,assets=update_assets),separators=(',',':')),encoding='utf-8')
(out/'install-unsigned.json').write_text(json.dumps(dict(schema=2,version=version,assets=install_assets),separators=(',',':')),encoding='utf-8')
print(json.dumps({'version':version,'prepared':len(assets)}),flush=True)
