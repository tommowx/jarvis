const assert=require('node:assert/strict');
const {volumeIntent}=require('../voice-commands.cjs');
const context=[{role:'user',content:'abbassa il volume'},{role:'assistant',content:'Voce al 10 per cento.'}];
const cases=[['abbassa la voce',[],10,1],['volume al cinque per cento',[],10,5],["all'uno per cento",context,10,1],['al venti percento',context,10,20],['voce al 25%',[],10,25],['voce a zero',[],10,0],['silenzia la voce',[],10,0],['parla più piano',[],15,5],['il volume',[],10,null],['come stanno i progetti',context,10,null],['non cambiare il volume',[],10,null],['non abbassare la voce',[],10,null],['cinque',context,10,5],['abbassala ancora',context,10,1],['5%',context,10,5]];
const results=cases.map(([text,history,current,expected])=>{const actual=volumeIntent(text,history,current);return{text,actual,expected,ok:actual===expected};});
console.log(JSON.stringify({ok:results.every(r=>r.ok),cases:results},null,2));assert(results.every(r=>r.ok),'Comandi volume non conformi');
