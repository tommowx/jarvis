const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),folder=path.join(root,'release');
const payload=fs.readFileSync(path.join(folder,'manifest-unsigned.json'));
const key=fs.readFileSync(path.join(process.env.LOCALAPPDATA,'JarvisBeta/publisher/release-signing.pem'));
const envelope={payload:payload.toString('base64'),signature:crypto.sign('RSA-SHA256',payload,key).toString('base64')};
const m=require('../auto-update.cjs').manifest(envelope);
fs.writeFileSync(path.join(folder,'update.json'),JSON.stringify(envelope));
console.log(JSON.stringify({signed:true,version:m.version,assets:m.assets.length}));

const installBytes=fs.readFileSync(path.join(folder,'install-unsigned.json'));const installEnvelope={payload:installBytes.toString('base64'),signature:crypto.sign('RSA-SHA256',installBytes,key).toString('base64')};require('../install-manifest.cjs').installManifest(installEnvelope);fs.writeFileSync(path.join(folder,'install.json'),JSON.stringify(installEnvelope));
