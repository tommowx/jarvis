const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { VaultMemory, within, redact, chunkDocument } = require('../vault-memory.cjs');
(async () => {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'jarvis-memory-check-'));
  const root = path.join(temp, 'Obsidian');
  for (const folder of ['01 Memoria', '02 Progetti', '04 Conversazioni']) await fs.mkdir(path.join(root, folder), { recursive: true });
  const project = path.join(root, '02 Progetti', 'TurboStick.md');
  await fs.writeFile(project, '# TurboStick\nFirmware attivo versione 3.0. Progetto dimostrativo di verifica.');
  await fs.writeFile(path.join(root, '02 Progetti', 'Crypto Desk.md'), '# Crypto Desk\nIl simulatore usa trading paper e dati di prova.');
  await fs.writeFile(path.join(root, '01 Memoria', '01 — Identità.md'), '# Identità\nPreferenza di prova: lingua italiana.');
  const fakeSecret = 'sk-test-' + 'x'.repeat(32);
  await fs.writeFile(path.join(root, '04 Conversazioni', 'Nota.md'), '# Conversazione\nParola fittizia segnalibro-verifica.\napi_key=' + fakeSecret);
  const key = crypto.randomBytes(32);
  const options = {
    cachePath: path.join(temp, 'memory.dat'), locateVault: async () => root,
    encrypt: text => { const nonce = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce); const body = Buffer.concat([cipher.update(text), cipher.final()]); return Buffer.concat([nonce, cipher.getAuthTag(), body]); },
    decrypt: bytes => { const decipher = crypto.createDecipheriv('aes-256-gcm', key, bytes.subarray(0, 12)); decipher.setAuthTag(bytes.subarray(12, 28)); return Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]).toString(); }
  };
  const memory = new VaultMemory(options); await memory.load(); await memory.sync({ force: true });
  assert.equal(memory.status().files, 4);
  assert(memory.search('turbo stick firmware').some(r => r.path.includes('TurboStick')));
  assert(memory.search('cryptodesk trading').some(r => r.path.includes('Crypto Desk')));
  assert(memory.recall('firmware').some(r => r.ref === 'P'));
  assert(!JSON.stringify(memory.documents).includes(fakeSecret));
  assert(!(await fs.readFile(options.cachePath)).includes(Buffer.from('Firmware attivo')));
  await fs.writeFile(project, '# TurboStick\nFirmware attivo versione finale 9.2, modulo nuovo aggiornato.');
  await memory.sync({ force: true });
  assert(memory.search('turbostick firmware')[0].text.includes('9.2'));
  assert(!JSON.stringify(memory.documents).includes('versione 3.0'));
  await fs.unlink(path.join(root, '02 Progetti', 'Crypto Desk.md')); await memory.sync({ force: true });
  assert.equal(memory.status().files, 3);
  const offline = new VaultMemory({ ...options, locateVault: async () => null }); await offline.load(); await offline.sync({ force: true });
  assert.equal(offline.status().phase, 'cached'); assert(offline.search('firmware')[0].text.includes('9.2'));
  await assert.rejects(() => offline.resolveSource(memory.documents[0].id), /chiavetta/);
  assert.throws(() => within(root, '..\\fuori.md'), /fuori/);
  assert.equal(redact(fakeSecret), '[CREDENZIALE OMESSA]');
  const long = chunkDocument('a'.repeat(12000)); assert(long.length >= 4); assert(long.every(c => c.text.length <= 2700));
  console.log(JSON.stringify({ ok: true, checked: ['import', 'project aliases', 'profile', 'secret redaction', 'encrypted persistence', 'incremental update', 'deletion', 'offline recovery', 'source boundaries', 'long chunks'] }));
})().catch(error => { console.error(error); process.exitCode = 1; });
