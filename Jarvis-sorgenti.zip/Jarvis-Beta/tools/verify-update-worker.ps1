$ErrorActionPreference='Stop'
$fixtureBase=Join-Path ([IO.Path]::GetTempPath()) ('jarvis-update-test-'+[guid]::NewGuid().ToString('N'))
$root=Join-Path $fixtureBase 'JarvisBeta';New-Item -ItemType Directory -Path (Join-Path $root 'updates') -Force|Out-Null
$oldLocal=$env:LOCALAPPDATA
try{
 $env:LOCALAPPDATA=$fixtureBase
 foreach($mode in @('success','failure')){
  $app=Join-Path $root 'App';New-Item -ItemType Directory -Path $app -Force|Out-Null
  $stage=Join-Path $root ('update-'+[guid]::NewGuid().ToString('N'));$candidate=Join-Path $stage 'App';New-Item -ItemType Directory -Path $candidate -Force|Out-Null
  foreach($component in @('voice','documents')){$existing=Join-Path $root $component;New-Item -ItemType Directory -Path $existing -Force|Out-Null;Set-Content -LiteralPath (Join-Path $existing 'fixture.txt') -Value 'old';$fresh=Join-Path $stage $component;New-Item -ItemType Directory -Path $fresh -Force|Out-Null;Set-Content -LiteralPath (Join-Path $fresh 'fixture.txt') -Value 'new'}
  $oldSource='using System;using System.IO;class Old {static void Main(){File.WriteAllText(Path.Combine(Environment.GetEnvironmentVariable("LOCALAPPDATA"),"rollback-started.txt"),"ok");}}'
  Add-Type -TypeDefinition $oldSource.Replace('class Old','class Old'+[guid]::NewGuid().ToString('N')) -Language CSharp -OutputAssembly (Join-Path $app 'Jarvis.exe') -OutputType ConsoleApplication
  if($mode -eq 'success'){$source='using System;using System.IO;using System.Diagnostics;class Fresh {static void Main(){string root=Environment.GetEnvironmentVariable("LOCALAPPDATA")+"/JarvisBeta";File.WriteAllText(root+"/updates/health-0.8.0.json","{\"version\":\"0.8.0\",\"pid\":"+Process.GetCurrentProcess().Id+"}");System.Threading.Thread.Sleep(120000);}}'}else{$source='class Fresh {static void Main(){}}'}
  Add-Type -TypeDefinition $source.Replace('class Fresh','class Fresh'+[guid]::NewGuid().ToString('N')) -Language CSharp -OutputAssembly (Join-Path $candidate 'Jarvis.exe') -OutputType ConsoleApplication
  $worker=Join-Path (Split-Path $PSScriptRoot) 'Apply-Update.ps1'
  $p=Start-Process powershell.exe -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',('"'+$worker+'"'),'-Root',('"'+$root+'"'),'-Stage',('"'+$stage+'"'),'-Version','0.8.0') -WindowStyle Hidden -PassThru
  $p.WaitForExit()
  if($mode -eq 'success'){
   if($p.ExitCode -ne 0 -or !(Test-Path -LiteralPath (Join-Path $stage 'Previous-App\Jarvis.exe'))){throw 'Aggiornamento fixture fallito.'}
   foreach($component in @('voice','documents')){if((Get-Content (Join-Path $root ($component+'\fixture.txt'))).Trim() -ne 'new'){throw 'Componente non aggiornato'}}
   $health=Get-Content -LiteralPath (Join-Path $root 'updates\health-0.8.0.json') -Raw|ConvertFrom-Json
   Stop-Process -Id $health.pid -Force
   Move-Item -LiteralPath $app -Destination (Join-Path $stage 'Verified-App')
  }else{
   foreach($component in @('voice','documents')){if((Get-Content (Join-Path $root ($component+'\fixture.txt'))).Trim() -ne 'old'){throw 'Componente non ripristinato'}}
   if($p.ExitCode -eq 0 -or !(Test-Path -LiteralPath (Join-Path $stage 'Failed-App\Jarvis.exe'))){throw 'Rollback fixture fallito.'}
   Start-Sleep -Milliseconds 500
   if(!(Test-Path -LiteralPath (Join-Path $fixtureBase 'rollback-started.txt'))){throw 'Versione precedente non avviata.'}
  }
 }
 @{ok=$true;checks=@('atomic app replacement','fresh startup health matched to PID','previous application retained','failed startup rolled back','previous app relaunched');fixture=$fixtureBase}|ConvertTo-Json -Compress
}finally{$env:LOCALAPPDATA=$oldLocal}
