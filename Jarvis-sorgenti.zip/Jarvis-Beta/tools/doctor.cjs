const { app, safeStorage } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
app.setName('Jarvis Beta');
app.setPath('userData', path.join(app.getPath('appData'), 'Jarvis Beta'));
app.whenReady().then(async () => {
  const { createChatGPT } = await import('@siwc/local');
  const client = createChatGPT({ appName: 'Jarvis', appId: 'jarvis-beta', redirectPort: 0, sendHostId: true,
    storageDir: path.join(app.getPath('appData'), 'Jarvis Beta', 'chatgpt'),
    credentialEncryption: { id: 'electron-safe-storage-v1', isAvailable: () => safeStorage.isEncryptionAvailable(), encrypt: t => safeStorage.encryptString(t), decrypt: b => safeStorage.decryptString(Buffer.from(b)) },
    openBrowser: () => { throw new Error('Accesso interattivo richiesto.'); }
  });
  const report = { checkedAt: new Date().toISOString(), session: null, models: [], responseOk: false };
  try {
    const session = await client.getSession();
    report.session = { status: session.status, sharing: session.sharing };
    if (session.status === 'connected' && session.sharing) {
      const models = await client.listModels(); report.models = models.map(m => m.slug);
      if (models.length) { const result = await client.streamResponse({ model: models[0].slug, input: [{ role: 'user', content: 'Controllo di funzionamento: rispondi soltanto PRONTO.' }], instructions: 'Rispondi brevemente al controllo tecnico.' }); report.responseOk = Boolean(result.text.trim()); }
    }
  } catch (error) { const safe = typeof error.toJSON === 'function' ? error.toJSON() : {}; report.error = { code: safe.code || 'check_failed', status: safe.status, message: safe.message || 'Controllo non completato.' }; }
  await fs.writeFile(path.join(app.getPath('temp'), 'jarvis-doctor.json'), JSON.stringify(report, null, 2));
  app.quit();
}).catch(() => app.exit(1));
