const { contextBridge, ipcRenderer } = require('electron');
const invoke = name => (...args) => ipcRenderer.invoke('jarvis:' + name, ...args);
const on = name => callback => { const listener = (_event, data) => callback(data); ipcRenderer.on('jarvis:' + name, listener); return () => ipcRenderer.removeListener('jarvis:' + name, listener); };
contextBridge.exposeInMainWorld('jarvis', {
  feedbackStatus:invoke('feedback-status'),exportFeedback:invoke('export-feedback'),
  aiConfig:invoke('ai-config'), configureAI:invoke('ai-configure'),memoryMap:invoke('memory-map'),importMemorySource:invoke('import-memory-source'),syncMemorySources:invoke('sync-memory-sources'),setupStatus:invoke('setup-status'),completeSetup:invoke('setup-complete'),onMemoryMap:on('memory-map'),
  getState: invoke('get-state'), loadMemory: invoke('load-memory'), getKnowledge: invoke('knowledge-status'), refreshKnowledge: invoke('refresh-knowledge'),
  conversationControl:invoke('conversation-control'), pauseRoutine:invoke('pause-routine'), getActivities:invoke('activities'), getSettings: invoke('get-settings'), saveSettings: invoke('save-settings'), getPhonePairing: invoke('phone-pairing'),
  openMemorySource: invoke('open-memory-source'), signIn: invoke('sign-in'), disconnect: invoke('disconnect'), sendMessage: invoke('send-message'), cancel: invoke('cancel'),
  pushAudio: bytes=>ipcRenderer.send('jarvis:audio-chunk',bytes), audioCaptureError:invoke('audio-capture-error'), playbackState:invoke('playback-state'),
  listen: invoke('voice-listen'), stopListening: invoke('voice-stop'), speak: invoke('speak'), stopSpeaking: invoke('stop-speech'), hideMedia:invoke('hide-media'), pickMedia: invoke('pick-media'), importChatGPT: invoke('import-chatgpt'),
  onState: on('state'), onDelta: on('delta'), onKnowledge: on('knowledge'), onSources: on('sources'), onActivity: on('activity'), onConversation: on('conversation'), onSettings: on('settings'), onVoice: on('voice'), onMedia: on('media'), onNotice: on('notice'), onDeltaReset: on('delta-reset')
});
